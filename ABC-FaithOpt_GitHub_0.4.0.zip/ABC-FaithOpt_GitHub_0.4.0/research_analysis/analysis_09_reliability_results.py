#!/usr/bin/env python3
"""Analysis 09: ML/XAI generalization gaps and explanation stability."""
from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd

from analysis_01_dataset_summary import AnalysisProgress, checkpoint_tsv, read_tsv, write_tsv


KEYS = ["dataset", "model", "repeat", "outer_fold"]


def _metric_row(key, method, metric, value):
    dataset, model, repeat, fold = key
    return {
        "dataset": dataset, "model": model, "method": method,
        "repeat": repeat, "outer_fold": fold, "metric": metric, "value": value,
    }


def main() -> None:
    progress = AnalysisProgress(
        9, "reliability and stability", 3, "calculation stages",
        output_filename="reliability_results.tsv",
    )
    ml = read_tsv("ml_performance.tsv")
    faith = read_tsv("xai_faithfulness.tsv")
    features = read_tsv("selected_features.tsv")
    rows = []

    unit_started = progress.start(1, "ML generalization gaps")
    for key, group in ml.groupby(KEYS, sort=False):
        for feature_set, subset in group.groupby("feature_set"):
            indexed = subset.set_index("eval_split")
            rows.append(_metric_row(
                key, feature_set, "ml_train_test_ba_gap",
                indexed.loc["core_train", "balanced_accuracy"] - indexed.loc["outer_test", "balanced_accuracy"],
            ))
            rows.append(_metric_row(
                key, feature_set, "ml_inner_test_ba_gap",
                indexed.loc["inner_cv", "balanced_accuracy"] - indexed.loc["outer_test", "balanced_accuracy"],
            ))
            rows.append(_metric_row(
                key, feature_set, "ml_train_test_logloss_gap",
                indexed.loc["outer_test", "log_loss"] - indexed.loc["core_train", "log_loss"],
            ))
    checkpoint_tsv(rows, "reliability_results.tsv")
    progress.done(1, unit_started, len(rows))

    unit_started = progress.start(2, "XAI calibration/guard/test gaps")
    for (*key, method), group in faith.groupby([*KEYS, "method"], sort=False):
        indexed = group.set_index("eval_split")["behavior_r2"]
        rows.extend([
            _metric_row(tuple(key), method, "xai_cal_guard_r2_gap", indexed["calibration"] - indexed["guard"]),
            _metric_row(tuple(key), method, "xai_guard_test_r2_gap", indexed["guard"] - indexed["outer_test"]),
            _metric_row(tuple(key), method, "xai_cal_test_r2_gap", indexed["calibration"] - indexed["outer_test"]),
        ])
    checkpoint_tsv(rows, "reliability_results.tsv")
    progress.done(2, unit_started, len(rows))

    unit_started = progress.start(3, "feature, weight, and sensitivity stability")
    for (dataset, model), group in features.groupby(["dataset", "model"], sort=False):
        fold_sets = [
            set(subset.sort_values("rank").head(5)["feature"])
            for _, subset in group.groupby(["repeat", "outer_fold"])
        ]
        jaccards = [len(a & b) / max(len(a | b), 1) for a, b in combinations(fold_sets, 2)]
        rows.append({
            "dataset": dataset, "model": model, "method": "abc_faithopt",
            "repeat": "all", "outer_fold": "all", "metric": "topk_jaccard",
            "value": float(np.mean(jaccards)) if jaccards else np.nan,
        })
        feature_means = group.groupby("feature")["faithful_weight"].mean()
        cvs = []
        for feature, subset in group.groupby("feature"):
            mean = feature_means[feature]
            if mean > 1e-12 and len(subset) > 1:
                cvs.append(float(subset["faithful_weight"].std(ddof=1) / mean))
        rows.append({
            "dataset": dataset, "model": model, "method": "abc_faithopt",
            "repeat": "all", "outer_fold": "all", "metric": "weight_cv",
            "value": float(np.mean(cvs)) if cvs else np.nan,
        })
        relative_change = (
            (group["faithful_weight"] - group["abc_weight"]).abs()
            / group["abc_weight"].clip(lower=1e-15) * 100.0
        )
        selected_bound = group["selected_sensitivity_pct"].astype(float)
        bound_hits = relative_change >= (selected_bound - 1e-3)
        rows.append({
            "dataset": dataset, "model": model, "method": "abc_faithopt",
            "repeat": "all", "outer_fold": "all", "metric": "weight_bound_hit_rate",
            "value": float(np.mean(bound_hits)),
        })
        fold_sensitivity = group.groupby(["repeat", "outer_fold"])[
            "selected_sensitivity_pct"
        ].first()
        rows.append({
            "dataset": dataset, "model": model, "method": "abc_faithopt",
            "repeat": "all", "outer_fold": "all", "metric": "sensitivity_cv",
            "value": (
                float(fold_sensitivity.std(ddof=1) / fold_sensitivity.mean())
                if len(fold_sensitivity) > 1 and fold_sensitivity.mean() > 1e-12
                else np.nan
            ),
        })
        rows.append({
            "dataset": dataset, "model": model, "method": "abc_faithopt",
            "repeat": "all", "outer_fold": "all",
            "metric": "sensitivity_boundary_hit_rate",
            "value": float(
                group.groupby(["repeat", "outer_fold"])[
                    "sensitivity_boundary_hit"
                ].first().astype(bool).mean()
            ),
        })
        rows.append({
            "dataset": dataset, "model": model, "method": "abc_faithopt",
            "repeat": "all", "outer_fold": "all",
            "metric": "abc_selected_frequency_mean",
            "value": float(group["selection_frequency"].astype(float).mean()),
        })
        rows.append({
            "dataset": dataset, "model": model, "method": "abc_faithopt",
            "repeat": "all", "outer_fold": "all",
            "metric": "abc_consensus_use_rate",
            "value": float(
                group.groupby(["repeat", "outer_fold"])[
                    "abc_consensus_used"
                ].first().astype(bool).mean()
            ),
        })
        rows.append({
            "dataset": dataset, "model": model, "method": "abc_faithopt",
            "repeat": "all", "outer_fold": "all",
            "metric": "abc_member_jaccard_mean",
            "value": float(
                group.groupby(["repeat", "outer_fold"])[
                    "abc_member_jaccard"
                ].first().astype(float).mean()
            ),
        })
    checkpoint_tsv(rows, "reliability_results.tsv")
    progress.done(3, unit_started, len(rows))
    path = write_tsv(rows, "reliability_results.tsv")
    progress.finish(len(rows), path)


if __name__ == "__main__":
    main()
