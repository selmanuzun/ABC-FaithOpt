#!/usr/bin/env python3
"""Analysis 12: standardized runtime, model-call and peak-memory benchmark."""
from __future__ import annotations

import time
import tracemalloc
from pathlib import Path
from typing import Any, Callable

import pandas as pd
from sklearn.base import clone

from analysis_01_dataset_summary import (
    CAL_PATTERNS,
    CAL_PERTURBATIONS,
    DATASETS,
    GUARD_PATTERNS,
    GUARD_PERTURBATIONS,
    MODELS,
    N_REPEATS,
    N_SPLITS,
    OUTPUT_DIR,
    TEST_PATTERNS,
    base_row,
    build_disjoint_mask_patterns,
    fit_scale,
    iter_fold_caches,
    measure_masked_model_behavior,
    native_importance,
    optimize_behavior_reconstruction,
    optimizer_config,
    permutation_weights,
    run_abc,
    selected_layout,
    selected_matrices,
    shap_mc_weights,
    stable_seed,
    write_tsv,
)


EXPLANATION_METHODS = (
    "abc_faithopt",
    "permutation",
    "shap_mc",
    "native_importance",
)
ROWS_PER_FOLD = len(EXPLANATION_METHODS) + 2  # ABC end-to-end + ML training


def format_duration(seconds: float | None) -> str:
    if seconds is None or not pd.notna(seconds):
        return "calculating"
    seconds = max(0, int(round(seconds)))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def checkpoint(rows: list[dict[str, Any]]) -> Path:
    """Atomically publish completed runtime measurements."""
    path = OUTPUT_DIR / "runtime_results.tsv"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tsv.tmp")
    pd.DataFrame(rows).to_csv(
        temporary, sep="\t", index=False, encoding="utf-8", na_rep="NA"
    )
    temporary.replace(path)
    return path


class CountingModel:
    def __init__(self, model: Any) -> None:
        self.model = model
        self.calls = 0
        self.rows = 0

    def predict_proba(self, X):
        self.calls += 1
        self.rows += len(X)
        return self.model.predict_proba(X)

    def predict(self, X):
        self.calls += 1
        self.rows += len(X)
        return self.model.predict(X)

    def __getattr__(self, name):
        return getattr(self.model, name)


def measure(function: Callable[[], Any]) -> tuple[Any, float, float]:
    tracemalloc.start()
    started = time.perf_counter()
    value = function()
    elapsed = time.perf_counter() - started
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return value, elapsed, peak / (1024.0 * 1024.0)


def faithful_explanation(cache, counted_model):
    matrices = selected_matrices(cache)
    names = cache["abc_result"].selected_features
    seed = stable_seed(cache["split"].seed, "runtime_faith")
    patterns = build_disjoint_mask_patterns(
        len(names), calibration_patterns=max(CAL_PATTERNS, len(names)),
        guard_patterns=GUARD_PATTERNS, test_patterns=TEST_PATTERNS, random_state=seed,
    )
    cal = measure_masked_model_behavior(
        model=counted_model, X=matrices["calibration"], feature_names=names,
        feature_groups=cache["relative_groups"], mask_patterns=patterns.calibration,
        n_perturbations=max(CAL_PERTURBATIONS, len(patterns.calibration)), random_state=seed + 1,
    )
    guard = measure_masked_model_behavior(
        model=counted_model, X=matrices["guard"], feature_names=names,
        feature_groups=cache["relative_groups"], mask_patterns=patterns.guard,
        n_perturbations=max(GUARD_PERTURBATIONS, len(patterns.guard)), random_state=seed + 2,
    )
    return optimize_behavior_reconstruction(
        cache["abc_result"].initial_weights, cal, guard, optimizer_config(seed)
    )


def time_method(cache, method: str, scope: str):
    counted = CountingModel(cache["model_selected"])
    local_cache = dict(cache)
    local_cache["model_selected"] = counted

    def operation():
        if method == "abc_faithopt":
            if scope == "end_to_end_xai":
                run_abc(
                    cache["dataset"].X.iloc[cache["split"].core_idx],
                    cache["labels"]["core_train"],
                    cache["dataset"].categorical_features,
                    cache["split"].seed,
                )
            return faithful_explanation(local_cache, counted)
        if method == "permutation":
            return permutation_weights(local_cache)
        if method == "shap_mc":
            return shap_mc_weights(local_cache)
        if method == "native_importance":
            return native_importance(local_cache)
        raise ValueError(method)

    # Warm-up is deliberately outside the measured block.
    cache["model_selected"].predict_proba(selected_matrices(cache)["calibration"][:4])
    _, seconds, peak = measure(operation)
    return seconds, counted.calls, counted.rows, peak


def main() -> None:
    total_folds = len(DATASETS) * len(MODELS) * N_SPLITS * N_REPEATS
    expected_rows = total_folds * ROWS_PER_FOLD
    rows: list[dict[str, Any]] = []
    fold_durations: list[float] = []
    analysis_started = time.perf_counter()
    print("\nABC-FaithOpt Analysis 12 — standardized runtime", flush=True)
    print(
        f"Plan: {total_folds} dataset-model-fold units × {ROWS_PER_FOLD} measurements "
        f"= {expected_rows} TSV rows",
        flush=True,
    )
    print(
        "Serial timing for validity: 4 explanation-only methods, "
        "ABC-FaithOpt end-to-end only, and 1 ML training measurement.",
        flush=True,
    )
    print(f"Partial/final TSV: {OUTPUT_DIR / 'runtime_results.tsv'}\n", flush=True)

    try:
        for fold_number, cache in enumerate(iter_fold_caches(require_existing=True), 1):
            fold_started = time.perf_counter()
            common = base_row(cache)
            tag = (
                f"{common['dataset']} | {common['model']} | "
                f"r{common['repeat']}f{common['outer_fold']}"
            )
            print(f"[{fold_number:02d}/{total_folds:02d}] START | {tag}", flush=True)

            for method_number, method in enumerate(EXPLANATION_METHODS, 1):
                print(
                    f"             STEP  | explanation {method_number}/"
                    f"{len(EXPLANATION_METHODS)}: {method}",
                    flush=True,
                )
                seconds, calls, perturbed_rows, peak = time_method(
                    cache, method, "explanation_only"
                )
                rows.append({
                    **common, "method": method, "scope": "explanation_only",
                    "runtime_sec": seconds, "model_calls": calls,
                    "perturbed_rows": perturbed_rows, "peak_memory_mib": peak,
                })

            print("             STEP  | ABC-FaithOpt end-to-end XAI", flush=True)
            seconds, calls, perturbed_rows, peak = time_method(
                cache, "abc_faithopt", "end_to_end_xai"
            )
            rows.append({
                **common, "method": "abc_faithopt", "scope": "end_to_end_xai",
                "runtime_sec": seconds, "model_calls": calls,
                "perturbed_rows": perturbed_rows, "peak_memory_mib": peak,
            })

            print("             STEP  | selected-model ML training", flush=True)
            matrices = selected_matrices(cache)
            training_model = clone(cache["model_selected"])
            _, seconds, peak = measure(
                lambda: training_model.fit(
                    matrices["core_train"], cache["labels"]["core_train"]
                )
            )
            rows.append({
                **common, "method": "ml_training", "scope": "training",
                "runtime_sec": seconds, "model_calls": 0,
                "perturbed_rows": 0, "peak_memory_mib": peak,
            })

            checkpoint(rows)
            fold_elapsed = time.perf_counter() - fold_started
            fold_durations.append(fold_elapsed)
            remaining = total_folds - fold_number
            eta = (
                float(pd.Series(fold_durations).median()) * remaining
                if remaining else 0.0
            )
            print(
                f"[{fold_number:02d}/{total_folds:02d}] DONE  | "
                f"fold_time={format_duration(fold_elapsed)} | "
                f"remaining={remaining} | ETA={format_duration(eta)} | "
                f"TSV_rows={len(rows)}/{expected_rows}",
                flush=True,
            )
    except (Exception, KeyboardInterrupt):
        if rows:
            checkpoint(rows)
        print(
            "Analysis 12 interrupted; completed fold measurements and the "
            "partial TSV checkpoint were preserved.",
            flush=True,
        )
        raise

    if len(rows) != expected_rows:
        raise RuntimeError(f"Expected {expected_rows} rows, produced {len(rows)}.")
    unique_keys = {
        (
            row["dataset"], row["model"], row["repeat"], row["outer_fold"],
            row["method"], row["scope"],
        )
        for row in rows
    }
    if len(unique_keys) != expected_rows:
        raise RuntimeError("Duplicate dataset/model/fold/method/scope rows detected.")

    final_path = write_tsv(rows, "runtime_results.tsv")
    total_elapsed = time.perf_counter() - analysis_started
    print(
        f"Analysis 12 complete: {len(rows)}/{expected_rows} rows | "
        f"total_time={format_duration(total_elapsed)}\nOutput: {final_path}",
        flush=True,
    )


if __name__ == "__main__":
    main()
