#!/usr/bin/env python3
"""Analysis 07: ABC and optimizer component ablations."""
from __future__ import annotations

from analysis_01_dataset_summary import (
    AnalysisProgress,
    DATASETS,
    MODELS,
    N_REPEATS,
    N_SPLITS,
    base_row,
    build_xai_cache,
    checkpoint_tsv,
    conditional_deletion,
    evaluate_behavior_reconstruction,
    fit_scale,
    iter_fold_caches,
    normalize_weights,
    optimize_behavior_reconstruction,
    optimizer_config,
    stable_seed,
    write_tsv,
)


def main() -> None:
    rows = []
    total_folds = len(DATASETS) * len(MODELS) * N_REPEATS * N_SPLITS
    expected_rows = total_folds * 3
    progress = AnalysisProgress(
        7, "component ablation", total_folds, "dataset-model-fold units",
        expected_rows=expected_rows, output_filename="ablation_results.tsv",
    )
    for fold_number, cache in enumerate(iter_fold_caches(require_existing=True), 1):
        common = base_row(cache)
        unit_started = progress.start(
            fold_number,
            f"{common['dataset']} | {common['model']} | "
            f"r{common['repeat']}f{common['outer_fold']}",
        )
        xai = build_xai_cache(cache)
        names = cache["abc_result"].selected_features
        initial = normalize_weights(xai["optimization"].initial_weights, names)
        final = normalize_weights(xai["optimization"].final_weights, names)
        uniform = {name: 1.0 / len(names) for name in names}
        progress.step("optimizing the uniform-weight ablation")
        uniform_opt = optimize_behavior_reconstruction(
            uniform, xai["behavior"]["calibration"], xai["behavior"]["guard"],
            optimizer_config(stable_seed(cache["split"].seed, "uniform")),
        )
        variants = {
            "full": final,
            "abc_only": initial,
            "uniform_optimizer": normalize_weights(uniform_opt.final_weights, names),
        }
        for variant_number, (variant, weights) in enumerate(variants.items(), 1):
            progress.step(f"evaluating variant {variant_number}/{len(variants)}: {variant}")
            scale = fit_scale(weights, xai["behavior"]["calibration"])
            test_metrics = evaluate_behavior_reconstruction(
                weights, scale, xai["behavior"]["outer_test"]
            )
            deletion_auc, _, _ = conditional_deletion(cache, weights)
            rows.append({
                **common, "variant": variant,
                "test_r2": test_metrics.r2,
                "test_nmae": test_metrics.normalized_mae,
                "deletion_auc": deletion_auc,
                "selected_n": len(names),
            })
        checkpoint_tsv(rows, "ablation_results.tsv")
        progress.done(fold_number, unit_started, len(rows))
    path = write_tsv(rows, "ablation_results.tsv")
    progress.finish(len(rows), path)


if __name__ == "__main__":
    main()
