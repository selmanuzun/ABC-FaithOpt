#!/usr/bin/env python3
"""Analysis 01 and shared research infrastructure for ABC-FaithOpt.

Run this file first.  The remaining numbered scripts import this module.  All
paths are resolved from the project root, so the scripts may be launched from
any working directory.
"""
from __future__ import annotations

import hashlib
import gzip
import io
import json
import math
import os
import pickle
import shutil
import sys
import time
import urllib.request
import warnings
import zipfile
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
from scipy.integrate import trapezoid
from scipy.stats import rankdata, spearmanr
from sklearn.base import clone
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, log_loss, roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold, train_test_split
from sklearn.preprocessing import LabelEncoder


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from abc_faithopt.abc import (  # noqa: E402
    ABCConfig,
    FeatureValueObjective,
    run_abc_feature_value_search,
)
from abc_faithopt.datasets import fetch_uci_dataset  # noqa: E402
from abc_faithopt.faithfulness import (  # noqa: E402
    BehaviorPerturbationResult,
    FaithfulnessOptimizerConfig,
    build_disjoint_mask_patterns,
    evaluate_behavior_reconstruction,
    measure_masked_model_behavior,
    optimize_behavior_reconstruction,
    permutation_impacts,
    reconstruction_metrics,
    safe_spearman,
)
from abc_faithopt.preprocessing import TabularPreprocessor  # noqa: E402


PROJECT_ON_WSL_MOUNT = str(PROJECT_ROOT).startswith("/mnt/")
LEGACY_OUTPUT_DIR = PROJECT_ROOT / "analysis_outputs"
LEGACY_CACHE_DIR = PROJECT_ROOT / "analysis_cache"
LEGACY_DATA_DIR = LEGACY_CACHE_DIR / "uci"
if PROJECT_ON_WSL_MOUNT:
    # Long computations should not checkpoint to /mnt/<drive>: cloud-backed or
    # removable Windows mounts may disappear with ENODEV after hours of work.
    WSL_WORK_ROOT = Path.home() / ".cache" / "abc_faithopt_sci" / PROJECT_ROOT.name
else:
    WSL_WORK_ROOT = PROJECT_ROOT

OUTPUT_DIR = Path(os.environ.get("ABCFAITH_OUTPUT_DIR", WSL_WORK_ROOT / "analysis_outputs"))
CACHE_DIR = Path(os.environ.get("ABCFAITH_ANALYSIS_CACHE", WSL_WORK_ROOT / "analysis_cache"))
DATA_DIR = Path(os.environ.get("ABCFAITH_DATA_CACHE", WSL_WORK_ROOT / "uci"))
for directory in (OUTPUT_DIR, CACHE_DIR, DATA_DIR):
    directory.mkdir(parents=True, exist_ok=True)

# Seed the stable WSL-local UCI cache from an existing project cache. Files are
# small and copied only when the destination is absent.
if PROJECT_ON_WSL_MOUNT and LEGACY_DATA_DIR.exists() and DATA_DIR != LEGACY_DATA_DIR:
    try:
        for archive in LEGACY_DATA_DIR.glob("*.zip"):
            destination = DATA_DIR / archive.name
            if not destination.exists():
                shutil.copy2(archive, destination)
    except OSError as error:
        warnings.warn(f"Existing UCI cache could not be copied from the mount: {error}")

FAST = os.environ.get("ABCFAITH_FAST", "0").strip().lower() in {"1", "true", "yes"}
N_SPLITS = int(os.environ.get("ABCFAITH_N_SPLITS", "2" if FAST else "3"))
N_REPEATS = int(os.environ.get("ABCFAITH_N_REPEATS", "1"))
INNER_SPLITS = int(os.environ.get("ABCFAITH_INNER_SPLITS", "2" if FAST else "3"))
BASE_SEED = int(os.environ.get("ABCFAITH_SEED", "20260813"))
ABC_COLONY = int(os.environ.get("ABCFAITH_ABC_COLONY", "8" if FAST else "24"))
ABC_ITERATIONS = int(os.environ.get("ABCFAITH_ABC_ITERATIONS", "4" if FAST else "40"))
ABC_STABILITY_RUNS = int(
    os.environ.get("ABCFAITH_ABC_STABILITY_RUNS", "3" if FAST else "7")
)
ABC_STABILITY_SUBSAMPLE = float(
    os.environ.get("ABCFAITH_ABC_STABILITY_SUBSAMPLE", "0.80")
)
ABC_STABILITY_FREQUENCY_WEIGHT = float(
    os.environ.get("ABCFAITH_ABC_STABILITY_FREQUENCY_WEIGHT", "0.75")
)
ABC_STABILITY_FITNESS_TOLERANCE = float(
    os.environ.get("ABCFAITH_ABC_STABILITY_FITNESS_TOLERANCE", "0.05")
)
CAL_PERTURBATIONS = int(os.environ.get("ABCFAITH_CAL_PERTURBATIONS", "32" if FAST else "192"))
GUARD_PERTURBATIONS = int(os.environ.get("ABCFAITH_GUARD_PERTURBATIONS", "24" if FAST else "128"))
TEST_PERTURBATIONS = int(os.environ.get("ABCFAITH_TEST_PERTURBATIONS", "24" if FAST else "128"))
CAL_PATTERNS = int(os.environ.get("ABCFAITH_CAL_PATTERNS", "12" if FAST else "32"))
GUARD_PATTERNS = int(os.environ.get("ABCFAITH_GUARD_PATTERNS", "8" if FAST else "24"))
TEST_PATTERNS = int(os.environ.get("ABCFAITH_TEST_PATTERNS", "8" if FAST else "24"))
SHAP_PERMUTATIONS = int(os.environ.get("ABCFAITH_SHAP_PERMUTATIONS", "4" if FAST else "32"))
PERMUTATION_RUNS = int(os.environ.get("ABCFAITH_PERMUTATION_RUNS", "3" if FAST else "20"))
TOP_K = int(os.environ.get("ABCFAITH_TOP_K", "5"))
AUDIT_ROWS = int(os.environ.get("ABCFAITH_AUDIT_ROWS", "128" if FAST else "1000"))
DONOR_ROWS = int(os.environ.get("ABCFAITH_DONOR_ROWS", "256" if FAST else "3000"))
ANALYSIS_WORKERS = int(
    os.environ.get("ABCFAITH_ANALYSIS_WORKERS", str(max(1, min(8, os.cpu_count() or 1))))
)
# Analysis 03 parallelizes independent outer-fold groups. Keep each individual
# estimator single-process by default to avoid 8 workers each spawning 8 more
# threads. It may still be overridden explicitly for serial/special runs.
N_JOBS = int(os.environ.get("ABCFAITH_MODEL_N_JOBS", "1"))
AUTO_SENSITIVITY_MIN = float(os.environ.get("ABCFAITH_AUTO_SENSITIVITY_MIN", "10"))
AUTO_SENSITIVITY_MAX = float(os.environ.get("ABCFAITH_AUTO_SENSITIVITY_MAX", "100"))
AUTO_SENSITIVITY_COLONY = int(
    os.environ.get("ABCFAITH_AUTO_SENSITIVITY_COLONY", "6" if FAST else "10")
)
AUTO_SENSITIVITY_ITERATIONS = int(
    os.environ.get("ABCFAITH_AUTO_SENSITIVITY_ITERATIONS", "4" if FAST else "12")
)
XAI_CACHE_VERSION = "stable_abc_auto_sensitivity_v2"
PROTOCOL_ID = (
    f"v3stable_seed{BASE_SEED}_outer{N_SPLITS}x{N_REPEATS}_inner{INNER_SPLITS}_"
    f"abc{ABC_COLONY}x{ABC_ITERATIONS}_"
    f"stable{ABC_STABILITY_RUNS}x{ABC_STABILITY_SUBSAMPLE:g}x"
    f"{ABC_STABILITY_FREQUENCY_WEIGHT:g}x{ABC_STABILITY_FITNESS_TOLERANCE:g}_"
    f"p{CAL_PERTURBATIONS}-{GUARD_PERTURBATIONS}-{TEST_PERTURBATIONS}_"
    f"m{CAL_PATTERNS}-{GUARD_PATTERNS}-{TEST_PATTERNS}_"
    f"sens{AUTO_SENSITIVITY_MIN:g}-{AUTO_SENSITIVITY_MAX:g}"
)


def migrate_legacy_protocol_cache() -> int:
    """Copy completed fold/XAI checkpoints from an older project-local cache."""
    if not PROJECT_ON_WSL_MOUNT or CACHE_DIR == LEGACY_CACHE_DIR:
        return 0
    source = LEGACY_CACHE_DIR / PROTOCOL_ID
    destination = CACHE_DIR / PROTOCOL_ID
    if not source.exists():
        return 0
    copied = 0
    try:
        for original in source.rglob("*.pkl.gz"):
            relative = original.relative_to(source)
            target = destination / relative
            if target.exists():
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(original, target)
            copied += 1
    except OSError as error:
        warnings.warn(f"Legacy checkpoint migration stopped: {error}")
    return copied

ALL_DATASETS = (
    "breast_cancer",
    "adult",
    "dry_bean",
    "bank_marketing",
    "spambase",
    "landsat",
)
ALL_MODELS = ("logistic_regression", "random_forest", "gradient_boosting")


def _selected_env(name: str, defaults: Sequence[str]) -> tuple[str, ...]:
    value = os.environ.get(name)
    if not value:
        return tuple(defaults)
    selected = tuple(item.strip() for item in value.split(",") if item.strip())
    unknown = set(selected) - set(defaults)
    if unknown:
        raise ValueError(f"Unknown values in {name}: {sorted(unknown)}")
    return selected


DATASETS = _selected_env("ABCFAITH_DATASETS", ALL_DATASETS)
MODELS = _selected_env("ABCFAITH_MODELS", ALL_MODELS)


@dataclass(frozen=True)
class DatasetBundle:
    key: str
    name: str
    uci_id: int
    X: pd.DataFrame
    y: pd.Series
    categorical_features: tuple[str, ...]


@dataclass(frozen=True)
class SplitBundle:
    repeat: int
    outer_fold: int
    seed: int
    core_idx: np.ndarray
    calibration_idx: np.ndarray
    guard_idx: np.ndarray
    test_idx: np.ndarray


def format_duration(seconds: float | None) -> str:
    if seconds is None or not np.isfinite(seconds):
        return "calculating"
    total = max(0, int(round(seconds)))
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


@dataclass
class AnalysisProgress:
    """Consistent English progress, ETA, and completion messages."""

    number: int
    title: str
    total_units: int
    unit_name: str
    expected_rows: int | None = None
    output_filename: str | None = None

    def __post_init__(self) -> None:
        self.analysis_started = time.perf_counter()
        self.unit_durations: list[float] = []
        print(f"\nABC-FaithOpt Analysis {self.number:02d} — {self.title}", flush=True)
        plan = f"Plan: {self.total_units} {self.unit_name}"
        if self.expected_rows is not None:
            plan += f" | expected TSV rows: {self.expected_rows}"
        print(plan, flush=True)
        if self.output_filename is not None:
            print(f"Output: {OUTPUT_DIR / self.output_filename}\n", flush=True)

    def start(self, index: int, label: str) -> float:
        print(
            f"[{index:02d}/{self.total_units:02d}] START | {label}",
            flush=True,
        )
        return time.perf_counter()

    def step(self, message: str) -> None:
        print(f"             STEP  | {message}", flush=True)

    def done(self, index: int, unit_started: float, row_count: int) -> None:
        elapsed = time.perf_counter() - unit_started
        self.unit_durations.append(elapsed)
        remaining = max(0, self.total_units - index)
        eta = float(np.median(self.unit_durations)) * remaining
        row_text = f" | rows={row_count}"
        if self.expected_rows is not None:
            row_text += f"/{self.expected_rows}"
        print(
            f"[{index:02d}/{self.total_units:02d}] DONE  | "
            f"unit_time={format_duration(elapsed)} | remaining={remaining} | "
            f"ETA={format_duration(eta)}{row_text}",
            flush=True,
        )

    def finish(self, row_count: int, path: Path) -> None:
        print(
            f"Analysis {self.number:02d} complete | rows={row_count} | "
            f"total_time={format_duration(time.perf_counter() - self.analysis_started)}"
            f"\nOutput: {path}",
            flush=True,
        )

    def interrupted(self, row_count: int) -> None:
        print(
            f"Analysis {self.number:02d} interrupted | completed rows={row_count}. "
            "The partial TSV checkpoint was preserved.",
            flush=True,
        )


def write_tsv(rows: Iterable[Mapping[str, Any]] | pd.DataFrame, filename: str) -> Path:
    frame = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(list(rows))
    path = OUTPUT_DIR / filename
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, sep="\t", index=False, encoding="utf-8", na_rep="NA")
    temporary.replace(path)
    print(f"Saved {len(frame)} rows: {path}")
    return path


def checkpoint_tsv(
    rows: Iterable[Mapping[str, Any]] | pd.DataFrame,
    filename: str,
) -> Path:
    """Atomically save a partial TSV without adding noisy console output."""
    frame = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(list(rows))
    path = OUTPUT_DIR / filename
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, sep="\t", index=False, encoding="utf-8", na_rep="NA")
    temporary.replace(path)
    return path


def read_tsv(filename: str) -> pd.DataFrame:
    path = OUTPUT_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"Run the prerequisite analysis first: {path.name}")
    return pd.read_csv(path, sep="\t", na_values=["NA"])


def save_pickle(value: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with gzip.open(temporary, "wb", compresslevel=3) as handle:
        pickle.dump(value, handle, protocol=pickle.HIGHEST_PROTOCOL)
    temporary.replace(path)


def load_pickle(path: Path) -> Any:
    with gzip.open(path, "rb") as handle:
        return pickle.load(handle)


def stable_seed(*parts: Any) -> int:
    digest = hashlib.sha256("|".join(map(str, parts)).encode("utf-8")).digest()
    return int.from_bytes(digest[:4], "little") & 0x7FFFFFFF


def _download_zip(uci_id: int, slug: str) -> Path:
    destination = DATA_DIR / f"uci_{uci_id}_{slug}.zip"
    if destination.exists():
        return destination
    url = f"https://archive.ics.uci.edu/static/public/{uci_id}/{slug}.zip"
    request = urllib.request.Request(url, headers={"User-Agent": "ABC-FaithOpt-SCI/1.0"})
    temporary = destination.with_suffix(".zip.part")
    with urllib.request.urlopen(request, timeout=180) as response, temporary.open("wb") as out:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)
    temporary.replace(destination)
    return destination


def _load_bank() -> DatasetBundle:
    path = _download_zip(222, "bank%2Bmarketing")
    with zipfile.ZipFile(path) as archive:
        nested_name = next(name for name in archive.namelist() if name.endswith("bank.zip"))
        with zipfile.ZipFile(io.BytesIO(archive.read(nested_name))) as nested:
            member = next(name for name in nested.namelist() if name.endswith("bank-full.csv"))
            frame = pd.read_csv(nested.open(member), sep=";")
    y = frame.pop("y").astype("string")
    categorical = tuple(
        column for column in frame if pd.api.types.is_object_dtype(frame[column])
    )
    return DatasetBundle("bank_marketing", "Bank Marketing", 222, frame, y, categorical)


def _spambase_names(archive: zipfile.ZipFile) -> list[str]:
    member = next(name for name in archive.namelist() if name.endswith("spambase.names"))
    text = archive.read(member).decode("utf-8", errors="replace")
    names: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if ":" in stripped and not stripped.startswith("|"):
            candidate = stripped.split(":", 1)[0].strip()
            if candidate and candidate != "1, 0":
                names.append(candidate)
    return names[:57] if len(names) >= 57 else [f"feature_{i+1}" for i in range(57)]


def _load_spambase() -> DatasetBundle:
    path = _download_zip(94, "spambase")
    with zipfile.ZipFile(path) as archive:
        member = next(name for name in archive.namelist() if name.endswith("spambase.data"))
        columns = _spambase_names(archive)
        frame = pd.read_csv(archive.open(member), header=None, names=[*columns, "spam"])
    y = frame.pop("spam").astype("string")
    return DatasetBundle("spambase", "Spambase", 94, frame, y, ())


def _load_landsat() -> DatasetBundle:
    path = _download_zip(146, "statlog%2Blandsat%2Bsatellite")
    pieces: list[pd.DataFrame] = []
    with zipfile.ZipFile(path) as archive:
        for suffix in ("sat.trn", "sat.tst"):
            member = next(name for name in archive.namelist() if name.endswith(suffix))
            pieces.append(pd.read_csv(archive.open(member), sep=r"\s+", header=None))
    raw = pd.concat(pieces, ignore_index=True)
    raw.columns = [*[f"spectral_{i+1}" for i in range(36)], "class"]
    y = raw.pop("class").astype("string")
    return DatasetBundle("landsat", "Statlog Landsat Satellite", 146, raw, y, ())


def load_dataset(key: str) -> DatasetBundle:
    if key in {"breast_cancer", "adult", "dry_bean"}:
        data = fetch_uci_dataset(key, cache_dir=DATA_DIR)
        return DatasetBundle(key, data.name, data.uci_id, data.X, data.y, data.categorical_features)
    if key == "bank_marketing":
        return _load_bank()
    if key == "spambase":
        return _load_spambase()
    if key == "landsat":
        return _load_landsat()
    raise ValueError(f"Unknown dataset: {key}")


def encode_target(y: Sequence[Any]) -> tuple[np.ndarray, LabelEncoder]:
    encoder = LabelEncoder()
    encoded = encoder.fit_transform(np.asarray(y).astype(str))
    return encoded.astype(int), encoder


def iter_splits(y: np.ndarray) -> Iterable[SplitBundle]:
    splitter = RepeatedStratifiedKFold(
        n_splits=N_SPLITS, n_repeats=N_REPEATS, random_state=BASE_SEED
    )
    dummy = np.zeros((len(y), 1))
    for order, (development_idx, test_idx) in enumerate(splitter.split(dummy, y)):
        repeat = order // N_SPLITS + 1
        outer_fold = order % N_SPLITS + 1
        seed = stable_seed(BASE_SEED, repeat, outer_fold)
        core_idx, holdout_idx = train_test_split(
            development_idx,
            test_size=0.30,
            random_state=seed,
            stratify=y[development_idx],
        )
        calibration_idx, guard_idx = train_test_split(
            holdout_idx,
            test_size=0.50,
            random_state=seed + 1,
            stratify=y[holdout_idx],
        )
        yield SplitBundle(
            repeat, outer_fold, seed,
            np.asarray(core_idx), np.asarray(calibration_idx),
            np.asarray(guard_idx), np.asarray(test_idx),
        )


def abc_config(seed: int) -> ABCConfig:
    return ABCConfig(
        colony_size=ABC_COLONY,
        iterations=ABC_ITERATIONS,
        abandonment_limit=4 if FAST else 10,
        min_features=3,
        max_features=7,
        stability_runs=ABC_STABILITY_RUNS,
        stability_subsample=ABC_STABILITY_SUBSAMPLE,
        stability_frequency_weight=ABC_STABILITY_FREQUENCY_WEIGHT,
        stability_fitness_tolerance=ABC_STABILITY_FITNESS_TOLERANCE,
        random_state=seed,
    )


def optimizer_config(
    seed: int,
    bound: float | str | None = "auto",
    *,
    auto_max_pct: float | None = None,
) -> FaithfulnessOptimizerConfig:
    return FaithfulnessOptimizerConfig(
        steps=80 if FAST else 500,
        regularization=0.05,
        sensitivity=bound,
        min_acceptable_faithfulness=None,
        max_guard_nmae_increase=0.0,
        auto_sensitivity_min_pct=AUTO_SENSITIVITY_MIN,
        auto_sensitivity_max_pct=(
            AUTO_SENSITIVITY_MAX if auto_max_pct is None else float(auto_max_pct)
        ),
        auto_abc_colony_size=AUTO_SENSITIVITY_COLONY,
        auto_abc_iterations=AUTO_SENSITIVITY_ITERATIONS,
        calibration_perturbations=CAL_PERTURBATIONS,
        guard_perturbations=GUARD_PERTURBATIONS,
        test_perturbations=TEST_PERTURBATIONS,
        calibration_mask_patterns=CAL_PATTERNS,
        guard_mask_patterns=GUARD_PATTERNS,
        test_mask_patterns=TEST_PATTERNS,
        random_state=seed,
    )


def run_abc(
    X: pd.DataFrame,
    y: np.ndarray,
    categorical: Sequence[str],
    seed: int,
    progress: Callable[[str], None] | None = None,
) -> tuple[TabularPreprocessor, Any]:
    preprocessor = TabularPreprocessor(categorical).fit(X)
    objective = FeatureValueObjective(
        preprocessor.transform_rules(X),
        y,
        preprocessor.feature_names_,
        preprocessor.categorical_mask(),
        preprocessor.decode_category,
        abc_config(seed),
    )
    return preprocessor, run_abc_feature_value_search(
        objective, abc_config(seed), progress=progress
    )


def selected_layout(preprocessor: TabularPreprocessor, abc_result: Any) -> tuple[np.ndarray, dict[str, tuple[int, ...]]]:
    indices = np.asarray(abc_result.selected_indices, dtype=int)
    full_groups = preprocessor.model_group_indices(indices)
    columns = np.asarray(
        [column for feature in abc_result.selected_features for column in full_groups[feature]],
        dtype=int,
    )
    relative: dict[str, tuple[int, ...]] = {}
    cursor = 0
    for feature in abc_result.selected_features:
        width = len(full_groups[feature])
        relative[feature] = tuple(range(cursor, cursor + width))
        cursor += width
    return columns, relative


def model_grid(model_name: str) -> list[dict[str, Any]]:
    if FAST:
        if model_name == "logistic_regression":
            return [{"C": 1.0}]
        if model_name == "random_forest":
            return [{"n_estimators": 40, "max_depth": None, "min_samples_leaf": 2}]
        return [{"learning_rate": 0.1, "n_estimators": 50, "max_depth": 2}]
    if model_name == "logistic_regression":
        return [{"C": value} for value in (0.1, 1.0, 10.0)]
    if model_name == "random_forest":
        return [
            {"n_estimators": 200, "max_depth": depth, "min_samples_leaf": leaf}
            for depth, leaf in ((None, 1), (None, 3), (12, 2))
        ]
    return [
        {"learning_rate": rate, "n_estimators": estimators, "max_depth": depth}
        for rate, estimators, depth in ((0.05, 150, 2), (0.1, 100, 2), (0.05, 150, 3))
    ]


def make_model(model_name: str, params: Mapping[str, Any], seed: int) -> Any:
    if model_name == "logistic_regression":
        return LogisticRegression(
            C=float(params["C"]), max_iter=2500, class_weight="balanced",
            solver="lbfgs", random_state=seed,
        )
    if model_name == "random_forest":
        return RandomForestClassifier(
            **params, class_weight="balanced_subsample", random_state=seed,
            n_jobs=N_JOBS,
        )
    if model_name == "gradient_boosting":
        return GradientBoostingClassifier(**params, random_state=seed)
    raise ValueError(model_name)


def probability_metrics(model: Any, X: np.ndarray, y: np.ndarray) -> dict[str, float]:
    probabilities = normalized_predict_proba(model, X)
    predictions = np.asarray(model.predict(X))
    try:
        auc = roc_auc_score(
            y, probabilities[:, 1] if probabilities.shape[1] == 2 else probabilities,
            multi_class="ovr", average="macro", labels=model.classes_,
        )
    except ValueError:
        auc = np.nan
    return {
        "balanced_accuracy": float(balanced_accuracy_score(y, predictions)),
        "log_loss": float(log_loss(y, probabilities, labels=model.classes_)),
        "macro_auroc": float(auc),
    }


def normalized_predict_proba(model: Any, X: np.ndarray) -> np.ndarray:
    """Return finite row-normalized probabilities for strict sklearn metrics.

    Some estimators can produce rows whose sum differs from one by floating
    point round-off.  Renormalization does not change the predicted class; it
    prevents current warnings and future sklearn errors in log-loss scoring.
    """
    probabilities = np.asarray(model.predict_proba(X), dtype=np.float64)
    if probabilities.ndim != 2 or probabilities.shape[1] < 2:
        raise ValueError("predict_proba must return a 2D array with >=2 classes.")
    if not np.all(np.isfinite(probabilities)):
        raise ValueError("predict_proba returned non-finite values.")
    probabilities = np.clip(probabilities, 0.0, 1.0)
    row_sums = probabilities.sum(axis=1, keepdims=True)
    invalid = row_sums[:, 0] <= np.finfo(np.float64).tiny
    if np.any(invalid):
        probabilities[invalid] = 1.0 / probabilities.shape[1]
        row_sums = probabilities.sum(axis=1, keepdims=True)
    return probabilities / row_sums


def tune_model(
    dataset: DatasetBundle,
    core_idx: np.ndarray,
    y: np.ndarray,
    model_name: str,
    feature_set: str,
    seed: int,
    repeat: int,
    outer_fold: int,
    progress: Callable[[str], None] | None = None,
) -> tuple[dict[str, Any], dict[str, float]]:
    X_core = dataset.X.iloc[core_idx]
    y_core = y[core_idx]
    inner = StratifiedKFold(n_splits=INNER_SPLITS, shuffle=True, random_state=seed)
    best_params: dict[str, Any] | None = None
    best_loss = math.inf
    best_metrics: dict[str, float] = {}
    prepared_folds = []
    for inner_fold, (train_pos, valid_pos) in enumerate(inner.split(X_core, y_core), 1):
        if progress:
            progress(f"{feature_set}: preparing inner fold {inner_fold}/{INNER_SPLITS}")
        X_train = X_core.iloc[train_pos]
        X_valid = X_core.iloc[valid_pos]
        y_train = y_core[train_pos]
        y_valid = y_core[valid_pos]
        prep = TabularPreprocessor(dataset.categorical_features).fit(X_train)
        train_matrix = prep.transform_model(X_train)
        valid_matrix = prep.transform_model(X_valid)
        if feature_set == "selected":
            selection_path = inner_selection_cache_path(
                dataset.key, repeat, outer_fold, inner_fold
            )
            if selection_path.exists():
                selection = load_pickle(selection_path)
                if progress:
                    progress(f"selected: inner ABC {inner_fold}/{INNER_SPLITS} loaded from cache")
            else:
                if progress:
                    progress(f"selected: running inner ABC {inner_fold}/{INNER_SPLITS}")
                objective = FeatureValueObjective(
                    prep.transform_rules(X_train), y_train, prep.feature_names_,
                    prep.categorical_mask(), prep.decode_category,
                    abc_config(stable_seed(seed, "inner", inner_fold)),
                )
                selection = run_abc_feature_value_search(
                    objective,
                    abc_config(stable_seed(seed, "inner", inner_fold)),
                    progress=progress,
                )
                save_pickle(selection, selection_path)
            columns, _ = selected_layout(prep, selection)
            train_matrix = train_matrix[:, columns]
            valid_matrix = valid_matrix[:, columns]
        prepared_folds.append((inner_fold, train_matrix, valid_matrix, y_train, y_valid))
    grid = model_grid(model_name)
    for config_number, params in enumerate(grid, 1):
        if progress:
            progress(
                f"{feature_set}: {model_name} tuning {config_number}/{len(grid)} "
                f"({INNER_SPLITS}-fold)"
            )
        fold_metrics: list[dict[str, float]] = []
        for inner_fold, train_matrix, valid_matrix, y_train, y_valid in prepared_folds:
            model = make_model(model_name, params, stable_seed(seed, inner_fold))
            model.fit(train_matrix, y_train)
            fold_metrics.append(probability_metrics(model, valid_matrix, y_valid))
        mean_loss = float(np.mean([item["log_loss"] for item in fold_metrics]))
        if mean_loss < best_loss:
            best_loss = mean_loss
            best_params = dict(params)
            best_metrics = {
                key: float(np.nanmean([item[key] for item in fold_metrics]))
                for key in ("balanced_accuracy", "log_loss", "macro_auroc")
            }
    assert best_params is not None
    return best_params, best_metrics


def fold_cache_path(dataset: str, model: str, repeat: int, fold: int) -> Path:
    return CACHE_DIR / PROTOCOL_ID / "folds" / f"{dataset}__{model}__r{repeat}f{fold}.pkl.gz"


def xai_cache_path(dataset: str, model: str, repeat: int, fold: int) -> Path:
    return (
        CACHE_DIR / PROTOCOL_ID / XAI_CACHE_VERSION
        / f"{dataset}__{model}__r{repeat}f{fold}.pkl.gz"
    )


def shared_fold_cache_path(dataset: str, repeat: int, fold: int) -> Path:
    return CACHE_DIR / PROTOCOL_ID / "shared" / f"{dataset}__r{repeat}f{fold}.pkl.gz"


def inner_selection_cache_path(dataset: str, repeat: int, fold: int, inner_fold: int) -> Path:
    return (
        CACHE_DIR / PROTOCOL_ID / "inner_abc"
        / f"{dataset}__r{repeat}f{fold}__inner{inner_fold}.pkl.gz"
    )


def build_shared_fold_cache(
    dataset: DatasetBundle,
    y: np.ndarray,
    split: SplitBundle,
    progress: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    path = shared_fold_cache_path(dataset.key, split.repeat, split.outer_fold)
    if path.exists():
        if progress:
            progress("outer ABC/preprocessing loaded from shared cache")
        return load_pickle(path)
    if progress:
        progress("running outer ABC feature selection")
    X_core = dataset.X.iloc[split.core_idx]
    y_core = y[split.core_idx]
    preprocessor, abc_result = run_abc(
        X_core, y_core, dataset.categorical_features, split.seed, progress
    )
    selected_columns, relative_groups = selected_layout(preprocessor, abc_result)
    shared = {
        "dataset_key": dataset.key,
        "categorical_features": dataset.categorical_features,
        "split": split,
        "preprocessor": preprocessor,
        "abc_result": abc_result,
        "selected_columns": selected_columns,
        "relative_groups": relative_groups,
        "labels": {
            "core_train": y[split.core_idx],
            "calibration": y[split.calibration_idx],
            "guard": y[split.guard_idx],
            "outer_test": y[split.test_idx],
        },
    }
    save_pickle(shared, path)
    return shared


def build_fold_cache(
    dataset: DatasetBundle,
    y: np.ndarray,
    split: SplitBundle,
    model_name: str,
    progress: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    path = fold_cache_path(dataset.key, model_name, split.repeat, split.outer_fold)
    if path.exists():
        return hydrate_fold_cache(load_pickle(path))
    shared = build_shared_fold_cache(dataset, y, split, progress)
    preprocessor = shared["preprocessor"]
    abc_result = shared["abc_result"]
    selected_columns = shared["selected_columns"]
    relative_groups = shared["relative_groups"]
    matrices = {
        name: preprocessor.transform_model(dataset.X.iloc[index])
        for name, index in {
            "core_train": split.core_idx,
            "calibration": split.calibration_idx,
            "guard": split.guard_idx,
            "outer_test": split.test_idx,
        }.items()
    }
    labels = shared["labels"]
    params_full, cv_full = tune_model(
        dataset, split.core_idx, y, model_name, "full", split.seed,
        split.repeat, split.outer_fold, progress,
    )
    params_selected, cv_selected = tune_model(
        dataset, split.core_idx, y, model_name, "selected", split.seed,
        split.repeat, split.outer_fold, progress,
    )
    if progress:
        progress("training final full and selected models")
    model_full = make_model(model_name, params_full, split.seed)
    model_selected = make_model(model_name, params_selected, split.seed)
    model_full.fit(matrices["core_train"], labels["core_train"])
    model_selected.fit(matrices["core_train"][:, selected_columns], labels["core_train"])
    cache = {
        "dataset_key": dataset.key,
        "categorical_features": dataset.categorical_features,
        "split": split,
        "preprocessor": preprocessor,
        "abc_result": abc_result,
        "selected_columns": selected_columns,
        "relative_groups": relative_groups,
        "labels": labels,
        "params_full": params_full,
        "params_selected": params_selected,
        "inner_cv_full": cv_full,
        "inner_cv_selected": cv_selected,
        "model_full": model_full,
        "model_selected": model_selected,
    }
    save_pickle(cache, path)
    return hydrate_fold_cache(cache)


def hydrate_fold_cache(cache: Mapping[str, Any]) -> dict[str, Any]:
    hydrated = dict(cache)
    dataset = load_dataset(str(cache["dataset_key"]))
    split: SplitBundle = cache["split"]
    preprocessor = cache["preprocessor"]
    hydrated["dataset"] = dataset
    hydrated["matrices"] = {
        name: preprocessor.transform_model(dataset.X.iloc[index]).astype(np.float32)
        for name, index in {
            "core_train": split.core_idx,
            "calibration": split.calibration_idx,
            "guard": split.guard_idx,
            "outer_test": split.test_idx,
        }.items()
    }
    return hydrated


def iter_fold_caches(require_existing: bool = False) -> Iterable[dict[str, Any]]:
    for dataset_key in DATASETS:
        dataset = load_dataset(dataset_key)
        y, _ = encode_target(dataset.y)
        for split in iter_splits(y):
            for model_name in MODELS:
                path = fold_cache_path(dataset_key, model_name, split.repeat, split.outer_fold)
                if require_existing and not path.exists():
                    raise FileNotFoundError("Run analysis_03_ml_performance.py first.")
                yield build_fold_cache(dataset, y, split, model_name)


def selected_matrices(cache: Mapping[str, Any]) -> dict[str, np.ndarray]:
    columns = cache["selected_columns"]
    return {name: matrix[:, columns] for name, matrix in cache["matrices"].items()}


def build_xai_cache(
    cache: Mapping[str, Any],
    bound: float | str | None = "auto",
) -> dict[str, Any]:
    split: SplitBundle = cache["split"]
    dataset: DatasetBundle = cache["dataset"]
    model_name = type(cache["model_selected"]).__name__
    canonical_model = {
        "LogisticRegression": "logistic_regression",
        "RandomForestClassifier": "random_forest",
        "GradientBoostingClassifier": "gradient_boosting",
    }[model_name]
    path = xai_cache_path(dataset.key, canonical_model, split.repeat, split.outer_fold)
    if bound == "auto" and path.exists():
        return load_pickle(path)
    matrices = selected_matrices(cache)
    names = cache["abc_result"].selected_features
    n_features = len(names)
    seed = stable_seed(split.seed, "xai")
    patterns = build_disjoint_mask_patterns(
        n_features,
        calibration_patterns=max(CAL_PATTERNS, n_features),
        guard_patterns=GUARD_PATTERNS,
        test_patterns=TEST_PATTERNS,
        random_state=seed,
    )
    model = cache["model_selected"]
    groups = cache["relative_groups"]
    behavior = {
        "calibration": measure_masked_model_behavior(
            model=model, X=matrices["calibration"], feature_names=names,
            feature_groups=groups, mask_patterns=patterns.calibration,
            n_perturbations=max(CAL_PERTURBATIONS, len(patterns.calibration)),
            random_state=seed + 1,
        ),
        "guard": measure_masked_model_behavior(
            model=model, X=matrices["guard"], feature_names=names,
            feature_groups=groups, mask_patterns=patterns.guard,
            n_perturbations=max(GUARD_PERTURBATIONS, len(patterns.guard)),
            random_state=seed + 2,
        ),
        "outer_test": measure_masked_model_behavior(
            model=model, X=matrices["outer_test"], feature_names=names,
            feature_groups=groups, mask_patterns=patterns.test,
            n_perturbations=max(TEST_PERTURBATIONS, len(patterns.test)),
            random_state=seed + 3,
        ),
    }
    optimization = optimize_behavior_reconstruction(
        cache["abc_result"].initial_weights,
        behavior["calibration"], behavior["guard"],
        optimizer_config(seed, bound),
    )
    value = {"patterns": patterns, "behavior": behavior, "optimization": optimization}
    if bound == "auto":
        save_pickle(value, path)
    return value


def fit_scale(weights: Mapping[str, float], behavior: BehaviorPerturbationResult) -> float:
    vector = np.asarray([weights[name] for name in weights], dtype=float)
    raw = behavior.unique_patterns @ vector
    denominator = float(np.dot(raw, raw))
    return 0.0 if denominator <= 1e-15 else max(0.0, float(np.dot(raw, behavior.pattern_mean_change) / denominator))


def normalize_weights(values: Mapping[str, float], feature_names: Sequence[str]) -> dict[str, float]:
    array = np.asarray([max(0.0, float(values.get(name, 0.0))) for name in feature_names])
    if array.sum() <= 1e-15:
        array = np.ones(len(feature_names), dtype=float)
    array /= array.sum()
    return {name: float(value) for name, value in zip(feature_names, array)}


def native_importance(cache: Mapping[str, Any]) -> dict[str, float]:
    model = cache["model_selected"]
    names = cache["abc_result"].selected_features
    groups = cache["relative_groups"]
    if hasattr(model, "coef_"):
        raw_columns = np.mean(np.abs(np.asarray(model.coef_)), axis=0)
    elif hasattr(model, "feature_importances_"):
        raw_columns = np.asarray(model.feature_importances_, dtype=float)
    else:
        # Defensive fallback for a custom model without a public importance.
        result = permutation_impacts(
            model=model,
            X=selected_matrices(cache)["core_train"],
            y=cache["labels"]["core_train"],
            feature_names=names,
            feature_groups=groups,
            metric="neg_log_loss",
            runs_per_feature=PERMUTATION_RUNS,
            random_state=stable_seed(cache["split"].seed, "native"),
        )
        return normalize_weights(result.impacts, names)
    values = {
        name: float(np.sum(raw_columns[np.asarray(groups[name], dtype=int)]))
        for name in names
    }
    return normalize_weights(values, names)


def permutation_weights(cache: Mapping[str, Any]) -> dict[str, float]:
    model = cache["model_selected"]
    X = selected_matrices(cache)["calibration"]
    y = cache["labels"]["calibration"]
    names = cache["abc_result"].selected_features
    groups = cache["relative_groups"]
    baseline_loss = float(
        log_loss(y, normalized_predict_proba(model, X), labels=model.classes_)
    )
    rng = np.random.default_rng(stable_seed(cache["split"].seed, "permutation"))
    impacts: dict[str, float] = {}
    for name in names:
        columns = np.asarray(groups[name], dtype=int)
        losses: list[float] = []
        for _ in range(PERMUTATION_RUNS):
            permuted = X.copy()
            order = rng.permutation(len(permuted))
            permuted[:, columns] = permuted[order][:, columns]
            losses.append(float(log_loss(
                y,
                normalized_predict_proba(model, permuted),
                labels=model.classes_,
            )))
        impacts[name] = max(0.0, float(np.mean(losses)) - baseline_loss)
    return normalize_weights(impacts, names)


def shap_mc_weights(cache: Mapping[str, Any]) -> dict[str, float]:
    """Model-agnostic interventional Monte-Carlo Shapley approximation."""
    model = cache["model_selected"]
    matrices = selected_matrices(cache)
    foreground = matrices["calibration"]
    background = matrices["core_train"]
    names = list(cache["abc_result"].selected_features)
    groups = cache["relative_groups"]
    rng = np.random.default_rng(stable_seed(cache["split"].seed, "shap"))
    sample_n = min(len(foreground), 128 if not FAST else 32)
    rows = rng.choice(len(foreground), size=sample_n, replace=False)
    foreground = foreground[rows]
    class_index = np.argmax(model.predict_proba(foreground), axis=1)
    totals = np.zeros(len(names), dtype=float)
    for _ in range(SHAP_PERMUTATIONS):
        order = rng.permutation(len(names))
        donors = background[rng.integers(0, len(background), size=sample_n)].copy()
        current = donors
        previous = model.predict_proba(current)[np.arange(sample_n), class_index]
        for feature_index in order:
            group = np.asarray(groups[names[feature_index]], dtype=int)
            current = current.copy()
            current[:, group] = foreground[:, group]
            updated = model.predict_proba(current)[np.arange(sample_n), class_index]
            totals[feature_index] += float(np.mean(np.abs(updated - previous)))
            previous = updated
    totals /= SHAP_PERMUTATIONS
    return normalize_weights(dict(zip(names, totals)), names)


def all_method_weights(cache: Mapping[str, Any], xai: Mapping[str, Any]) -> dict[str, dict[str, float]]:
    optimization = xai["optimization"]
    names = cache["abc_result"].selected_features
    return {
        "abc_initial": normalize_weights(optimization.initial_weights, names),
        "abc_faithopt": normalize_weights(optimization.final_weights, names),
        "permutation": permutation_weights(cache),
        "shap_mc": shap_mc_weights(cache),
        "native_importance": native_importance(cache),
    }


def conditional_deletion(
    cache: Mapping[str, Any], weights: Mapping[str, float], top_k: int = TOP_K
) -> tuple[float, float, int]:
    """Deletion audit using nearest core donors conditional on remaining features."""
    model = cache["model_selected"]
    matrices = selected_matrices(cache)
    core = matrices["core_train"]
    test = matrices["outer_test"]
    names = list(cache["abc_result"].selected_features)
    groups = cache["relative_groups"]
    ordered = sorted(names, key=lambda name: weights[name], reverse=True)
    k = min(top_k, len(ordered))
    rng = np.random.default_rng(stable_seed(cache["split"].seed, "conditional_audit"))
    if len(core) > DONOR_ROWS:
        core = core[rng.choice(len(core), size=DONOR_ROWS, replace=False)]
    if len(test) > AUDIT_ROWS:
        test = test[rng.choice(len(test), size=AUDIT_ROWS, replace=False)]
    reference = model.predict_proba(test)
    original_class = np.argmax(reference, axis=1)
    original_probability = reference[np.arange(len(test)), original_class]
    working = test.copy()
    drops = [0.0]
    removed: list[int] = []
    for name in ordered[:k]:
        removed.extend(groups[name])
        remaining = np.asarray([i for i in range(test.shape[1]) if i not in set(removed)], dtype=int)
        if len(remaining):
            # Chunked squared distances avoid a large n_test x n_core x p tensor.
            donor_index = np.empty(len(test), dtype=int)
            chunk_size = 128
            for start in range(0, len(test), chunk_size):
                stop = min(start + chunk_size, len(test))
                query = working[start:stop, remaining]
                distances = (
                    np.sum(query**2, axis=1)[:, None]
                    + np.sum(core[:, remaining] ** 2, axis=1)[None, :]
                    - 2.0 * query @ core[:, remaining].T
                )
                donor_index[start:stop] = np.argmin(distances, axis=1)
        else:
            donor_index = np.arange(len(test)) % len(core)
        group = np.asarray(groups[name], dtype=int)
        working[:, group] = core[donor_index][:, group]
        probabilities = model.predict_proba(working)[np.arange(len(test)), original_class]
        drops.append(float(np.mean(original_probability - probabilities)))
    x = np.linspace(0.0, 1.0, len(drops))
    auc = float(trapezoid(drops, x))
    return auc, float(drops[-1]), k


def model_key(cache: Mapping[str, Any]) -> str:
    return {
        "LogisticRegression": "logistic_regression",
        "RandomForestClassifier": "random_forest",
        "GradientBoostingClassifier": "gradient_boosting",
    }[type(cache["model_selected"]).__name__]


def base_row(cache: Mapping[str, Any]) -> dict[str, Any]:
    split: SplitBundle = cache["split"]
    return {
        "dataset": cache["dataset"].key,
        "model": model_key(cache),
        "repeat": split.repeat,
        "outer_fold": split.outer_fold,
    }


def analysis_01() -> Path:
    rows: list[dict[str, Any]] = []
    progress = AnalysisProgress(
        1, "dataset summary", len(DATASETS), "datasets",
        expected_rows=len(DATASETS), output_filename="dataset_summary.tsv",
    )
    for index, key in enumerate(DATASETS, 1):
        unit_started = progress.start(index, key)
        dataset = load_dataset(key)
        categorical = set(dataset.categorical_features)
        counts = dataset.y.astype(str).value_counts(normalize=True)
        rows.append(
            {
                "dataset": key,
                "n_samples": len(dataset.X),
                "n_features": dataset.X.shape[1],
                "n_numeric": sum(column not in categorical for column in dataset.X),
                "n_categorical": len(categorical),
                "n_classes": dataset.y.nunique(),
                "minority_ratio": float(counts.min()),
                "missing_pct": float(dataset.X.isna().mean().mean() * 100.0),
                "uci_id": dataset.uci_id,
            }
        )
        checkpoint_tsv(rows, "dataset_summary.tsv")
        progress.done(index, unit_started, len(rows))
    path = write_tsv(rows, "dataset_summary.tsv")
    progress.finish(len(rows), path)
    return path


if __name__ == "__main__":
    analysis_01()
