#!/usr/bin/env python3
"""Analysis 06: optimization-independent conditional deletion audit."""
from __future__ import annotations

from analysis_01_dataset_summary import (
    AnalysisProgress,
    DATASETS,
    MODELS,
    N_REPEATS,
    N_SPLITS,
    all_method_weights,
    base_row,
    build_xai_cache,
    checkpoint_tsv,
    conditional_deletion,
    iter_fold_caches,
    write_tsv,
)


def main() -> None:
    rows = []
    total_folds = len(DATASETS) * len(MODELS) * N_REPEATS * N_SPLITS
    methods_per_fold = 5
    expected_rows = total_folds * methods_per_fold
    progress = AnalysisProgress(
        6, "conditional deletion audit", total_folds,
        "dataset-model-fold units", expected_rows=expected_rows,
        output_filename="conditional_audit.tsv",
    )
    for fold_number, cache in enumerate(iter_fold_caches(require_existing=True), 1):
        common = base_row(cache)
        unit_started = progress.start(
            fold_number,
            f"{common['dataset']} | {common['model']} | "
            f"r{common['repeat']}f{common['outer_fold']}",
        )
        xai = build_xai_cache(cache)
        methods = all_method_weights(cache, xai)
        for method_number, (method, weights) in enumerate(methods.items(), 1):
            progress.step(f"conditional deletion {method_number}/{len(methods)}: {method}")
            auc, final_drop, k = conditional_deletion(cache, weights)
            rows.append({
                **common, "method": method, "top_k": k,
                "deletion_auc": auc, "final_probability_drop": final_drop,
            })
        checkpoint_tsv(rows, "conditional_audit.tsv")
        progress.done(fold_number, unit_started, len(rows))
    if len(rows) != expected_rows:
        raise RuntimeError(f"Expected {expected_rows} rows, produced {len(rows)}.")
    unique_keys = {
        (row["dataset"], row["model"], row["repeat"], row["outer_fold"], row["method"])
        for row in rows
    }
    if len(unique_keys) != expected_rows:
        raise RuntimeError("Duplicate dataset/model/fold/method rows detected.")
    path = write_tsv(rows, "conditional_audit.tsv")
    progress.finish(len(rows), path)


if __name__ == "__main__":
    main()
