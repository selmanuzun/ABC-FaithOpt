#!/usr/bin/env python3
"""Analysis 04: fold-level ABC feature-value rules and final faithful weights."""
from __future__ import annotations

from itertools import combinations

from analysis_01_dataset_summary import (
    AnalysisProgress,
    DATASETS,
    MODELS,
    N_REPEATS,
    N_SPLITS,
    base_row,
    build_xai_cache,
    checkpoint_tsv,
    iter_fold_caches,
    write_tsv,
)


def main() -> None:
    rows = []
    total_folds = len(DATASETS) * len(MODELS) * N_REPEATS * N_SPLITS
    progress = AnalysisProgress(
        4, "selected features and faithful weights", total_folds,
        "dataset-model-fold units", output_filename="selected_features.tsv",
    )
    for fold_number, cache in enumerate(iter_fold_caches(require_existing=True), 1):
        common = base_row(cache)
        unit_started = progress.start(
            fold_number,
            f"{common['dataset']} | {common['model']} | "
            f"r{common['repeat']}f{common['outer_fold']}",
        )
        progress.step("building or loading the XAI cache")
        xai = build_xai_cache(cache)
        optimization = xai["optimization"]
        abc_result = cache["abc_result"]
        member_sets = [set(features) for features in abc_result.ensemble_member_features]
        member_jaccards = [
            len(left & right) / max(len(left | right), 1)
            for left, right in combinations(member_sets, 2)
        ]
        member_jaccard = (
            sum(member_jaccards) / len(member_jaccards)
            if member_jaccards else 1.0
        )
        rules = {rule.feature: rule for rule in abc_result.rules}
        order = sorted(
            abc_result.selected_features,
            key=lambda name: optimization.final_weights[name], reverse=True,
        )
        for rank, feature in enumerate(order, 1):
            rule = rules[feature]
            rows.append({
                **common,
                "feature": feature,
                "rank": rank,
                "abc_weight": optimization.initial_weights[feature],
                "faithful_weight": optimization.final_weights[feature],
                "sensitivity_mode": optimization.requested_sensitivity_mode,
                "selected_sensitivity_pct": optimization.selected_sensitivity_pct,
                "sensitivity_boundary_hit": optimization.sensitivity_boundary_hit,
                "optimization_accepted": optimization.accepted,
                "selection_frequency": abc_result.selection_frequency.get(
                    feature, 1.0
                ),
                "abc_ensemble_runs": abc_result.ensemble_runs,
                "abc_consensus_used": abc_result.consensus_used,
                "abc_member_jaccard": member_jaccard,
                "abc_consensus_fitness": abc_result.consensus_fitness,
                "abc_reference_fitness": abc_result.reference_fitness,
                "rule_operator": rule.operator,
                "rule_value": rule.value,
                "favored_class": rule.favored_class,
            })
        checkpoint_tsv(rows, "selected_features.tsv")
        progress.done(fold_number, unit_started, len(rows))
    path = write_tsv(rows, "selected_features.tsv")
    progress.finish(len(rows), path)


if __name__ == "__main__":
    main()
