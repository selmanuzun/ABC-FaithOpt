#!/usr/bin/env python3
"""Analysis 08: fixed versus ABC-selected faithfulness sensitivity."""
from __future__ import annotations

import time

import numpy as np
import pandas as pd

from analysis_01_dataset_summary import (
    AUTO_SENSITIVITY_MAX,
    DATASETS,
    MODELS,
    N_REPEATS,
    N_SPLITS,
    OUTPUT_DIR,
    base_row,
    build_xai_cache,
    checkpoint_tsv,
    evaluate_behavior_reconstruction,
    iter_fold_caches,
    optimize_behavior_reconstruction,
    optimizer_config,
    stable_seed,
    write_tsv,
)


MODES: tuple[tuple[str, float | str, float | None], ...] = (
    ("fixed_30", 30.0, None),
    ("fixed_50", 50.0, None),
    ("auto_max_80", "auto", 80.0),
    ("auto_max_90", "auto", 90.0),
    ("auto_max_100", "auto", 100.0),
)


def format_duration(seconds: float) -> str:
    total = max(0, int(round(seconds)))
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def main() -> None:
    key_columns = ["dataset", "model", "repeat", "outer_fold"]
    output_path = OUTPUT_DIR / "weight_sensitivity.tsv"
    rows: list[dict[str, object]] = []
    completed_keys: set[tuple[object, ...]] = set()
    if output_path.exists():
        previous = pd.read_csv(output_path, sep="\t", na_values=["NA"])
        required = {
            *key_columns,
            "sensitivity_mode",
            "selected_sensitivity_pct",
            "auto_max_sensitivity_pct",
        }
        if required.issubset(previous.columns):
            expected_modes = {label for label, _, _ in MODES}
            retained = []
            for key, group in previous.groupby(key_columns, sort=False):
                if (
                    len(group) == len(MODES)
                    and set(group["sensitivity_mode"]) == expected_modes
                ):
                    retained.append(group)
                    completed_keys.add(tuple(key))
            if retained:
                rows = pd.concat(retained, ignore_index=True).to_dict("records")
    total_folds = len(DATASETS) * len(MODELS) * N_REPEATS * N_SPLITS
    expected_rows = total_folds * len(MODES)
    started = time.perf_counter()
    completed = len(completed_keys)
    initial_completed = completed
    print(
        "ABC-FaithOpt Analysis 08 — sensitivity hyperparameter audit\n"
        f"Plan: {total_folds} fold-model × {len(MODES)} modes "
        f"= {expected_rows} measurements\n"
        f"Output: {output_path}"
    )
    if completed:
        print(
            f"Resume: {completed}/{total_folds} fold-model already complete; "
            f"{total_folds - completed} remain."
        )
    for cache in iter_fold_caches(require_existing=True):
        common = base_row(cache)
        cache_key = tuple(common[column] for column in key_columns)
        if cache_key in completed_keys:
            continue
        fold_started = time.perf_counter()
        print(
            f"[{completed + 1:02d}/{total_folds:02d}] START | "
            f"{common['dataset']} | {common['model']} | "
            f"r{common['repeat']}f{common['outer_fold']}",
            flush=True,
        )
        auto_xai = build_xai_cache(cache)
        initial = auto_xai["optimization"].initial_weights
        for mode_index, (label, bound, auto_ceiling) in enumerate(MODES, 1):
            print(
                f"             STEP | mode {mode_index}/{len(MODES)}: {label}",
                flush=True,
            )
            mode_started = time.perf_counter()
            if bound == "auto" and auto_ceiling == AUTO_SENSITIVITY_MAX:
                result = auto_xai["optimization"]
            else:
                result = optimize_behavior_reconstruction(
                    initial,
                    auto_xai["behavior"]["calibration"],
                    auto_xai["behavior"]["guard"],
                    optimizer_config(
                        stable_seed(cache["split"].seed, "sensitivity", label),
                        bound,
                        auto_max_pct=auto_ceiling,
                    ),
                )
            test = evaluate_behavior_reconstruction(
                result.final_weights,
                result.final_behavior_scale,
                auto_xai["behavior"]["outer_test"],
            )
            rows.append({
                **common,
                "sensitivity_mode": label,
                "requested_sensitivity_pct": (
                    float(bound) if isinstance(bound, float) else np.nan
                ),
                "auto_max_sensitivity_pct": (
                    float(auto_ceiling) if auto_ceiling is not None else np.nan
                ),
                "selected_sensitivity_pct": result.selected_sensitivity_pct,
                "sensitivity_boundary_hit": result.sensitivity_boundary_hit,
                "calibration_initial_r2": result.calibration_initial.r2,
                "calibration_candidate_r2": result.calibration_candidate.r2,
                "guard_initial_r2": result.guard_initial.r2,
                "guard_candidate_r2": result.guard_candidate.r2,
                "guard_final_r2": result.guard_final.r2,
                "guard_initial_nmae": result.guard_initial.normalized_mae,
                "guard_candidate_nmae": result.guard_candidate.normalized_mae,
                "guard_improvement": result.guard_improvement,
                "guard_nmae_change": result.guard_nmae_change,
                "test_r2": test.r2,
                "test_nmae": test.normalized_mae,
                "mean_weight_change_pct": result.mean_weight_change_pct,
                "max_weight_change_pct": result.max_weight_change_pct,
                "accepted": result.accepted,
                "acceptance_reason": result.reason,
                "optimizer_success": result.optimizer_success,
                "auto_search_evaluations": result.sensitivity_search_evaluations,
                "runtime_sec": time.perf_counter() - mode_started,
            })
        completed += 1
        checkpoint_tsv(rows, "weight_sensitivity.tsv")
        elapsed = time.perf_counter() - started
        newly_completed = completed - initial_completed
        eta = elapsed / newly_completed * (total_folds - completed)
        print(
            f"[{completed:02d}/{total_folds:02d}] DONE | "
            f"fold={format_duration(time.perf_counter() - fold_started)} | "
            f"ETA={format_duration(eta)} | rows={len(rows)}/{expected_rows}",
            flush=True,
        )

    if len(rows) != expected_rows:
        raise RuntimeError("Sensitivity audit produced an unexpected row count.")
    path = write_tsv(rows, "weight_sensitivity.tsv")
    print(
        f"Analysis 08 complete | rows={len(rows)} | "
        f"total_time={format_duration(time.perf_counter() - started)}\n"
        f"Output: {path}",
        flush=True,
    )


if __name__ == "__main__":
    main()
