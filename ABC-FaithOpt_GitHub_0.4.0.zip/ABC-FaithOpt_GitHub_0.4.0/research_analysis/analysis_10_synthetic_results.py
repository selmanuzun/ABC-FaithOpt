#!/usr/bin/env python3
"""Analysis 10: additive ground truth and controlled-interaction limits."""
from __future__ import annotations

import os

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression

from analysis_01_dataset_summary import (
    AnalysisProgress,
    CAL_PATTERNS,
    CAL_PERTURBATIONS,
    GUARD_PATTERNS,
    GUARD_PERTURBATIONS,
    TEST_PATTERNS,
    TEST_PERTURBATIONS,
    FAST,
    build_disjoint_mask_patterns,
    checkpoint_tsv,
    evaluate_behavior_reconstruction,
    measure_masked_model_behavior,
    normalize_weights,
    optimize_behavior_reconstruction,
    optimizer_config,
    run_abc,
    safe_spearman,
    selected_layout,
    stable_seed,
    write_tsv,
)


def main() -> None:
    replicates = int(os.environ.get("ABCFAITH_SYNTHETIC_REPLICATES", "3" if FAST else "20"))
    n_samples = 600 if FAST else 2500
    true = np.asarray([2.0, 1.5, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    true_norm = np.abs(true) / np.abs(true).sum()
    rows = []
    scenarios = [("additive", 0.0), ("interaction", 0.5), ("interaction", 1.0), ("interaction", 2.0), ("interaction", 4.0)]
    total_tasks = len(scenarios) * replicates
    expected_rows = total_tasks * 3
    progress = AnalysisProgress(
        10, "synthetic ground-truth experiments", total_tasks,
        "scenario-replicate tasks", expected_rows=expected_rows,
        output_filename="synthetic_results.tsv",
    )
    task_number = 0
    for scenario, gamma in scenarios:
        for replicate in range(1, replicates + 1):
            task_number += 1
            unit_started = progress.start(
                task_number,
                f"scenario={scenario} | gamma={gamma:g} | replicate={replicate}",
            )
            seed = stable_seed("synthetic", scenario, gamma, replicate)
            rng = np.random.default_rng(seed)
            X_array = rng.normal(size=(n_samples, len(true)))
            logits = X_array @ true + gamma * X_array[:, 0] * X_array[:, 1]
            probability = 1.0 / (1.0 + np.exp(-np.clip(logits, -25, 25)))
            y = rng.binomial(1, probability).astype(int)
            X = pd.DataFrame(X_array, columns=[f"x{i+1}" for i in range(len(true))])
            indices = rng.permutation(n_samples)
            n_core = int(0.56 * n_samples)
            n_cal = int(0.12 * n_samples)
            n_guard = int(0.12 * n_samples)
            core = indices[:n_core]
            calibration = indices[n_core:n_core + n_cal]
            guard = indices[n_core + n_cal:n_core + n_cal + n_guard]
            test = indices[n_core + n_cal + n_guard:]
            progress.step("running ABC feature-value search")
            prep, abc = run_abc(X.iloc[core], y[core], (), seed)
            columns, groups = selected_layout(prep, abc)
            matrices = {
                name: prep.transform_model(X.iloc[index])[:, columns]
                for name, index in {
                    "core": core, "calibration": calibration,
                    "guard": guard, "test": test,
                }.items()
            }
            if gamma == 0.0:
                model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)
            else:
                model = HistGradientBoostingClassifier(max_iter=80 if FAST else 200, random_state=seed)
            model.fit(matrices["core"], y[core])
            patterns = build_disjoint_mask_patterns(
                len(abc.selected_features),
                calibration_patterns=max(CAL_PATTERNS, len(abc.selected_features)),
                guard_patterns=GUARD_PATTERNS,
                test_patterns=TEST_PATTERNS,
                random_state=seed + 1,
            )
            behavior = {
                "calibration": measure_masked_model_behavior(
                    model=model, X=matrices["calibration"], feature_names=abc.selected_features,
                    feature_groups=groups, mask_patterns=patterns.calibration,
                    n_perturbations=max(CAL_PERTURBATIONS, len(patterns.calibration)), random_state=seed + 2,
                ),
                "guard": measure_masked_model_behavior(
                    model=model, X=matrices["guard"], feature_names=abc.selected_features,
                    feature_groups=groups, mask_patterns=patterns.guard,
                    n_perturbations=max(GUARD_PERTURBATIONS, len(patterns.guard)), random_state=seed + 3,
                ),
                "test": measure_masked_model_behavior(
                    model=model, X=matrices["test"], feature_names=abc.selected_features,
                    feature_groups=groups, mask_patterns=patterns.test,
                    n_perturbations=max(TEST_PERTURBATIONS, len(patterns.test)), random_state=seed + 4,
                ),
            }
            progress.step("optimizing faithful and uniform explanations")
            full = optimize_behavior_reconstruction(
                abc.initial_weights, behavior["calibration"], behavior["guard"],
                optimizer_config(seed + 5),
            )
            uniform = {name: 1.0 / len(abc.selected_features) for name in abc.selected_features}
            uniform_result = optimize_behavior_reconstruction(
                uniform, behavior["calibration"], behavior["guard"], optimizer_config(seed + 6),
            )
            variants = {
                "abc_initial": (full.initial_weights, full.initial_behavior_scale),
                "abc_faithopt": (full.final_weights, full.final_behavior_scale),
                "uniform_optimizer": (uniform_result.final_weights, uniform_result.final_behavior_scale),
            }
            for method, (weights, scale) in variants.items():
                test_metrics = evaluate_behavior_reconstruction(weights, scale, behavior["test"])
                estimated = np.zeros(len(true), dtype=float)
                for name, value in normalize_weights(weights, abc.selected_features).items():
                    estimated[int(name[1:]) - 1] = value
                top_true = set(np.argsort(true_norm)[-3:])
                top_found = set(np.argsort(estimated)[-3:])
                corr = safe_spearman(true_norm, estimated)
                rows.append({
                    "scenario": scenario,
                    "interaction_gamma": gamma,
                    "replicate": replicate,
                    "method": method,
                    "weight_mae": float(np.mean(np.abs(estimated - true_norm))),
                    "topk_recall": len(top_true & top_found) / 3.0,
                    "weight_rank_corr": float(corr),
                    "test_r2": test_metrics.r2,
                })
            checkpoint_tsv(rows, "synthetic_results.tsv")
            progress.done(task_number, unit_started, len(rows))
    path = write_tsv(rows, "synthetic_results.tsv")
    progress.finish(len(rows), path)


if __name__ == "__main__":
    main()
