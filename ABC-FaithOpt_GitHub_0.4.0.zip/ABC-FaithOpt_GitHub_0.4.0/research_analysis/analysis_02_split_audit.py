#!/usr/bin/env python3
"""Analysis 02: nested-CV row/mask separation audit."""
from __future__ import annotations

import numpy as np

from analysis_01_dataset_summary import (
    AnalysisProgress,
    DATASETS,
    CAL_PATTERNS,
    GUARD_PATTERNS,
    TEST_PATTERNS,
    build_disjoint_mask_patterns,
    checkpoint_tsv,
    encode_target,
    iter_splits,
    load_dataset,
    N_REPEATS,
    N_SPLITS,
    stable_seed,
    write_tsv,
)


def main() -> None:
    rows = []
    expected_rows = len(DATASETS) * N_REPEATS * N_SPLITS
    progress = AnalysisProgress(
        2, "split and leakage audit", len(DATASETS), "datasets",
        expected_rows=expected_rows, output_filename="split_audit.tsv",
    )
    for dataset_number, dataset_key in enumerate(DATASETS, 1):
        unit_started = progress.start(dataset_number, dataset_key)
        dataset = load_dataset(dataset_key)
        y, _ = encode_target(dataset.y)
        n_pattern_features = min(7, dataset.X.shape[1])
        for split in iter_splits(y):
            blocks = [split.core_idx, split.calibration_idx, split.guard_idx, split.test_idx]
            row_overlap = any(
                np.intersect1d(blocks[i], blocks[j]).size > 0
                for i in range(len(blocks)) for j in range(i + 1, len(blocks))
            )
            patterns = build_disjoint_mask_patterns(
                n_pattern_features,
                calibration_patterns=max(CAL_PATTERNS, n_pattern_features),
                guard_patterns=GUARD_PATTERNS,
                test_patterns=TEST_PATTERNS,
                random_state=stable_seed(split.seed, "mask_audit"),
            )
            signatures = [
                {tuple(row) for row in matrix}
                for matrix in (patterns.calibration, patterns.guard, patterns.test)
            ]
            mask_overlap = bool(
                signatures[0] & signatures[1]
                or signatures[0] & signatures[2]
                or signatures[1] & signatures[2]
            )
            rows.append({
                "dataset": dataset_key,
                "repeat": split.repeat,
                "outer_fold": split.outer_fold,
                "split_seed": split.seed,
                "n_core": len(split.core_idx),
                "n_calibration": len(split.calibration_idx),
                "n_guard": len(split.guard_idx),
                "n_test": len(split.test_idx),
                "row_overlap": row_overlap,
                "mask_overlap": mask_overlap,
                "leakage_check": "passed" if not row_overlap and not mask_overlap else "failed",
            })
        checkpoint_tsv(rows, "split_audit.tsv")
        progress.done(dataset_number, unit_started, len(rows))
    path = write_tsv(rows, "split_audit.tsv")
    progress.finish(len(rows), path)


if __name__ == "__main__":
    main()
