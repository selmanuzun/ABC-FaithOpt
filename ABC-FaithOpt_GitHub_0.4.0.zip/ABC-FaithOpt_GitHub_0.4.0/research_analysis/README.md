# ABC-FaithOpt Research Analysis Scripts

This directory contains the 13 study-analysis scripts used for the ABC-FaithOpt v0.4.0 evaluation. The scripts generate tab-separated numerical outputs and do not generate figures. Figure-generation code is intentionally excluded from this repository package.

## Analysis sequence

Run all analyses from the repository root:

```bash
python research_analysis/run_all_analyses.py
```

The runner executes the analyses in numerical order, streams subprocess output to the terminal, updates `analysis_run_report.tsv` after each stage, and continues after failures by default.

Preview the execution plan without running analyses:

```bash
python research_analysis/run_all_analyses.py --dry-run
```

Stop at the first failure:

```bash
python research_analysis/run_all_analyses.py --stop-on-error
```

Run only a selected interval:

```bash
python research_analysis/run_all_analyses.py --start 4 --end 13
```

Individual scripts can also be executed directly:

```bash
python research_analysis/analysis_01_dataset_summary.py
python research_analysis/analysis_02_split_audit.py
python research_analysis/analysis_03_ml_performance.py
python research_analysis/analysis_04_selected_features.py
python research_analysis/analysis_05_xai_faithfulness.py
python research_analysis/analysis_06_conditional_audit.py
python research_analysis/analysis_07_ablation_results.py
python research_analysis/analysis_08_weight_sensitivity.py
python research_analysis/analysis_09_reliability_results.py
python research_analysis/analysis_10_synthetic_results.py
python research_analysis/analysis_11_sanity_check.py
python research_analysis/analysis_12_runtime_results.py
python research_analysis/analysis_13_statistical_results.py
```

## Study design

The main research protocol uses six UCI classification datasets:

```text
breast_cancer, adult, dry_bean, bank_marketing, spambase, landsat
```

and three classifier families:

```text
logistic_regression, random_forest, gradient_boosting
```

The principal design uses:

- 3 outer stratified folds and 1 repeat;
- 3 inner stratified folds for model selection;
- fold-specific preprocessing;
- 7-run stability-aware ABC selection using training information only;
- 3 to 7 selected original features;
- separate core-training, calibration, validation-guard, and outer-test roles;
- automatic sensitivity selection on calibration only over 10% to 100%;
- validation-guard acceptance requiring at least 0.01 R-squared improvement and no increase in normalized MAE;
- untouched outer-test evaluation after the accept/revert decision;
- at most 8 outer-fold worker processes for the computationally intensive predictive analysis;
- one estimator-level job per worker by default to avoid nested CPU oversubscription.

The common selected-feature comparison evaluates ABC initial weights, final ABC-FaithOpt weights, permutation importance, Monte Carlo SHAP, and native model importance.

## Data acquisition

Raw UCI archives are not included in the repository. The analysis scripts download the official UCI archives on first use and store them in the configured local data cache.

## Output and cache locations

By default, final TSV files are written to:

```text
analysis_outputs/
```

Reusable fold and XAI objects are stored under a protocol-specific cache path:

```text
analysis_cache/<protocol_id>/
```

If the project is executed under WSL from a mounted Windows or cloud drive, the analysis code may redirect long-running caches and outputs to a local WSL cache directory to reduce the risk of mount interruptions. The script reports the effective paths at runtime.

## Environment variables

| Variable | Default | Purpose |
|---|---:|---|
| `ABCFAITH_OUTPUT_DIR` | `analysis_outputs` | TSV output directory |
| `ABCFAITH_ANALYSIS_CACHE` | `analysis_cache` | Fold/XAI cache directory |
| `ABCFAITH_DATA_CACHE` | `analysis_cache/uci` | UCI archive cache |
| `ABCFAITH_DATASETS` | six datasets | Comma-separated dataset filter |
| `ABCFAITH_MODELS` | three models | Comma-separated model filter |
| `ABCFAITH_SEED` | `20260813` | Base random seed |
| `ABCFAITH_ANALYSIS_WORKERS` | `8` | Parallel outer-fold workers for Analysis 03 |
| `ABCFAITH_MODEL_N_JOBS` | `1` | Estimator-level parallelism per worker |
| `ABCFAITH_ABC_STABILITY_RUNS` | `7` | ABC ensemble runs per feature-selection operation |
| `ABCFAITH_ABC_STABILITY_SUBSAMPLE` | `0.80` | Training subsample fraction for stability runs |
| `ABCFAITH_ABC_STABILITY_FREQUENCY_WEIGHT` | `0.75` | Selection-frequency weight in consensus scoring |
| `ABCFAITH_ABC_STABILITY_FITNESS_TOLERANCE` | `0.05` | Full-core ABC fitness tolerance for consensus acceptance |
| `ABCFAITH_AUTO_SENSITIVITY_MAX` | `100` | Maximum calibration-only automatic sensitivity |
| `ABCFAITH_AUDIT_ROWS` | `1000` | Conditional-deletion outer-test sample cap |
| `ABCFAITH_DONOR_ROWS` | `3000` | Conditional donor-pool cap |
| `ABCFAITH_SYNTHETIC_REPLICATES` | `20` | Synthetic replicates per interaction condition |

Changing `ABCFAITH_ANALYSIS_WORKERS` affects runtime only. The fold counts, dataset set, perturbation budgets, and optimization settings should remain fixed when reproducing the reported study protocol.

## Fast validation mode

A reduced mode is available for checking installation and execution paths. It must not be used to reproduce the manuscript results.

Linux/macOS:

```bash
ABCFAITH_FAST=1 \
ABCFAITH_DATASETS=breast_cancer \
ABCFAITH_MODELS=random_forest \
python research_analysis/analysis_03_ml_performance.py
```

PowerShell:

```powershell
$env:ABCFAITH_FAST="1"
$env:ABCFAITH_DATASETS="breast_cancer"
$env:ABCFAITH_MODELS="random_forest"
python research_analysis/analysis_03_ml_performance.py
```

Remove `ABCFAITH_FAST` before running the full protocol.

## Generated study outputs

The analysis sequence generates:

```text
dataset_summary.tsv
split_audit.tsv
ml_performance.tsv
selected_features.tsv
xai_faithfulness.tsv
conditional_audit.tsv
ablation_results.tsv
weight_sensitivity.tsv
reliability_results.tsv
synthetic_results.tsv
sanity_check.tsv
runtime_results.tsv
statistical_results.tsv
analysis_run_report.tsv
```

### Analysis 01 — Dataset summary

Summarizes the six benchmark datasets and provides shared data-loading utilities used by later analyses.

### Analysis 02 — Split audit

Checks row-level role separation and perturbation-mask separation across the experimental data roles.

### Analysis 03 — Predictive performance

Evaluates full-feature and ABC-selected classifiers under nested cross-validation. This is the most computationally expensive stage and supports checkpoint-based continuation.

### Analysis 04 — Selected features

Records selected original features, feature-value rules, initial/final weights, selection frequencies, and stability-consensus metadata.

### Analysis 05 — XAI faithfulness

Evaluates ABC initial, ABC-FaithOpt, permutation importance, Monte Carlo SHAP, and native model importance under the common selected-feature protocol.

### Analysis 06 — Conditional deletion audit

Provides an optimization-independent conditional deletion assessment of ranked global features.

### Analysis 07 — Component ablation

Compares the full method, ABC-only weights, and uniform-initialization optimizer variants on the same ABC-selected feature set.

### Analysis 08 — Sensitivity audit

Evaluates fixed 30%, fixed 50%, auto-80, auto-90, and auto-100 sensitivity settings across the full dataset-model-fold design.

### Analysis 09 — Reliability and stability

Summarizes predictive generalization gaps, XAI generalization gaps, cross-fold feature-set agreement, within-ensemble ABC agreement, weight variability, and sensitivity variability.

### Analysis 10 — Synthetic ground truth

Evaluates weight and feature recovery under controlled additive and interaction conditions.

### Analysis 11 — Shuffled-label sanity check

Repeats the explanation pipeline after core-training label randomization for a predefined subset of datasets and the random-forest classifier.

### Analysis 12 — Runtime benchmark

Measures explanation-only runtime for the common explanation methods and separately measures selected-model training and ABC-FaithOpt end-to-end XAI runtime. Runtime results are descriptive because the end-to-end scope does not provide a common pairwise comparison across methods.

### Analysis 13 — Statistical results

Aggregates fold-level observations to dataset-model blocks and performs the prespecified paired inferential analyses, including predictive non-inferiority, Friedman tests, Wilcoxon signed-rank comparisons, bootstrap confidence intervals, Holm correction, and rank-biserial effect sizes where defined.

## Reproducibility constraints

- Outer-test data must not feed back into preprocessing, feature selection, model tuning, sensitivity selection, explanation optimization, or guard acceptance.
- Sensitivity is selected using calibration behavior only.
- The validation guard is used only for the accept/revert decision.
- Outer-test perturbations are used only for final reporting.
- Methods within a comparison use the same outer folds and behavioral evaluation objects.
- Dataset-model blocks, rather than individual folds, are the inferential units in Analysis 13.
- Runtime measurements are executed serially.

## Figure code

Figure-generation scripts are intentionally not included in this package. Numerical figure inputs are available in `analysis_outputs/`.
