#!/usr/bin/env python3
"""Analysis 13: paired block-level inference from the preceding TSV files."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import friedmanchisquare, rankdata, wilcoxon

from analysis_01_dataset_summary import (
    AnalysisProgress,
    BASE_SEED,
    checkpoint_tsv,
    read_tsv,
    write_tsv,
)


BLOCK = ["dataset", "model"]
RNG = np.random.default_rng(BASE_SEED + 1300)
ML_NONINFERIORITY_MARGIN = -0.02


def bootstrap_ci(values: np.ndarray, n_boot: int = 5000) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    if len(values) == 0:
        return np.nan, np.nan
    simulations = np.asarray([
        np.mean(RNG.choice(values, size=len(values), replace=True)) for _ in range(n_boot)
    ])
    return tuple(np.quantile(simulations, [0.025, 0.975]))


def rank_biserial(differences: np.ndarray) -> float:
    differences = np.asarray(differences, dtype=float)
    differences = differences[np.abs(differences) > 1e-15]
    if not len(differences):
        return 0.0
    ranks = rankdata(np.abs(differences))
    positive = float(ranks[differences > 0].sum())
    negative = float(ranks[differences < 0].sum())
    return (positive - negative) / max(positive + negative, 1e-15)


def paired_rows(analysis, metric, pivot, reference, competitors):
    rows = []
    for competitor in competitors:
        paired = pivot[[reference, competitor]].dropna()
        differences = paired[reference].to_numpy() - paired[competitor].to_numpy()
        if len(differences) == 0:
            continue
        try:
            p_value = float(wilcoxon(differences, zero_method="zsplit").pvalue)
        except ValueError:
            p_value = 1.0
        low, high = bootstrap_ci(differences)
        rows.append({
            "analysis": analysis, "metric": metric,
            "comparison": f"{reference}_vs_{competitor}",
            "n_blocks": len(differences), "estimate": float(np.mean(differences)),
            "ci_low": low, "ci_high": high, "p_raw": p_value,
            "p_holm": np.nan, "effect_size": rank_biserial(differences),
            "decision": "descriptive",
        })
    return rows


def omnibus_row(analysis, metric, pivot):
    complete = pivot.dropna()
    if complete.shape[0] < 2 or complete.shape[1] < 3:
        return None
    statistic, p_value = friedmanchisquare(*[complete[column] for column in complete])
    return {
        "analysis": analysis, "metric": metric, "comparison": "all_methods",
        "n_blocks": len(complete), "estimate": float(statistic),
        "ci_low": np.nan, "ci_high": np.nan, "p_raw": float(p_value),
        "p_holm": np.nan, "effect_size": np.nan,
        "decision": "supported" if p_value < 0.05 else "not_supported",
    }


def block_pivot(frame, value, method):
    medians = frame.groupby([*BLOCK, method], as_index=False)[value].median()
    return medians.pivot(index=BLOCK, columns=method, values=value)


def noninferiority_decision(
    ci_low: float,
    margin: float = ML_NONINFERIORITY_MARGIN,
) -> str:
    """Return the CI-based non-inferiority decision without a p-value shortcut."""
    return "supported" if np.isfinite(ci_low) and ci_low > margin else "not_supported"


def holm_adjust(rows):
    frame = pd.DataFrame(rows)
    frame["p_holm"] = frame["p_holm"].astype(float)
    # Holm correction applies only to finite pairwise p-values.  CI-based
    # non-inferiority rows intentionally have no p-value and must retain their
    # precomputed decision instead of being converted from NaN to p_holm=0.
    finite_pairwise = (
        frame["comparison"].ne("all_methods")
        & np.isfinite(frame["p_raw"].to_numpy(dtype=float))
    )
    for _, indices in frame[finite_pairwise].groupby(["analysis", "metric"]).groups.items():
        index = list(indices)
        p = frame.loc[index, "p_raw"].to_numpy(dtype=float)
        order = np.argsort(p)
        adjusted = np.empty(len(p), dtype=float)
        running = 0.0
        m = len(p)
        for rank, position in enumerate(order):
            running = max(running, (m - rank) * p[position])
            adjusted[position] = min(1.0, running)
        frame.loc[index, "p_holm"] = adjusted
        for row_index in index:
            frame.loc[row_index, "decision"] = (
                "supported" if frame.loc[row_index, "p_holm"] < 0.05 else "not_supported"
            )
    return frame


def main() -> None:
    rows = []
    progress = AnalysisProgress(
        13, "paired statistical inference", 5, "analysis families",
        output_filename="statistical_results.tsv",
    )

    unit_started = progress.start(1, "ML non-inferiority")
    ml = read_tsv("ml_performance.tsv")
    ml = ml[ml["eval_split"] == "outer_test"]
    ml_pivot = block_pivot(ml, "balanced_accuracy", "feature_set")
    paired = ml_pivot[["selected", "full"]].dropna()
    differences = paired["selected"].to_numpy() - paired["full"].to_numpy()
    low, high = bootstrap_ci(differences)
    rows.append({
        "analysis": "ml_noninferiority", "metric": "balanced_accuracy",
        "comparison": "selected_vs_full", "n_blocks": len(differences),
        "estimate": float(np.mean(differences)), "ci_low": low, "ci_high": high,
        "p_raw": np.nan, "p_holm": np.nan,
        "effect_size": rank_biserial(differences),
        "decision": noninferiority_decision(low),
    })
    checkpoint_tsv(rows, "statistical_results.tsv")
    progress.done(1, unit_started, len(rows))

    unit_started = progress.start(2, "XAI faithfulness comparison")
    faith = read_tsv("xai_faithfulness.tsv")
    faith = faith[faith["eval_split"] == "outer_test"]
    faith_pivot = block_pivot(faith, "behavior_r2", "method")
    omnibus = omnibus_row("xai_comparison", "behavior_r2", faith_pivot)
    if omnibus:
        rows.append(omnibus)
    rows.extend(paired_rows(
        "xai_comparison", "behavior_r2", faith_pivot, "abc_faithopt",
        [column for column in faith_pivot if column != "abc_faithopt"],
    ))
    checkpoint_tsv(rows, "statistical_results.tsv")
    progress.done(2, unit_started, len(rows))

    unit_started = progress.start(3, "conditional deletion comparison")
    audit = read_tsv("conditional_audit.tsv")
    audit_pivot = block_pivot(audit, "deletion_auc", "method")
    omnibus = omnibus_row("conditional_audit", "deletion_auc", audit_pivot)
    if omnibus:
        rows.append(omnibus)
    rows.extend(paired_rows(
        "conditional_audit", "deletion_auc", audit_pivot, "abc_faithopt",
        [column for column in audit_pivot if column != "abc_faithopt"],
    ))
    checkpoint_tsv(rows, "statistical_results.tsv")
    progress.done(3, unit_started, len(rows))

    unit_started = progress.start(4, "component ablation comparison")
    ablation = read_tsv("ablation_results.tsv")
    ablation_pivot = block_pivot(ablation, "test_r2", "variant")
    rows.extend(paired_rows(
        "ablation", "test_r2", ablation_pivot, "full",
        [column for column in ablation_pivot if column != "full"],
    ))
    checkpoint_tsv(rows, "statistical_results.tsv")
    progress.done(4, unit_started, len(rows))

    unit_started = progress.start(5, "runtime comparison")
    runtime = read_tsv("runtime_results.tsv")
    runtime = runtime[runtime["scope"] == "end_to_end_xai"]
    runtime_pivot = block_pivot(runtime, "runtime_sec", "method")
    omnibus = omnibus_row("runtime", "runtime_sec", runtime_pivot)
    if omnibus:
        rows.append(omnibus)
    rows.extend(paired_rows(
        "runtime", "runtime_sec", runtime_pivot, "abc_faithopt",
        [column for column in runtime_pivot if column != "abc_faithopt"],
    ))

    output = holm_adjust(rows)
    checkpoint_tsv(output, "statistical_results.tsv")
    progress.done(5, unit_started, len(output))
    path = write_tsv(output, "statistical_results.tsv")
    progress.finish(len(output), path)


if __name__ == "__main__":
    main()
