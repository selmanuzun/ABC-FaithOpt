#!/usr/bin/env python3
"""Analysis 05: held-out behavior reconstruction for all global XAI methods."""
from __future__ import annotations

from analysis_01_dataset_summary import (
    AnalysisProgress,
    DATASETS,
    MODELS,
    N_REPEATS,
    N_SPLITS,
    all_method_weights,
    base_row,
    build_xai_cache,
    checkpoint_tsv,
    evaluate_behavior_reconstruction,
    fit_scale,
    iter_fold_caches,
    write_tsv,
)


def main() -> None:
    rows = []
    total_folds = len(DATASETS) * len(MODELS) * N_REPEATS * N_SPLITS
    expected_rows = total_folds * 5 * 3
    progress = AnalysisProgress(
        5, "XAI faithfulness", total_folds, "dataset-model-fold units",
        expected_rows=expected_rows, output_filename="xai_faithfulness.tsv",
    )
    for fold_number, cache in enumerate(iter_fold_caches(require_existing=True), 1):
        common = base_row(cache)
        unit_started = progress.start(
            fold_number,
            f"{common['dataset']} | {common['model']} | "
            f"r{common['repeat']}f{common['outer_fold']}",
        )
        progress.step("building or loading the XAI cache")
        xai = build_xai_cache(cache)
        progress.step("computing five global explanation methods")
        weights_by_method = all_method_weights(cache, xai)
        for method, weights in weights_by_method.items():
            scale = fit_scale(weights, xai["behavior"]["calibration"])
            for eval_split in ("calibration", "guard", "outer_test"):
                metrics = evaluate_behavior_reconstruction(
                    weights, scale, xai["behavior"][eval_split]
                )
                accepted = (
                    xai["optimization"].accepted
                    if method == "abc_faithopt" and eval_split == "guard"
                    else None
                )
                optimization = xai["optimization"]
                rows.append({
                    **common, "method": method, "eval_split": eval_split,
                    "behavior_r2": metrics.r2,
                    "normalized_mae": metrics.normalized_mae,
                    "accepted": accepted,
                    "sensitivity_mode": (
                        optimization.requested_sensitivity_mode
                        if method == "abc_faithopt" else None
                    ),
                    "selected_sensitivity_pct": (
                        optimization.selected_sensitivity_pct
                        if method == "abc_faithopt" else None
                    ),
                    "sensitivity_boundary_hit": (
                        optimization.sensitivity_boundary_hit
                        if method == "abc_faithopt" else None
                    ),
                })
        checkpoint_tsv(rows, "xai_faithfulness.tsv")
        progress.done(fold_number, unit_started, len(rows))
    path = write_tsv(rows, "xai_faithfulness.tsv")
    progress.finish(len(rows), path)


if __name__ == "__main__":
    main()
