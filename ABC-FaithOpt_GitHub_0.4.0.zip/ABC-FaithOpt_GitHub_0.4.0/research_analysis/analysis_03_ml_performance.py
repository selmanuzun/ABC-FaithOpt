#!/usr/bin/env python3
"""Analysis 03: parallel nested-CV full versus ABC-selected ML performance."""
from __future__ import annotations

import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import pandas as pd

from analysis_01_dataset_summary import (
    ABC_STABILITY_RUNS,
    ABC_STABILITY_SUBSAMPLE,
    ANALYSIS_WORKERS,
    CACHE_DIR,
    DATASETS,
    INNER_SPLITS,
    MODELS,
    N_REPEATS,
    N_SPLITS,
    OUTPUT_DIR,
    base_row,
    build_fold_cache,
    encode_target,
    fold_cache_path,
    iter_splits,
    load_dataset,
    migrate_legacy_protocol_cache,
    probability_metrics,
    selected_matrices,
    write_tsv,
)


def format_duration(seconds: float | None) -> str:
    if seconds is None or not pd.notna(seconds):
        return "calculating"
    seconds = max(0, int(round(seconds)))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def ordered_frame(rows: list[dict[str, Any]]) -> pd.DataFrame:
    frame = pd.DataFrame(rows)
    keys = [
        name for name in
        ("dataset", "model", "repeat", "outer_fold", "feature_set", "eval_split")
        if name in frame.columns
    ]
    return frame.sort_values(keys, kind="stable").reset_index(drop=True) if keys else frame


def checkpoint(rows: list[dict[str, Any]]) -> Path:
    """Atomically publish the partial TSV after every completed fold group."""
    path = OUTPUT_DIR / "ml_performance.tsv"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tsv.tmp")
    ordered_frame(rows).to_csv(
        temporary, sep="\t", index=False, encoding="utf-8", na_rep="NA"
    )
    temporary.replace(path)
    return path


def rows_from_cache(cache: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    common = base_row(cache)
    selected = selected_matrices(cache)
    for feature_set, model, matrices, n_features, cv_metrics in (
        (
            "full", cache["model_full"], cache["matrices"],
            len(cache["preprocessor"].feature_names_), cache["inner_cv_full"],
        ),
        (
            "selected", cache["model_selected"], selected,
            len(cache["abc_result"].selected_features), cache["inner_cv_selected"],
        ),
    ):
        for eval_split in ("core_train", "outer_test"):
            metrics = probability_metrics(
                model, matrices[eval_split], cache["labels"][eval_split]
            )
            rows.append({
                **common, "feature_set": feature_set,
                "eval_split": eval_split, "n_features": n_features, **metrics,
            })
        rows.append({
            **common, "feature_set": feature_set, "eval_split": "inner_cv",
            "n_features": n_features, **cv_metrics,
        })
    return rows


def run_fold_group(
    group_number: int,
    dataset_key: str,
    repeat: int,
    outer_fold: int,
) -> dict[str, Any]:
    """Run all model families for one outer fold inside one worker process."""
    started = time.perf_counter()
    dataset = load_dataset(dataset_key)
    y, _ = encode_target(dataset.y)
    split = next(
        item for item in iter_splits(y)
        if item.repeat == repeat and item.outer_fold == outer_fold
    )
    rows: list[dict[str, Any]] = []
    new_tasks = 0
    tag = f"G{group_number:02d} {dataset_key} r{repeat}f{outer_fold}"
    for model_number, model_name in enumerate(MODELS, 1):
        cache_path = fold_cache_path(dataset_key, model_name, repeat, outer_fold)
        cached = cache_path.exists()
        new_tasks += int(not cached)
        print(
            f"[{tag}] MODEL {model_number}/{len(MODELS)} "
            f"{'CACHE' if cached else 'RUN'} | {model_name}",
            flush=True,
        )
        cache = build_fold_cache(
            dataset,
            y,
            split,
            model_name,
            progress=lambda message, prefix=tag: print(
                f"[{prefix}] STEP | {message}", flush=True
            ),
        )
        rows.extend(rows_from_cache(cache))
        print(f"[{tag}] MODEL {model_number}/{len(MODELS)} DONE | {model_name}", flush=True)
    return {
        "group_number": group_number,
        "dataset_key": dataset_key,
        "repeat": repeat,
        "outer_fold": outer_fold,
        "rows": rows,
        "new_tasks": new_tasks,
        "elapsed": time.perf_counter() - started,
        "pid": os.getpid(),
    }


def main() -> None:
    total_tasks = len(DATASETS) * len(MODELS) * N_SPLITS * N_REPEATS
    total_groups = len(DATASETS) * N_SPLITS * N_REPEATS
    workers = max(1, min(ANALYSIS_WORKERS, total_groups))
    groups: list[tuple[int, str, int, int]] = []
    cached_initial = 0

    print("\nABC-FaithOpt Analysis 03 — ML performance", flush=True)
    migrated = migrate_legacy_protocol_cache()
    print(f"TSV directory:   {OUTPUT_DIR}", flush=True)
    print(f"Cache directory: {CACHE_DIR}", flush=True)
    if migrated:
        print(f"Migrated {migrated} checkpoint(s) from the previous cache.", flush=True)
    print(
        f"Plan: {len(DATASETS)} datasets × {len(MODELS)} models × "
        f"{N_REPEATS} repeats × {N_SPLITS} outer folds = {total_tasks} tasks",
        flush=True,
    )
    print(
        f"Parallel plan: {total_groups} outer-fold groups | {workers} workers | "
        f"{INNER_SPLITS}-fold inner CV",
        flush=True,
    )
    print(
        "Each worker runs the models from one outer fold sequentially; "
        "ABC results are shared across those models.",
        flush=True,
    )
    print(
        f"ABC stability selection: {ABC_STABILITY_RUNS} runs per search | "
        f"stratified train subsample={ABC_STABILITY_SUBSAMPLE:.0%}",
        flush=True,
    )

    group_number = 0
    for dataset_key in DATASETS:
        dataset = load_dataset(dataset_key)
        y, _ = encode_target(dataset.y)
        for split in iter_splits(y):
            group_number += 1
            groups.append((group_number, dataset_key, split.repeat, split.outer_fold))
            for model_name in MODELS:
                cached_initial += int(
                    fold_cache_path(
                        dataset_key, model_name, split.repeat, split.outer_fold
                    ).exists()
                )
    print(
        f"Initial status: {cached_initial}/{total_tasks} tasks cached; "
        f"{total_tasks - cached_initial} tasks require computation.\n",
        flush=True,
    )

    rows: list[dict[str, Any]] = []
    group_durations: list[float] = []
    completed_groups = 0
    completed_tasks = 0
    started = time.perf_counter()
    executor = ProcessPoolExecutor(max_workers=workers)
    future_map = {
        executor.submit(run_fold_group, *group): group for group in groups
    }
    try:
        for future in as_completed(future_map):
            result = future.result()
            rows.extend(result["rows"])
            checkpoint(rows)
            completed_groups += 1
            completed_tasks += len(MODELS)
            group_durations.append(float(result["elapsed"]))
            remaining_groups = total_groups - completed_groups
            waves_remaining = remaining_groups / workers
            eta = (
                float(pd.Series(group_durations).median()) * waves_remaining
                if group_durations and remaining_groups else 0.0
            )
            print(
                f"[PROGRESS] groups={completed_groups}/{total_groups} | "
                f"tasks={completed_tasks}/{total_tasks} | "
                f"latest={result['dataset_key']} r{result['repeat']}f{result['outer_fold']} | "
                f"group_time={format_duration(result['elapsed'])} | "
                f"ETA={format_duration(eta)} | TSV_rows={len(rows)}",
                flush=True,
            )
    except (Exception, KeyboardInterrupt):
        if rows:
            checkpoint(rows)
        for future in future_map:
            future.cancel()
        executor.shutdown(wait=False, cancel_futures=True)
        print(
            "Analysis 03 interrupted; completed caches and the partial TSV "
            "checkpoint were preserved.",
            flush=True,
        )
        raise
    else:
        executor.shutdown(wait=True)

    total_elapsed = time.perf_counter() - started
    final_rows = ordered_frame(rows).to_dict("records")
    final_path = write_tsv(final_rows, "ml_performance.tsv")
    print(
        f"Analysis 03 complete: {total_tasks}/{total_tasks} tasks | "
        f"TSV_rows={len(final_rows)} | total_time={format_duration(total_elapsed)}"
        f"\nOutput: {final_path}",
        flush=True,
    )


if __name__ == "__main__":
    main()
