#!/usr/bin/env python3
"""Analysis 11: shuffled-label model/explanation sanity check."""
from __future__ import annotations

import numpy as np

from analysis_01_dataset_summary import (
    AnalysisProgress,
    CAL_PERTURBATIONS,
    GUARD_PERTURBATIONS,
    TEST_PERTURBATIONS,
    base_row,
    build_disjoint_mask_patterns,
    build_xai_cache,
    checkpoint_tsv,
    iter_fold_caches,
    make_model,
    measure_masked_model_behavior,
    normalize_weights,
    optimize_behavior_reconstruction,
    optimizer_config,
    probability_metrics,
    run_abc,
    safe_spearman,
    selected_layout,
    stable_seed,
    write_tsv,
    N_REPEATS,
    N_SPLITS,
)


TARGET_DATASETS = {"breast_cancer", "adult", "dry_bean"}


def main() -> None:
    rows = []
    total_tasks = len(TARGET_DATASETS) * N_REPEATS * N_SPLITS
    progress = AnalysisProgress(
        11, "shuffled-label sanity check", total_tasks,
        "dataset-fold tasks", expected_rows=total_tasks,
        output_filename="sanity_check.tsv",
    )
    task_number = 0
    for cache in iter_fold_caches(require_existing=True):
        common = base_row(cache)
        if common["dataset"] not in TARGET_DATASETS or common["model"] != "random_forest":
            continue
        task_number += 1
        unit_started = progress.start(
            task_number,
            f"{common['dataset']} | random_forest | "
            f"r{common['repeat']}f{common['outer_fold']}",
        )
        xai_real = build_xai_cache(cache)
        split = cache["split"]
        dataset = cache["dataset"]
        rng = np.random.default_rng(stable_seed(split.seed, "shuffle"))
        shuffled_y = cache["labels"]["core_train"].copy()
        rng.shuffle(shuffled_y)
        progress.step("running ABC with shuffled labels")
        prep, abc = run_abc(
            dataset.X.iloc[split.core_idx], shuffled_y,
            dataset.categorical_features, stable_seed(split.seed, "shuffled_abc"),
        )
        columns, groups = selected_layout(prep, abc)
        matrices = {
            name: prep.transform_model(dataset.X.iloc[index])[:, columns]
            for name, index in {
                "core": split.core_idx, "calibration": split.calibration_idx,
                "guard": split.guard_idx, "test": split.test_idx,
            }.items()
        }
        progress.step("training the shuffled-label random forest")
        model = make_model("random_forest", cache["params_selected"], split.seed + 901)
        model.fit(matrices["core"], shuffled_y)
        patterns = build_disjoint_mask_patterns(
            len(abc.selected_features),
            calibration_patterns=max(len(abc.selected_features), len(xai_real["patterns"].calibration)),
            guard_patterns=len(xai_real["patterns"].guard),
            test_patterns=len(xai_real["patterns"].test),
            random_state=stable_seed(split.seed, "shuffled_masks"),
        )
        behavior_cal = measure_masked_model_behavior(
            model=model, X=matrices["calibration"], feature_names=abc.selected_features,
            feature_groups=groups, mask_patterns=patterns.calibration,
            n_perturbations=max(CAL_PERTURBATIONS, len(patterns.calibration)), random_state=split.seed + 902,
        )
        behavior_guard = measure_masked_model_behavior(
            model=model, X=matrices["guard"], feature_names=abc.selected_features,
            feature_groups=groups, mask_patterns=patterns.guard,
            n_perturbations=max(GUARD_PERTURBATIONS, len(patterns.guard)), random_state=split.seed + 903,
        )
        shuffled_opt = optimize_behavior_reconstruction(
            abc.initial_weights, behavior_cal, behavior_guard, optimizer_config(split.seed + 904),
        )
        real_weights = normalize_weights(
            xai_real["optimization"].final_weights,
            cache["abc_result"].selected_features,
        )
        shuffled_weights = normalize_weights(shuffled_opt.final_weights, abc.selected_features)
        all_names = list(dataset.X.columns)
        real_vector = np.asarray([real_weights.get(name, 0.0) for name in all_names])
        shuffled_vector = np.asarray([shuffled_weights.get(name, 0.0) for name in all_names])
        k = min(5, len(real_weights), len(shuffled_weights))
        real_top = set(sorted(real_weights, key=real_weights.get, reverse=True)[:k])
        shuffled_top = set(sorted(shuffled_weights, key=shuffled_weights.get, reverse=True)[:k])
        real_test = probability_metrics(
            cache["model_selected"],
            cache["matrices"]["outer_test"][:, cache["selected_columns"]],
            cache["labels"]["outer_test"],
        )
        shuffled_test = probability_metrics(model, matrices["test"], cache["labels"]["outer_test"])
        rows.append({
            "dataset": common["dataset"], "model": common["model"],
            "repeat": common["repeat"], "outer_fold": common["outer_fold"],
            "real_test_ba": real_test["balanced_accuracy"],
            "shuffled_test_ba": shuffled_test["balanced_accuracy"],
            "topk_jaccard": len(real_top & shuffled_top) / max(len(real_top | shuffled_top), 1),
            "weight_rank_corr": safe_spearman(real_vector, shuffled_vector),
            "explanation_distance": float(np.sum(np.abs(real_vector - shuffled_vector))),
        })
        checkpoint_tsv(rows, "sanity_check.tsv")
        progress.done(task_number, unit_started, len(rows))
    path = write_tsv(rows, "sanity_check.tsv")
    progress.finish(len(rows), path)


if __name__ == "__main__":
    main()
