#!/usr/bin/env python3
"""Run the 13 ABC-FaithOpt research analyses sequentially.

Child processes inherit the current environment and stream their output directly
to the terminal. A failed analysis is recorded and, by default, does not prevent
the remaining analyses from running.
"""
from __future__ import annotations

import argparse
import csv
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Sequence


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
ANALYSIS_PATTERN = re.compile(r"^analysis_(\d{2})_.+\.py$")


def format_duration(seconds: float) -> str:
    total = max(0, int(round(seconds)))
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def discover_analyses() -> dict[int, Path]:
    discovered: dict[int, Path] = {}
    for path in SCRIPT_DIR.glob("analysis_*.py"):
        match = ANALYSIS_PATTERN.match(path.name)
        if not match:
            continue
        number = int(match.group(1))
        if not 1 <= number <= 13:
            continue
        if number in discovered:
            raise RuntimeError(f"Duplicate script found for analysis {number:02d}.")
        discovered[number] = path

    missing = [number for number in range(1, 14) if number not in discovered]
    if missing:
        labels = ", ".join(f"{number:02d}" for number in missing)
        raise RuntimeError(f"Missing analysis script(s): {labels}.")
    return discovered


def default_report_path() -> Path:
    configured = os.environ.get("ABCFAITH_OUTPUT_DIR")
    if configured:
        output_dir = Path(configured).expanduser()
        if not output_dir.is_absolute():
            output_dir = PROJECT_ROOT / output_dir
    elif str(PROJECT_ROOT).startswith("/mnt/"):
        output_dir = (
            Path.home()
            / ".cache"
            / "abc_faithopt_sci"
            / PROJECT_ROOT.name
            / "analysis_outputs"
        )
    else:
        output_dir = PROJECT_ROOT / "analysis_outputs"
    return output_dir / "analysis_run_report.tsv"


def write_report(rows: Sequence[dict[str, object]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp")
    fields = (
        "analysis_number",
        "script",
        "status",
        "return_code",
        "duration_seconds",
        "started_at",
        "finished_at",
    )
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, path)


def print_summary(rows: Sequence[dict[str, object]], report_path: Path) -> None:
    successful = sum(row["status"] == "SUCCESS" for row in rows)
    failed = sum(row["status"] == "FAILED" for row in rows)
    interrupted = sum(row["status"] == "INTERRUPTED" for row in rows)
    total_seconds = sum(float(row["duration_seconds"]) for row in rows)

    print("\n" + "=" * 78, flush=True)
    print("FINAL ANALYSIS RUN REPORT", flush=True)
    print("=" * 78, flush=True)
    for row in rows:
        print(
            f"Analysis {int(row['analysis_number']):02d} | "
            f"{str(row['status']):11s} | "
            f"duration={format_duration(float(row['duration_seconds']))} | "
            f"return_code={row['return_code']}",
            flush=True,
        )
    print("-" * 78, flush=True)
    print(
        f"Completed={len(rows)}/13 | Successful={successful} | "
        f"Failed={failed} | Interrupted={interrupted} | "
        f"total_time={format_duration(total_seconds)}",
        flush=True,
    )
    print(f"Report: {report_path.resolve()}", flush=True)
    print("=" * 78, flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run ABC-FaithOpt analyses 01 through 13 sequentially."
    )
    parser.add_argument("--start", type=int, default=1, choices=range(1, 14))
    parser.add_argument("--end", type=int, default=13, choices=range(1, 14))
    parser.add_argument(
        "--stop-on-error",
        action="store_true",
        help="Stop after the first failed analysis instead of continuing.",
    )
    parser.add_argument(
        "--report",
        type=Path,
        default=None,
        help="TSV report path. Defaults to the configured analysis output directory.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the execution plan without running any analysis.",
    )
    args = parser.parse_args()
    if args.start > args.end:
        parser.error("--start cannot be greater than --end.")
    return args


def main() -> int:
    args = parse_args()
    analyses = discover_analyses()
    selected = [(number, analyses[number]) for number in range(args.start, args.end + 1)]
    report_path = args.report or default_report_path()
    if not report_path.is_absolute():
        report_path = PROJECT_ROOT / report_path

    print("ABC-FaithOpt sequential analysis runner", flush=True)
    print(f"Python: {sys.executable}", flush=True)
    print(f"Project root: {PROJECT_ROOT}", flush=True)
    print(f"Plan: {len(selected)} analysis script(s), {args.start:02d} through {args.end:02d}", flush=True)
    print(f"Failure policy: {'stop' if args.stop_on_error else 'continue'}", flush=True)
    print(f"Report: {report_path.resolve()}", flush=True)

    if args.dry_run:
        print("\nDRY RUN — no analysis will be executed.", flush=True)
        for number, script in selected:
            print(f"Analysis {number:02d} | {script.name}", flush=True)
        return 0

    child_environment = os.environ.copy()
    child_environment["PYTHONUNBUFFERED"] = "1"
    rows: list[dict[str, object]] = []
    interrupted = False

    for position, (number, script) in enumerate(selected, start=1):
        print("\n" + "=" * 78, flush=True)
        print(
            f"RUN {position:02d}/{len(selected):02d} | Analysis {number:02d} | {script.name}",
            flush=True,
        )
        print("=" * 78, flush=True)
        started_at = datetime.now().astimezone()
        started = time.monotonic()
        return_code = 1
        status = "FAILED"
        try:
            completed = subprocess.run(
                [sys.executable, "-u", str(script)],
                cwd=PROJECT_ROOT,
                env=child_environment,
                check=False,
            )
            return_code = int(completed.returncode)
            status = "SUCCESS" if return_code == 0 else "FAILED"
        except KeyboardInterrupt:
            return_code = 130
            status = "INTERRUPTED"
            interrupted = True

        finished_at = datetime.now().astimezone()
        elapsed = time.monotonic() - started
        rows.append(
            {
                "analysis_number": number,
                "script": script.name,
                "status": status,
                "return_code": return_code,
                "duration_seconds": round(elapsed, 3),
                "started_at": started_at.isoformat(timespec="seconds"),
                "finished_at": finished_at.isoformat(timespec="seconds"),
            }
        )
        write_report(rows, report_path)
        print(
            f"RUN RESULT | Analysis {number:02d} | {status} | "
            f"duration={format_duration(elapsed)} | return_code={return_code}",
            flush=True,
        )

        if interrupted or (status == "FAILED" and args.stop_on_error):
            break

    print_summary(rows, report_path)
    if interrupted:
        return 130
    return 0 if all(row["status"] == "SUCCESS" for row in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
