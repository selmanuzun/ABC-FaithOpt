from __future__ import annotations

import unittest

import numpy as np
import pandas as pd
from sklearn.datasets import make_classification

from abc_faithopt import (
    ABCConfig,
    ABCFaithOpt,
    ABCFaithOptConfig,
    FaithfulnessOptimizerConfig,
)
from abc_faithopt.datasets import available_uci_datasets
from abc_faithopt.faithfulness import (
    BehaviorPerturbationResult,
    build_disjoint_mask_patterns,
    optimize_behavior_reconstruction,
)
from abc_faithopt.abc import FeatureValueObjective, run_abc_feature_value_search


def behavior_result(patterns: np.ndarray, target: np.ndarray) -> BehaviorPerturbationResult:
    return BehaviorPerturbationResult(
        masks=patterns.copy(),
        behavior_change=target.copy(),
        unique_patterns=patterns.copy(),
        pattern_mean_change=target.copy(),
        metric="synthetic",
        n_perturbations=len(patterns),
        n_unique_patterns=len(patterns),
        random_state=42,
    )


class BehaviorReconstructionTests(unittest.TestCase):
    def test_auto_sensitivity_default_ceiling_is_full_percentage_range(self) -> None:
        config = FaithfulnessOptimizerConfig()
        self.assertEqual(config.auto_sensitivity_min_pct, 10.0)
        self.assertEqual(config.auto_sensitivity_max_pct, 100.0)

    def test_mask_patterns_are_disjoint_and_calibration_has_singletons(self) -> None:
        split = build_disjoint_mask_patterns(5, random_state=13)
        calibration = {tuple(row) for row in split.calibration}
        guard = {tuple(row) for row in split.guard}
        test = {tuple(row) for row in split.test}
        self.assertFalse(calibration & guard)
        self.assertFalse(calibration & test)
        self.assertFalse(guard & test)
        for singleton in np.eye(5):
            self.assertIn(tuple(singleton), calibration)

    def test_optimizer_reconstructs_unseen_mask_behavior(self) -> None:
        split = build_disjoint_mask_patterns(5, random_state=7)
        true_weights = np.asarray([0.40, 0.26, 0.17, 0.11, 0.06])
        scale = 0.35
        calibration = behavior_result(
            split.calibration,
            scale * (split.calibration @ true_weights),
        )
        guard = behavior_result(
            split.guard,
            scale * (split.guard @ true_weights),
        )
        result = optimize_behavior_reconstruction(
            {"a": 0.20, "b": 0.20, "c": 0.20, "d": 0.20, "e": 0.20},
            calibration,
            guard,
            FaithfulnessOptimizerConfig(
                steps=500,
                regularization=0.0,
                sensitivity=None,
                min_acceptable_faithfulness=0.85,
            ),
        )
        self.assertTrue(result.accepted)
        self.assertGreater(result.guard_candidate.r2, 0.999)
        self.assertGreater(result.guard_improvement, 0.01)

    def test_auto_sensitivity_is_selected_without_guard_leakage(self) -> None:
        split = build_disjoint_mask_patterns(5, random_state=23)
        true_weights = np.asarray([0.42, 0.25, 0.16, 0.10, 0.07])
        initial = {name: 0.20 for name in "abcde"}
        calibration = behavior_result(
            split.calibration,
            0.4 * (split.calibration @ true_weights),
        )
        guard_one = behavior_result(
            split.guard,
            0.4 * (split.guard @ true_weights),
        )
        guard_two = behavior_result(
            split.guard,
            0.4 * (split.guard @ true_weights[::-1]),
        )
        config = FaithfulnessOptimizerConfig(
            steps=100,
            regularization=0.0,
            sensitivity="auto",
            min_acceptable_faithfulness=None,
            max_guard_nmae_increase=None,
            auto_sensitivity_min_pct=10.0,
            auto_sensitivity_max_pct=80.0,
            auto_abc_colony_size=6,
            auto_abc_iterations=4,
            random_state=19,
        )
        first = optimize_behavior_reconstruction(
            initial, calibration, guard_one, config
        )
        second = optimize_behavior_reconstruction(
            initial, calibration, guard_two, config
        )
        self.assertEqual(
            first.selected_sensitivity_pct,
            second.selected_sensitivity_pct,
        )
        self.assertEqual(first.candidate_weights, second.candidate_weights)
        self.assertGreaterEqual(first.selected_sensitivity_pct, 10.0)
        self.assertLessEqual(first.selected_sensitivity_pct, 80.0)
        self.assertGreater(first.sensitivity_search_evaluations, 1)

    def test_full_auto_ceiling_resolves_a_binding_eighty_percent_limit(self) -> None:
        split = build_disjoint_mask_patterns(
            5,
            calibration_patterns=16,
            guard_patterns=12,
            test_patterns=12,
            random_state=71,
        )
        true_weights = np.asarray([0.55, 0.25, 0.12, 0.07, 0.01])
        initial = {name: 0.20 for name in "abcde"}
        calibration = behavior_result(
            split.calibration,
            0.42 * (split.calibration @ true_weights),
        )
        guard = behavior_result(
            split.guard,
            0.42 * (split.guard @ true_weights),
        )

        def solve(maximum: float):
            return optimize_behavior_reconstruction(
                initial,
                calibration,
                guard,
                FaithfulnessOptimizerConfig(
                    steps=150,
                    regularization=0.0,
                    sensitivity="auto",
                    min_acceptable_faithfulness=None,
                    max_guard_nmae_increase=0.0,
                    auto_sensitivity_min_pct=10.0,
                    auto_sensitivity_max_pct=maximum,
                    auto_sensitivity_penalty=0.0,
                    auto_abc_colony_size=6,
                    auto_abc_iterations=6,
                    random_state=2026,
                ),
            )

        capped = solve(80.0)
        full = solve(100.0)
        self.assertTrue(capped.sensitivity_boundary_hit)
        self.assertFalse(full.sensitivity_boundary_hit)
        self.assertGreater(full.selected_sensitivity_pct, 80.0)
        self.assertGreater(full.calibration_candidate.r2, capped.calibration_candidate.r2)
        self.assertGreater(full.guard_candidate.r2, capped.guard_candidate.r2)

    def test_fixed_sensitivity_remains_available(self) -> None:
        split = build_disjoint_mask_patterns(5, random_state=29)
        true_weights = np.asarray([0.40, 0.26, 0.17, 0.11, 0.06])
        calibration = behavior_result(
            split.calibration,
            split.calibration @ true_weights,
        )
        guard = behavior_result(split.guard, split.guard @ true_weights)
        result = optimize_behavior_reconstruction(
            {name: 0.20 for name in "abcde"},
            calibration,
            guard,
            FaithfulnessOptimizerConfig(
                sensitivity=50.0,
                min_acceptable_faithfulness=None,
            ),
        )
        self.assertEqual(result.requested_sensitivity_mode, "fixed")
        self.assertEqual(result.selected_sensitivity_pct, 50.0)
        self.assertEqual(result.sensitivity_search_evaluations, 1)

    def test_inconsistent_unseen_masks_reject_candidate(self) -> None:
        split = build_disjoint_mask_patterns(5, random_state=11)
        calibration_weights = np.asarray([0.45, 0.25, 0.15, 0.10, 0.05])
        guard_weights = calibration_weights[::-1]
        calibration = behavior_result(
            split.calibration,
            split.calibration @ calibration_weights,
        )
        guard = behavior_result(split.guard, split.guard @ guard_weights)
        result = optimize_behavior_reconstruction(
            {"a": 0.20, "b": 0.20, "c": 0.20, "d": 0.20, "e": 0.20},
            calibration,
            guard,
            FaithfulnessOptimizerConfig(
                steps=500,
                regularization=0.0,
                sensitivity=None,
                min_acceptable_faithfulness=0.85,
            ),
        )
        self.assertFalse(result.accepted)
        self.assertEqual(
            result.reason,
            "unseen_mask_reconstruction_below_threshold",
        )
        self.assertEqual(result.final_weights, result.initial_weights)


class DatasetRegistryTests(unittest.TestCase):
    def test_required_official_uci_ids_are_registered(self) -> None:
        self.assertEqual(
            available_uci_datasets(),
            {"breast_cancer": 17, "adult": 2, "dry_bean": 602},
        )


class ABCStabilitySelectionTests(unittest.TestCase):
    def test_stability_ensemble_is_deterministic_and_auditable(self) -> None:
        rng = np.random.default_rng(31)
        X = rng.normal(size=(360, 10))
        logits = 2.5 * X[:, 0] - 2.0 * X[:, 1] + 1.7 * X[:, 2]
        y = (logits + rng.normal(scale=0.7, size=len(X)) > 0.0).astype(int)
        names = [f"x{index}" for index in range(X.shape[1])]
        config = ABCConfig(
            colony_size=10,
            iterations=8,
            abandonment_limit=3,
            min_features=3,
            max_features=5,
            stability_runs=5,
            stability_subsample=0.80,
            stability_fitness_tolerance=1.0,
            random_state=17,
        )

        def build_objective() -> FeatureValueObjective:
            return FeatureValueObjective(
                X,
                y,
                names,
                np.zeros(X.shape[1], dtype=bool),
                lambda _index, value: value,
                config,
            )

        first = run_abc_feature_value_search(build_objective(), config)
        second = run_abc_feature_value_search(build_objective(), config)
        self.assertEqual(first.selected_features, second.selected_features)
        self.assertEqual(first.initial_weights, second.initial_weights)
        self.assertEqual(first.ensemble_runs, 5)
        self.assertEqual(len(first.ensemble_member_features), 5)
        self.assertEqual(set(first.selection_frequency), set(names))
        self.assertTrue(all(0.0 <= value <= 1.0 for value in first.selection_frequency.values()))
        self.assertTrue(first.consensus_used)
        self.assertIsNotNone(first.consensus_fitness)
        self.assertIsNotNone(first.reference_fitness)


class PipelineTests(unittest.TestCase):
    def test_end_to_end_pipeline_uses_unseen_mask_reconstruction(self) -> None:
        values, labels = make_classification(
            n_samples=300,
            n_features=8,
            n_informative=5,
            n_redundant=1,
            random_state=17,
        )
        frame = pd.DataFrame(values, columns=[f"x{index}" for index in range(8)])
        config = ABCFaithOptConfig(
            permutation_runs=2,
            abc=ABCConfig(
                colony_size=8,
                iterations=5,
                abandonment_limit=3,
                min_features=4,
                max_features=5,
                stability_runs=3,
                stability_fitness_tolerance=1.0,
            ),
            optimizer=FaithfulnessOptimizerConfig(
                steps=100,
                regularization=0.01,
                sensitivity=100.0,
                min_acceptable_faithfulness=None,
                accept_only_if_improved=False,
                calibration_perturbations=24,
                guard_perturbations=12,
                test_perturbations=12,
            ),
        )
        result = ABCFaithOpt(config).fit(frame, labels).explain_global()

        self.assertGreaterEqual(len(result.selected_features), 4)
        self.assertLessEqual(len(result.selected_features), 5)
        self.assertEqual(set(result.explanation["feature"]), set(result.selected_features))
        self.assertEqual(sum(result.split_sizes.values()), len(frame))
        self.assertEqual(result.metadata["version"], "0.4.0")
        self.assertEqual(result.metadata["abc_stability_runs"], 3)
        self.assertIn("abc_selection_frequency", result.explanation.columns)
        self.assertEqual(result.metadata["sensitivity_mode"], "fixed")
        self.assertEqual(result.metadata["selected_sensitivity_pct"], 100.0)
        self.assertIn(
            result.metadata["test_audit_status"],
            {"passed", "failed", "candidate_rejected"},
        )
        self.assertIsInstance(result.metadata["test_audit_threshold_met"], bool)
        self.assertTrue(result.metadata["rank_metric_is_diagnostic_only"])
        self.assertFalse(result.metadata["mask_pattern_overlap"])
        self.assertIn("R-squared reconstruction", result.metadata["faithfulness_definition"])
        self.assertEqual(result.metadata["abc_scope"], "train_only")
        self.assertEqual(
            result.metadata["faithfulness_optimization_scope"], "calibration_only"
        )
        self.assertEqual(
            result.metadata["acceptance_guard_scope"],
            "held_out_validation_guard_only",
        )
        self.assertEqual(result.metadata["final_evaluation_scope"], "untouched_test")
        self.assertFalse(result.metadata["causal_claim"])
        self.assertTrue(result.metadata["test_is_reporting_only"])
        self.assertTrue(np.isfinite(list(result.metrics.values())).all())


if __name__ == "__main__":
    unittest.main()
