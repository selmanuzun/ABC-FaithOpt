# ABC-FaithOpt 0.4.0

ABC-FaithOpt is a model-agnostic global explainable artificial intelligence (XAI) framework for tabular classification. It combines stability-aware Artificial Bee Colony (ABC) feature-value discovery with constrained optimization of global explanation weights against perturbation-induced model behavior.

The repository contains the implementation used in the study, the 13 research-analysis scripts, unit tests, and the tab-separated analysis outputs used for the reported results. Figure-generation scripts are intentionally excluded.

## Method overview

ABC-FaithOpt separates feature discovery, explanation calibration, guarded acceptance, and final evaluation:

1. Data are partitioned into core training, calibration, validation-guard, and outer-test roles.
2. ABC operates on training data only to discover a compact set of original features, feature-value rules, and initial global weights.
3. Repeated ABC searches are aggregated through a stability-aware consensus procedure, subject to a fitness guard.
4. A predictive classifier is trained on the selected feature groups.
5. Calibration perturbations are used to optimize the global weights under sensitivity-controlled bounds.
6. A separate validation guard determines whether the optimized candidate is accepted or the method reverts to the ABC initialization.
7. Final behavioral faithfulness is evaluated on untouched outer-test observations and disjoint perturbation masks.

The primary faithfulness target is out-of-sample behavioral reconstruction measured with R-squared. Spearman rank correlation is retained only as a diagnostic and does not drive optimization or acceptance.

## Repository structure

```text
ABC-FaithOpt_GitHub_0.4.0/
├── README.md
├── pyproject.toml
├── .gitignore
├── src/
│   └── abc_faithopt/
├── tests/
├── research_analysis/
│   ├── analysis_01_dataset_summary.py
│   ├── ...
│   ├── analysis_13_statistical_results.py
│   ├── run_all_analyses.py
│   └── README.md
└── analysis_outputs/
    ├── dataset_summary.tsv
    ├── split_audit.tsv
    ├── ml_performance.tsv
    ├── selected_features.tsv
    ├── xai_faithfulness.tsv
    ├── conditional_audit.tsv
    ├── ablation_results.tsv
    ├── weight_sensitivity.tsv
    ├── reliability_results.tsv
    ├── synthetic_results.tsv
    ├── sanity_check.tsv
    ├── runtime_results.tsv
    ├── statistical_results.tsv
    └── analysis_run_report.tsv
```

## Installation

Python 3.10 or newer is required.

```bash
python -m pip install -e .
```

The declared dependencies are NumPy, pandas, SciPy, and scikit-learn. The research code does not require the external `shap`, `xgboost`, or `psutil` packages.

## Basic command-line usage

The package-level command-line interface provides the original three-dataset demonstration workflow:

```bash
python -m abc_faithopt --dataset breast_cancer
python -m abc_faithopt --dataset adult --output adult_result.json
python -m abc_faithopt --dataset dry_bean --output dry_bean_result.json
```

Supported package-level dataset keys are:

```text
breast_cancer, adult, dry_bean
```

Official UCI archives are downloaded on first use and stored in a local cache; raw UCI archives are not distributed in this repository.

## Python API example

```python
from abc_faithopt import (
    ABCConfig,
    ABCFaithOpt,
    ABCFaithOptConfig,
    FaithfulnessOptimizerConfig,
    fetch_uci_dataset,
)

dataset = fetch_uci_dataset("breast_cancer")

config = ABCFaithOptConfig(
    abc=ABCConfig(
        stability_runs=7,
        stability_subsample=0.80,
        stability_frequency_weight=0.75,
        stability_fitness_tolerance=0.05,
    ),
    optimizer=FaithfulnessOptimizerConfig(
        sensitivity="auto",
        auto_sensitivity_max_pct=100.0,
        min_acceptable_faithfulness=None,
        max_guard_nmae_increase=0.0,
        calibration_mask_patterns=32,
        guard_mask_patterns=24,
        test_mask_patterns=24,
    ),
)

model = ABCFaithOpt(config).fit(
    dataset.X,
    dataset.y,
    categorical_features=dataset.categorical_features,
)
result = model.explain_global()

print(result.explanation)
print(result.metrics["validation_guard_faithfulness_final"])
print(result.metrics["test_faithfulness_final"])
print(result.optimization.accepted)
print(result.optimization.selected_sensitivity_pct)
```

## Study analyses

The study-level analyses use six UCI datasets and three classifier families:

- Breast Cancer Wisconsin (Diagnostic)
- Adult
- Dry Bean
- Bank Marketing
- Spambase
- Statlog Landsat Satellite

Classifier families:

- Logistic Regression
- Random Forest
- Gradient Boosting

The complete analysis sequence can be executed from the repository root with:

```bash
python research_analysis/run_all_analyses.py
```

To inspect the execution plan without running the analyses:

```bash
python research_analysis/run_all_analyses.py --dry-run
```

See [`research_analysis/README.md`](research_analysis/README.md) for the full study protocol, environment variables, output definitions, and reproducibility notes.

## Main study configuration

The principal protocol includes:

- outer stratified 3-fold cross-validation with one repeat;
- inner stratified 3-fold model selection;
- stability-aware ABC with 7 searches per feature-selection operation;
- 3 to 7 selected original features;
- calibration, validation-guard, and outer-test perturbation sets with disjoint mask signatures;
- automatic sensitivity search over 10% to 100%;
- L-BFGS-B weight optimization;
- guard acceptance requiring at least 0.01 improvement in validation-guard R-squared without an increase in normalized MAE;
- final evaluation on untouched outer-test data.

The study comparison evaluates ABC initial weights, ABC-FaithOpt, permutation importance, Monte Carlo SHAP, and native model importance within the same ABC-selected feature space. This design compares weighting representations under a common feature set and should not be interpreted as an end-to-end comparison of independently selected explanation pipelines.

## Analysis outputs

The `analysis_outputs/` directory contains the TSV files generated by the 13 study analyses. These files are included to make the reported numerical results auditable without requiring every analysis to be rerun immediately.

All TSV outputs are UTF-8, tab-delimited, written without an index, and use `NA` for missing values where applicable.

## Testing

Run the unit tests from the repository root:

```bash
python -m unittest discover -s tests -v
```

The tests cover disjoint perturbation-mask construction, sensitivity behavior, guarded acceptance, stability-aware ABC selection, and end-to-end pipeline behavior.

## Reproducibility notes

The principal random seed used in the study analyses is `20260813`. Derived deterministic seeds are generated for dataset, fold, method, and analysis-specific stochastic components.

The outer-test data are not used for preprocessing estimation, feature selection, classifier tuning, sensitivity selection, explanation optimization, or guard acceptance. Runtime measurements are executed serially to reduce timing contention.

Research caches and downloaded UCI archives are intentionally excluded from the repository and regenerated locally when needed.

## Scope

ABC-FaithOpt is designed to explain predictive model behavior under the perturbation-reconstruction protocol implemented here. Its outputs should not be interpreted as causal feature effects or as a unique ground-truth explanation.
