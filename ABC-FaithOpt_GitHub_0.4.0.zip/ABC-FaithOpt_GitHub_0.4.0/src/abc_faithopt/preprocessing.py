from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class PreprocessingSummary:
    feature_names: tuple[str, ...]
    categorical_features: tuple[str, ...]
    numeric_features: tuple[str, ...]


class TabularPreprocessor:
    """One-column-per-feature encoder fitted only on training rows.

    The rule matrix remains in original numeric units (categoricals are ordinal
    codes).  The model matrix standardizes every encoded column.  This preserves
    a one-to-one mapping between an explanation and the original input column.
    """

    def __init__(self, categorical_features: Optional[Iterable[str]] = None) -> None:
        self.declared_categorical = (
            None if categorical_features is None else set(categorical_features)
        )
        self.feature_names_: list[str] = []
        self.categorical_features_: list[str] = []
        self.numeric_features_: list[str] = []
        self.numeric_medians_: dict[str, float] = {}
        self.category_maps_: dict[str, dict[str, int]] = {}
        self.category_decoders_: dict[str, dict[int, str]] = {}
        self.numeric_means_: dict[str, float] = {}
        self.numeric_scales_: dict[str, float] = {}
        self.model_groups_: dict[str, tuple[int, ...]] = {}
        self.n_model_columns_: int = 0

    def fit(self, X: pd.DataFrame) -> "TabularPreprocessor":
        if not isinstance(X, pd.DataFrame) or X.empty:
            raise ValueError("X must be a non-empty pandas DataFrame.")
        if X.columns.duplicated().any():
            raise ValueError("X contains duplicate feature names.")

        self.feature_names_ = [str(column) for column in X.columns]
        if self.declared_categorical is None:
            categorical = {
                str(column)
                for column in X.columns
                if (
                    pd.api.types.is_object_dtype(X[column])
                    or isinstance(X[column].dtype, pd.CategoricalDtype)
                    or pd.api.types.is_bool_dtype(X[column])
                )
            }
        else:
            unknown = self.declared_categorical - set(self.feature_names_)
            if unknown:
                raise ValueError(f"Unknown categorical features: {sorted(unknown)}")
            categorical = set(self.declared_categorical)

        self.categorical_features_ = [
            feature for feature in self.feature_names_ if feature in categorical
        ]
        self.numeric_features_ = [
            feature for feature in self.feature_names_ if feature not in categorical
        ]

        for feature in self.numeric_features_:
            values = pd.to_numeric(X[feature], errors="coerce")
            median = float(values.median()) if values.notna().any() else 0.0
            self.numeric_medians_[feature] = median

        for feature in self.categorical_features_:
            values = X[feature].astype("string").fillna("<MISSING>")
            categories = sorted(str(value) for value in values.unique())
            mapping = {value: index for index, value in enumerate(categories)}
            self.category_maps_[feature] = mapping
            self.category_decoders_[feature] = {
                index: value for value, index in mapping.items()
            }

        cursor = 0
        for feature in self.feature_names_:
            if feature in self.category_maps_:
                width = len(self.category_maps_[feature])
                self.model_groups_[feature] = tuple(range(cursor, cursor + width))
                cursor += width
            else:
                values = pd.to_numeric(X[feature], errors="coerce").fillna(
                    self.numeric_medians_[feature]
                )
                mean = float(values.mean())
                scale = float(values.std(ddof=0))
                self.numeric_means_[feature] = mean
                self.numeric_scales_[feature] = 1.0 if scale <= 1e-12 else scale
                self.model_groups_[feature] = (cursor,)
                cursor += 1
        self.n_model_columns_ = cursor
        return self

    def _require_fitted(self) -> None:
        if not self.feature_names_ or not self.model_groups_:
            raise RuntimeError("Call fit before transform.")

    def transform_rules(self, X: pd.DataFrame) -> np.ndarray:
        if not self.feature_names_:
            raise RuntimeError("Call fit before transform.")
        missing = [feature for feature in self.feature_names_ if feature not in X]
        if missing:
            raise ValueError(f"X is missing features: {missing}")

        columns: list[np.ndarray] = []
        for feature in self.feature_names_:
            if feature in self.category_maps_:
                mapping = self.category_maps_[feature]
                values = X[feature].astype("string").fillna("<MISSING>")
                encoded = values.map(mapping).fillna(-1).to_numpy(dtype=float)
            else:
                values = pd.to_numeric(X[feature], errors="coerce")
                encoded = values.fillna(self.numeric_medians_[feature]).to_numpy(
                    dtype=float
                )
            columns.append(encoded)
        return np.column_stack(columns)

    def transform_model(self, X: pd.DataFrame) -> np.ndarray:
        self._require_fitted()
        rule_matrix = self.transform_rules(X)
        output = np.zeros((len(X), self.n_model_columns_), dtype=float)
        for index, feature in enumerate(self.feature_names_):
            group = self.model_groups_[feature]
            if feature in self.category_maps_:
                codes = rule_matrix[:, index].astype(int)
                for category_index, output_index in enumerate(group):
                    output[:, output_index] = (codes == category_index).astype(float)
            else:
                output[:, group[0]] = (
                    rule_matrix[:, index] - self.numeric_means_[feature]
                ) / self.numeric_scales_[feature]
        return output

    def model_group_indices(self, feature_indices: Iterable[int]) -> dict[str, tuple[int, ...]]:
        self._require_fitted()
        return {
            self.feature_names_[index]: self.model_groups_[self.feature_names_[index]]
            for index in feature_indices
        }

    def categorical_mask(self) -> np.ndarray:
        if not self.feature_names_:
            raise RuntimeError("Call fit first.")
        categorical = set(self.categorical_features_)
        return np.asarray(
            [feature in categorical for feature in self.feature_names_], dtype=bool
        )

    def decode_category(self, feature_index: int, value: float) -> str:
        feature = self.feature_names_[feature_index]
        decoder = self.category_decoders_.get(feature, {})
        return decoder.get(int(round(value)), "<UNKNOWN>")

    def summary(self) -> PreprocessingSummary:
        self._require_fitted()
        return PreprocessingSummary(
            feature_names=tuple(self.feature_names_),
            categorical_features=tuple(self.categorical_features_),
            numeric_features=tuple(self.numeric_features_),
        )
