from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Callable, Sequence

import numpy as np


@dataclass(frozen=True)
class ABCConfig:
    colony_size: int = 24
    iterations: int = 40
    abandonment_limit: int = 10
    min_features: int = 3
    max_features: int = 7
    coverage_weight: float = 0.20
    redundancy_weight: float = 0.10
    sparsity_weight: float = 0.03
    invalid_rule_weight: float = 0.25
    min_rule_support: float = 0.10
    selector_bins: int = 101
    stability_runs: int = 7
    stability_subsample: float = 0.80
    stability_frequency_weight: float = 0.75
    stability_fitness_tolerance: float = 0.05
    random_state: int = 42

    def __post_init__(self) -> None:
        if self.colony_size < 4:
            raise ValueError("colony_size must be at least 4.")
        if self.iterations < 1 or self.abandonment_limit < 1:
            raise ValueError("iterations and abandonment_limit must be positive.")
        if self.min_features < 1 or self.max_features < self.min_features:
            raise ValueError("Require 1 <= min_features <= max_features.")
        if not 0.0 < self.min_rule_support < 0.5:
            raise ValueError("min_rule_support must be between 0 and 0.5.")
        if self.selector_bins < 5:
            raise ValueError("selector_bins must be at least 5.")
        if self.stability_runs < 1:
            raise ValueError("stability_runs must be at least 1.")
        if not 0.5 <= self.stability_subsample <= 1.0:
            raise ValueError("stability_subsample must be in [0.5, 1.0].")
        if not 0.0 <= self.stability_frequency_weight <= 1.0:
            raise ValueError("stability_frequency_weight must be in [0, 1].")
        if self.stability_fitness_tolerance < 0.0:
            raise ValueError("stability_fitness_tolerance must be non-negative.")


@dataclass(frozen=True)
class FeatureValueRule:
    feature: str
    operator: str
    value: object
    favored_class: object
    class_rate_delta: float
    support: float
    strength: float


@dataclass(frozen=True)
class ABCSearchResult:
    selected_indices: tuple[int, ...]
    selected_features: tuple[str, ...]
    initial_weights: dict[str, float]
    rules: tuple[FeatureValueRule, ...]
    fitness: float
    fitness_history: tuple[float, ...]
    selection_frequency: dict[str, float] = field(default_factory=dict)
    ensemble_runs: int = 1
    ensemble_member_features: tuple[tuple[str, ...], ...] = ()
    consensus_used: bool = False
    consensus_fitness: float | None = None
    reference_fitness: float | None = None


class FeatureValueObjective:
    """Supervised, model-independent feature-value objective for ABC.

    A bee contains p feature-weight genes, p value-selector genes, and one
    subset-size gene. Numeric selectors define 10th--90th percentile cutoffs;
    categorical selectors choose one observed category.
    """

    def __init__(
        self,
        X: np.ndarray,
        y: np.ndarray,
        feature_names: Sequence[str],
        categorical_mask: np.ndarray,
        category_decoder: Callable[[int, float], object],
        config: ABCConfig,
    ) -> None:
        self.X = np.asarray(X, dtype=float)
        self.y = np.asarray(y, dtype=int)
        self.feature_names = list(feature_names)
        self.categorical_mask = np.asarray(categorical_mask, dtype=bool)
        self.category_decoder = category_decoder
        self.config = config
        self.n_features = self.X.shape[1]
        if self.X.shape[0] != len(self.y):
            raise ValueError("X and y must contain the same number of rows.")
        if self.n_features != len(self.feature_names):
            raise ValueError("feature_names must match X columns.")
        if config.min_features > self.n_features:
            raise ValueError("min_features exceeds the number of input features.")
        self.max_features = min(config.max_features, self.n_features)
        self.classes = np.unique(self.y)
        if len(self.classes) < 2:
            raise ValueError("ABC feature-value search requires at least two classes.")

        ranked = np.apply_along_axis(lambda values: values.argsort().argsort(), 0, self.X)
        corr = np.corrcoef(ranked, rowvar=False)
        if self.n_features == 1:
            corr = np.asarray([[1.0]])
        self.redundancy = np.nan_to_num(np.abs(corr), nan=0.0)

        self.selector_grid = np.linspace(0.0, 1.0, self.config.selector_bins)
        self.rule_strength_grid = np.asarray(
            [
                [
                    self._rule_strength(index, selector)[0]
                    for selector in self.selector_grid
                ]
                for index in range(self.n_features)
            ],
            dtype=float,
        )
        self.best_grid_strength = np.max(self.rule_strength_grid, axis=1)
        best = np.sort(self.best_grid_strength)[::-1][: self.max_features]
        self.coverage_denominator = max(float(np.sum(best)), 1e-12)

    @property
    def dimension(self) -> int:
        return 2 * self.n_features + 1

    def decode(self, position: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        position = np.clip(np.asarray(position, dtype=float), 0.0, 1.0)
        raw_weights = position[: self.n_features]
        selectors = position[self.n_features : 2 * self.n_features]
        span = self.max_features - self.config.min_features + 1
        count = self.config.min_features + min(
            int(np.floor(position[-1] * span)), span - 1
        )
        selected = np.argsort(raw_weights)[-count:]
        selected = selected[np.argsort(raw_weights[selected])[::-1]]
        selected_weights = np.maximum(raw_weights[selected], 1e-8)
        selected_weights = selected_weights / np.sum(selected_weights)
        return selected, selected_weights, selectors

    def _mask_for_rule(self, index: int, selector: float) -> tuple[np.ndarray, str, float]:
        values = self.X[:, index]
        if self.categorical_mask[index]:
            categories = np.unique(values)
            supports = np.asarray([np.mean(values == value) for value in categories])
            eligible = categories[
                (supports >= self.config.min_rule_support)
                & (supports <= 1.0 - self.config.min_rule_support)
            ]
            if len(eligible):
                categories = eligible
            category_index = min(int(np.floor(selector * len(categories))), len(categories) - 1)
            value = float(categories[category_index])
            return values == value, "==", value
        quantile = 0.10 + 0.80 * float(selector)
        value = float(np.quantile(values, quantile))
        return values > value, ">", value

    def _distribution(self, labels: np.ndarray) -> np.ndarray:
        counts = np.asarray([(labels == value).sum() for value in self.classes], dtype=float)
        counts += 1e-9
        return counts / np.sum(counts)

    def _rule_strength(self, index: int, selector: float) -> tuple[float, np.ndarray, str, float]:
        mask, operator, value = self._mask_for_rule(index, selector)
        support = float(np.mean(mask))
        if support < self.config.min_rule_support or support > 1.0 - self.config.min_rule_support:
            return 0.0, mask, operator, value
        left = self._distribution(self.y[mask])
        right = self._distribution(self.y[~mask])
        midpoint = 0.5 * (left + right)
        js = 0.5 * np.sum(left * np.log(left / midpoint))
        js += 0.5 * np.sum(right * np.log(right / midpoint))
        balance = 4.0 * support * (1.0 - support)
        strength = float((js / np.log(2.0)) * balance)
        return strength, mask, operator, value

    def __call__(self, position: np.ndarray) -> float:
        selected, weights, selectors = self.decode(position)
        selector_indices = np.minimum(
            np.rint(selectors[selected] * (self.config.selector_bins - 1)).astype(int),
            self.config.selector_bins - 1,
        )
        strengths = np.asarray(
            [
                self.rule_strength_grid[index, selector_index]
                for index, selector_index in zip(selected, selector_indices)
            ]
        )
        weighted_strength = float(np.dot(weights, strengths))
        coverage = min(float(np.sum(strengths)) / self.coverage_denominator, 1.0)

        if len(selected) > 1:
            submatrix = self.redundancy[np.ix_(selected, selected)]
            upper = submatrix[np.triu_indices(len(selected), k=1)]
            redundancy = float(np.mean(upper)) if len(upper) else 0.0
        else:
            redundancy = 0.0
        sparsity = len(selected) / self.n_features
        invalid_fraction = float(np.mean(strengths <= 1e-12))
        return (
            weighted_strength
            + self.config.coverage_weight * coverage
            - self.config.redundancy_weight * redundancy
            - self.config.sparsity_weight * sparsity
            - self.config.invalid_rule_weight * invalid_fraction
        )

    def result_from_position(
        self, position: np.ndarray, fitness: float, history: Sequence[float]
    ) -> ABCSearchResult:
        selected, weights, selectors = self.decode(position)
        return self.result_from_selection(selected, weights, selectors, fitness, history)

    def result_from_selection(
        self,
        selected: Sequence[int],
        weights: Sequence[float],
        selectors: Sequence[float],
        fitness: float,
        history: Sequence[float],
    ) -> ABCSearchResult:
        selected = np.asarray(selected, dtype=int)
        weights = np.asarray(weights, dtype=float)
        selectors = np.asarray(selectors, dtype=float)
        if len(selected) != len(weights):
            raise ValueError("selected and weights must have the same length.")
        if len(selectors) != self.n_features:
            raise ValueError("selectors must contain one value per feature.")
        if len(selected) < self.config.min_features or len(selected) > self.max_features:
            raise ValueError("Consensus feature count is outside configured bounds.")
        if np.any(weights < 0.0) or float(np.sum(weights)) <= 1e-15:
            raise ValueError("Consensus weights must be non-negative with a positive sum.")
        weights = weights / float(np.sum(weights))
        rules: list[FeatureValueRule] = []
        for index in selected:
            strength, mask, operator, value = self._rule_strength(index, selectors[index])
            support = float(np.mean(mask))
            mask_dist = self._distribution(self.y[mask])
            other_dist = self._distribution(self.y[~mask])
            differences = mask_dist - other_dist
            class_index = int(np.argmax(np.abs(differences)))
            if differences[class_index] < 0:
                mask = ~mask
                support = 1.0 - support
                operator = "<=" if operator == ">" else "!="
                differences = -differences
            display_value: object = value
            if self.categorical_mask[index]:
                display_value = self.category_decoder(index, value)
            rules.append(
                FeatureValueRule(
                    feature=self.feature_names[index],
                    operator=operator,
                    value=display_value,
                    favored_class=int(self.classes[class_index]),
                    class_rate_delta=float(differences[class_index]),
                    support=float(support),
                    strength=float(strength),
                )
            )

        initial_weights = {
            self.feature_names[index]: float(weight)
            for index, weight in zip(selected, weights)
        }
        return ABCSearchResult(
            selected_indices=tuple(int(index) for index in selected),
            selected_features=tuple(self.feature_names[index] for index in selected),
            initial_weights=initial_weights,
            rules=tuple(rules),
            fitness=float(fitness),
            fitness_history=tuple(float(value) for value in history),
            selection_frequency={
                self.feature_names[index]: 1.0 for index in selected
            },
        )


class ArtificialBeeColony:
    def __init__(self, config: ABCConfig) -> None:
        self.config = config

    def maximize(
        self, objective: Callable[[np.ndarray], float], dimension: int
    ) -> tuple[np.ndarray, float, list[float]]:
        rng = np.random.default_rng(self.config.random_state)
        population = rng.random((self.config.colony_size, dimension))
        fitness = np.asarray([objective(position) for position in population])
        trials = np.zeros(self.config.colony_size, dtype=int)

        best_index = int(np.argmax(fitness))
        best_position = population[best_index].copy()
        best_fitness = float(fitness[best_index])
        history = [best_fitness]

        def neighbor(index: int) -> np.ndarray:
            candidates = np.delete(np.arange(self.config.colony_size), index)
            partner = int(rng.choice(candidates))
            candidate = population[index].copy()
            gene = int(rng.integers(0, dimension))
            phi = float(rng.uniform(-1.0, 1.0))
            candidate[gene] += phi * (
                population[index, gene] - population[partner, gene]
            )
            return np.clip(candidate, 0.0, 1.0)

        def greedy(index: int, candidate: np.ndarray) -> None:
            candidate_fitness = float(objective(candidate))
            if candidate_fitness > fitness[index]:
                population[index] = candidate
                fitness[index] = candidate_fitness
                trials[index] = 0
            else:
                trials[index] += 1

        for _ in range(self.config.iterations):
            for index in range(self.config.colony_size):
                greedy(index, neighbor(index))

            shifted = fitness - np.min(fitness) + 1e-12
            probabilities = shifted / np.sum(shifted)
            for _ in range(self.config.colony_size):
                index = int(rng.choice(self.config.colony_size, p=probabilities))
                greedy(index, neighbor(index))

            abandoned = np.flatnonzero(trials >= self.config.abandonment_limit)
            for index in abandoned:
                population[index] = rng.random(dimension)
                fitness[index] = float(objective(population[index]))
                trials[index] = 0

            iteration_best = int(np.argmax(fitness))
            if fitness[iteration_best] > best_fitness:
                best_fitness = float(fitness[iteration_best])
                best_position = population[iteration_best].copy()
            history.append(best_fitness)

        return best_position, best_fitness, history


def run_abc_feature_value_search(
    objective: FeatureValueObjective,
    config: ABCConfig,
    progress: Callable[[str], None] | None = None,
) -> ABCSearchResult:
    def run_single(
        member_objective: FeatureValueObjective,
        member_config: ABCConfig,
    ) -> ABCSearchResult:
        position, fitness, history = ArtificialBeeColony(member_config).maximize(
            member_objective, member_objective.dimension
        )
        return member_objective.result_from_position(position, fitness, history)

    if config.stability_runs == 1:
        return run_single(objective, config)

    members: list[ABCSearchResult] = []
    rng = np.random.default_rng(config.random_state + 7919)
    single_base = replace(config, stability_runs=1)
    for run_index in range(config.stability_runs):
        if progress:
            progress(
                f"ABC stability run {run_index + 1}/{config.stability_runs}"
            )
        member_seed = config.random_state + 104729 * run_index
        member_config = replace(single_base, random_state=member_seed)
        if run_index == 0 or config.stability_subsample >= 1.0:
            member_objective = objective
        else:
            sampled_parts: list[np.ndarray] = []
            for class_value in objective.classes:
                class_indices = np.flatnonzero(objective.y == class_value)
                sample_size = min(
                    len(class_indices),
                    max(
                        2,
                        int(round(config.stability_subsample * len(class_indices))),
                    ),
                )
                sampled_parts.append(
                    rng.choice(class_indices, size=sample_size, replace=False)
                )
            sampled = np.concatenate(sampled_parts)
            rng.shuffle(sampled)
            member_objective = FeatureValueObjective(
                objective.X[sampled],
                objective.y[sampled],
                objective.feature_names,
                objective.categorical_mask,
                objective.category_decoder,
                member_config,
            )
        members.append(run_single(member_objective, member_config))

    feature_index = {name: index for index, name in enumerate(objective.feature_names)}
    counts = np.zeros(objective.n_features, dtype=float)
    weight_sums = np.zeros(objective.n_features, dtype=float)
    for member in members:
        for feature in member.selected_features:
            index = feature_index[feature]
            counts[index] += 1.0
            weight_sums[index] += float(member.initial_weights[feature])
    frequencies = counts / float(len(members))
    conditional_weights = np.divide(
        weight_sums,
        counts,
        out=np.zeros_like(weight_sums),
        where=counts > 0.0,
    )
    max_conditional = max(float(np.max(conditional_weights)), 1e-12)
    normalized_conditional = conditional_weights / max_conditional
    frequency_weight = float(config.stability_frequency_weight)
    consensus_scores = (
        frequency_weight * frequencies
        + (1.0 - frequency_weight) * normalized_conditional
    )
    subset_size = int(np.rint(np.median([len(member.selected_features) for member in members])))
    subset_size = int(np.clip(subset_size, config.min_features, objective.max_features))
    selected = np.argsort(consensus_scores)[-subset_size:]
    selected = selected[np.argsort(consensus_scores[selected])[::-1]]

    consensus_weights = frequencies[selected] * np.maximum(
        conditional_weights[selected], 1e-12
    )
    consensus_weights /= float(np.sum(consensus_weights))
    selectors = np.asarray(
        [
            objective.selector_grid[int(np.argmax(objective.rule_strength_grid[index]))]
            for index in range(objective.n_features)
        ],
        dtype=float,
    )
    position = np.zeros(objective.dimension, dtype=float)
    position[selected] = consensus_weights
    position[objective.n_features : 2 * objective.n_features] = selectors
    span = objective.max_features - config.min_features + 1
    position[-1] = (subset_size - config.min_features + 0.5) / span
    consensus_fitness = float(objective(position))
    consensus = objective.result_from_selection(
        selected,
        consensus_weights,
        selectors,
        consensus_fitness,
        members[0].fitness_history,
    )

    reference = members[0]
    allowed_drop = config.stability_fitness_tolerance * max(
        abs(reference.fitness), 1e-12
    )
    consensus_used = consensus_fitness >= reference.fitness - allowed_drop
    chosen = consensus if consensus_used else reference
    if progress:
        progress(
            "ABC stability consensus accepted"
            if consensus_used
            else "ABC stability consensus rejected by the fitness guard"
        )
    return replace(
        chosen,
        selection_frequency={
            name: float(frequencies[index])
            for index, name in enumerate(objective.feature_names)
        },
        ensemble_runs=len(members),
        ensemble_member_features=tuple(member.selected_features for member in members),
        consensus_used=bool(consensus_used),
        consensus_fitness=consensus_fitness,
        reference_fitness=float(reference.fitness),
    )
