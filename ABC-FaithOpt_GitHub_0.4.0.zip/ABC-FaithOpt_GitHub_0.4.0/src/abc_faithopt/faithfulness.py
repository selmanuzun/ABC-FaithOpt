from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Optional, Sequence

import numpy as np
from scipy.optimize import minimize
from scipy.stats import spearmanr
from sklearn.metrics import accuracy_score, log_loss


def safe_spearman(first: Sequence[float], second: Sequence[float]) -> float:
    left = np.asarray(first, dtype=float)
    right = np.asarray(second, dtype=float)
    if len(left) < 2 or np.ptp(left) <= 1e-12 or np.ptp(right) <= 1e-12:
        return 0.0
    value = spearmanr(left, right).statistic
    return float(value) if np.isfinite(value) else 0.0


def behavior_r2(observed: Sequence[float], predicted: Sequence[float]) -> float:
    actual = np.asarray(observed, dtype=float)
    estimate = np.asarray(predicted, dtype=float)
    if actual.shape != estimate.shape or actual.size < 2:
        raise ValueError("observed and predicted must have the same length >= 2.")
    residual = float(np.sum((actual - estimate) ** 2))
    total = float(np.sum((actual - np.mean(actual)) ** 2))
    if total <= 1e-15:
        return 1.0 if residual <= 1e-15 else 0.0
    return float(1.0 - residual / total)


@dataclass(frozen=True)
class PermutationImpactResult:
    """Single-feature diagnostic; it is not used as the optimization target."""

    impacts: dict[str, float]
    baseline: float
    metric: str
    runs_per_feature: int


def _resolve_groups(
    feature_names: Sequence[str],
    n_columns: int,
    feature_groups: Optional[Mapping[str, Sequence[int]]],
) -> dict[str, tuple[int, ...]]:
    if feature_groups is None:
        if n_columns != len(feature_names):
            raise ValueError(
                "feature_names must match X columns when feature_groups is absent."
            )
        groups = {
            feature: (index,) for index, feature in enumerate(feature_names)
        }
    else:
        groups = {
            feature: tuple(feature_groups[feature]) for feature in feature_names
        }
    for feature, group in groups.items():
        indices = np.asarray(group, dtype=int)
        if len(indices) == 0 or np.any(indices < 0) or np.any(indices >= n_columns):
            raise ValueError(f"Invalid model-column group for feature {feature!r}.")
    return groups


def permutation_impacts(
    *,
    model: object,
    X: np.ndarray,
    y: np.ndarray,
    feature_names: Sequence[str],
    feature_groups: Optional[Mapping[str, Sequence[int]]] = None,
    metric: str = "neg_log_loss",
    runs_per_feature: int = 20,
    random_state: int = 42,
) -> PermutationImpactResult:
    if runs_per_feature < 1:
        raise ValueError("runs_per_feature must be at least 1.")
    if metric not in {"neg_log_loss", "accuracy"}:
        raise ValueError("metric must be 'neg_log_loss' or 'accuracy'.")
    X = np.asarray(X, dtype=float)
    y = np.asarray(y)
    groups = _resolve_groups(feature_names, X.shape[1], feature_groups)

    if metric == "accuracy":
        baseline = float(accuracy_score(y, model.predict(X)))
    else:
        baseline = -float(
            log_loss(y, model.predict_proba(X), labels=model.classes_)
        )

    master_rng = np.random.default_rng(random_state)
    impacts: dict[str, float] = {}
    for feature in feature_names:
        group = np.asarray(groups[feature], dtype=int)
        values: list[float] = []
        for _ in range(runs_per_feature):
            permuted = X.copy()
            order = master_rng.permutation(len(permuted))
            permuted[:, group] = permuted[order][:, group]
            if metric == "accuracy":
                score = float(accuracy_score(y, model.predict(permuted)))
            else:
                score = -float(
                    log_loss(y, model.predict_proba(permuted), labels=model.classes_)
                )
            values.append(baseline - score)
        impacts[feature] = max(0.0, float(np.mean(values)))
    return PermutationImpactResult(
        impacts=impacts,
        baseline=baseline,
        metric=metric,
        runs_per_feature=runs_per_feature,
    )


@dataclass(frozen=True)
class MaskPatternSplit:
    calibration: np.ndarray
    guard: np.ndarray
    test: np.ndarray


def build_disjoint_mask_patterns(
    n_features: int,
    *,
    calibration_patterns: int = 32,
    guard_patterns: int = 24,
    test_patterns: int = 24,
    random_state: int = 42,
) -> MaskPatternSplit:
    """Create disjoint calibration/guard/test perturbation-dose masks.

    Calibration always contains every singleton so each weight is identifiable.
    Other masks contain at least two active features with independently sampled
    perturbation doses. Guard and test therefore exercise unseen combinations
    and unseen perturbation strengths, rather than merely new data rows.
    """

    if n_features < 3:
        raise ValueError(
            "Behavior reconstruction requires at least three selected features."
        )
    if calibration_patterns < n_features:
        raise ValueError("calibration_patterns must cover every singleton.")
    if guard_patterns < 2 or test_patterns < 2:
        raise ValueError("guard_patterns and test_patterns must be at least 2.")
    rng = np.random.default_rng(random_state)
    singletons = np.eye(n_features, dtype=float)
    used = {tuple(row) for row in singletons}

    def random_masks(count: int) -> np.ndarray:
        generated: list[np.ndarray] = []
        while len(generated) < count:
            active_count = int(rng.integers(2, n_features + 1))
            active = rng.choice(n_features, size=active_count, replace=False)
            mask = np.zeros(n_features, dtype=float)
            mask[active] = rng.uniform(0.25, 1.0, size=active_count)
            mask = np.round(mask, 8)
            signature = tuple(mask)
            if signature in used:
                continue
            used.add(signature)
            generated.append(mask)
        return np.vstack(generated)

    calibration_extra = random_masks(calibration_patterns - n_features)
    calibration = (
        singletons
        if len(calibration_extra) == 0
        else np.vstack([singletons, calibration_extra])
    )
    guard = random_masks(guard_patterns)
    test = random_masks(test_patterns)
    return MaskPatternSplit(calibration=calibration, guard=guard, test=test)


@dataclass(frozen=True)
class BehaviorPerturbationResult:
    masks: np.ndarray
    behavior_change: np.ndarray
    unique_patterns: np.ndarray
    pattern_mean_change: np.ndarray
    metric: str
    n_perturbations: int
    n_unique_patterns: int
    random_state: int


def _probability_l1_change(reference: np.ndarray, perturbed: np.ndarray) -> float:
    return float(np.mean(0.5 * np.sum(np.abs(reference - perturbed), axis=1)))


def _aggregate_patterns(
    masks: np.ndarray,
    changes: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    unique, inverse = np.unique(masks, axis=0, return_inverse=True)
    means = np.asarray(
        [float(np.mean(changes[inverse == index])) for index in range(len(unique))]
    )
    return unique.astype(float), means


def measure_masked_model_behavior(
    *,
    model: object,
    X: np.ndarray,
    feature_names: Sequence[str],
    mask_patterns: np.ndarray,
    feature_groups: Optional[Mapping[str, Sequence[int]]] = None,
    n_perturbations: int = 128,
    random_state: int = 42,
) -> BehaviorPerturbationResult:
    """Measure probability behavior under unseen single/multi-feature masks.

    Each observation is a feature-combination pattern plus fresh independent row
    permutations for its active features. Pattern means suppress Monte-Carlo
    noise and become the reconstruction optimizer/evaluator observations.
    """

    X = np.asarray(X, dtype=float)
    patterns = np.asarray(mask_patterns, dtype=float)
    if patterns.ndim != 2 or patterns.shape[1] != len(feature_names):
        raise ValueError("mask_patterns must have one column per feature.")
    if len(patterns) == 0:
        raise ValueError("mask_patterns cannot be empty.")
    if n_perturbations < len(patterns):
        raise ValueError(
            "n_perturbations must be at least the number of mask patterns."
        )
    groups = _resolve_groups(feature_names, X.shape[1], feature_groups)
    group_arrays = [np.asarray(groups[feature], dtype=int) for feature in feature_names]
    rng = np.random.default_rng(random_state)
    reference = np.asarray(model.predict_proba(X), dtype=float)

    pattern_order = np.concatenate(
        [
            rng.permutation(len(patterns))
            for _ in range(int(np.ceil(n_perturbations / len(patterns))))
        ]
    )[:n_perturbations]
    masks = patterns[pattern_order]
    changes = np.zeros(n_perturbations, dtype=float)
    for row, mask in enumerate(masks):
        perturbed_X = X.copy()
        for feature_index in np.flatnonzero(mask):
            dose = float(mask[feature_index])
            affected_count = max(1, int(round(dose * len(perturbed_X))))
            affected = rng.choice(
                len(perturbed_X), size=affected_count, replace=False
            )
            donors = rng.choice(
                len(perturbed_X), size=affected_count, replace=False
            )
            group = group_arrays[int(feature_index)]
            perturbed_X[np.ix_(affected, group)] = perturbed_X[np.ix_(donors, group)]
        perturbed = np.asarray(model.predict_proba(perturbed_X), dtype=float)
        changes[row] = _probability_l1_change(reference, perturbed)

    unique, pattern_means = _aggregate_patterns(masks, changes)
    return BehaviorPerturbationResult(
        masks=masks,
        behavior_change=changes,
        unique_patterns=unique,
        pattern_mean_change=pattern_means,
        metric="mean_probability_total_variation",
        n_perturbations=n_perturbations,
        n_unique_patterns=len(unique),
        random_state=random_state,
    )


@dataclass(frozen=True)
class FaithfulnessOptimizerConfig:
    steps: int = 500
    regularization: float = 0.05
    sensitivity: float | str | None = "auto"
    accept_only_if_improved: bool = True
    min_improvement: float = 0.01
    min_acceptable_faithfulness: float | None = None
    max_guard_nmae_increase: float | None = 0.0
    auto_sensitivity_min_pct: float = 10.0
    auto_sensitivity_max_pct: float = 100.0
    auto_sensitivity_penalty: float = 0.002
    auto_abc_colony_size: int = 10
    auto_abc_iterations: int = 12
    auto_abc_abandonment_limit: int = 4
    calibration_perturbations: int = 192
    guard_perturbations: int = 128
    test_perturbations: int = 128
    calibration_mask_patterns: int = 32
    guard_mask_patterns: int = 24
    test_mask_patterns: int = 24
    random_state: int = 42

    def __post_init__(self) -> None:
        if self.steps < 1:
            raise ValueError("steps must be positive.")
        if self.regularization < 0 or self.min_improvement < 0:
            raise ValueError("regularization and min_improvement must be non-negative.")
        sensitivity = self.sensitivity
        if isinstance(sensitivity, str):
            if sensitivity.lower() != "auto":
                raise ValueError("sensitivity must be numeric, 'auto', or None.")
        elif sensitivity is not None and not (0.0 <= sensitivity <= 100.0):
            raise ValueError("sensitivity must be in [0, 100], 'auto', or None.")
        if self.min_acceptable_faithfulness is not None and not (
            -1.0 <= self.min_acceptable_faithfulness <= 1.0
        ):
            raise ValueError(
                "min_acceptable_faithfulness must be in [-1, 1] or None."
            )
        if self.max_guard_nmae_increase is not None and self.max_guard_nmae_increase < 0:
            raise ValueError("max_guard_nmae_increase must be non-negative or None.")
        if not 0.0 <= self.auto_sensitivity_min_pct < self.auto_sensitivity_max_pct <= 100.0:
            raise ValueError("auto sensitivity range must satisfy 0 <= min < max <= 100.")
        if self.auto_sensitivity_penalty < 0:
            raise ValueError("auto_sensitivity_penalty must be non-negative.")
        if self.auto_abc_colony_size < 4 or self.auto_abc_iterations < 1:
            raise ValueError("auto ABC requires colony_size >= 4 and iterations >= 1.")
        if self.auto_abc_abandonment_limit < 1:
            raise ValueError("auto_abc_abandonment_limit must be positive.")
        if min(
            self.calibration_perturbations,
            self.guard_perturbations,
            self.test_perturbations,
        ) < 1:
            raise ValueError("All perturbation counts must be positive.")
        if self.calibration_mask_patterns < 3:
            raise ValueError("calibration_mask_patterns must be at least 3.")
        if self.guard_mask_patterns < 2 or self.test_mask_patterns < 2:
            raise ValueError("guard/test mask pattern counts must be at least 2.")


@dataclass(frozen=True)
class ReconstructionMetrics:
    r2: float
    mae: float
    normalized_mae: float
    spearman: float


def reconstruction_metrics(
    observed: Sequence[float],
    predicted: Sequence[float],
) -> ReconstructionMetrics:
    actual = np.asarray(observed, dtype=float)
    estimate = np.asarray(predicted, dtype=float)
    mae = float(np.mean(np.abs(actual - estimate)))
    denominator = max(float(np.mean(np.abs(actual))), 1e-12)
    return ReconstructionMetrics(
        r2=behavior_r2(actual, estimate),
        mae=mae,
        normalized_mae=mae / denominator,
        spearman=safe_spearman(actual, estimate),
    )


def _fit_global_scale(masks: np.ndarray, weights: np.ndarray, target: np.ndarray) -> float:
    raw = masks @ weights
    denominator = float(np.dot(raw, raw))
    if denominator <= 1e-15:
        return 0.0
    return max(0.0, float(np.dot(raw, target) / denominator))


def _predict_behavior(
    masks: np.ndarray,
    weights: np.ndarray,
    scale: float,
) -> np.ndarray:
    return float(scale) * (np.asarray(masks, dtype=float) @ weights)


@dataclass(frozen=True)
class FaithfulnessOptimizationResult:
    initial_weights: dict[str, float]
    candidate_weights: dict[str, float]
    final_weights: dict[str, float]
    initial_behavior_scale: float
    candidate_behavior_scale: float
    final_behavior_scale: float
    calibration_initial: ReconstructionMetrics
    calibration_candidate: ReconstructionMetrics
    guard_initial: ReconstructionMetrics
    guard_candidate: ReconstructionMetrics
    guard_final: ReconstructionMetrics
    guard_improvement: float
    guard_nmae_change: float
    accepted: bool
    reason: str
    mean_weight_change_pct: float
    max_weight_change_pct: float
    minimum_acceptable_faithfulness: float | None
    absolute_threshold_met: bool
    nmae_guard_met: bool
    requested_sensitivity_mode: str
    selected_sensitivity_pct: float | None
    sensitivity_boundary_hit: bool
    sensitivity_search_evaluations: int
    sensitivity_search_history: tuple[float, ...]
    optimizer_success: bool
    optimizer_message: str


def optimize_behavior_reconstruction(
    initial_weights: Mapping[str, float],
    calibration: BehaviorPerturbationResult,
    guard: BehaviorPerturbationResult,
    config: FaithfulnessOptimizerConfig,
) -> FaithfulnessOptimizationResult:
    """Calibrate ABC weights by reconstructing multi-mask model behavior."""

    features = list(initial_weights)
    n_features = len(features)
    if calibration.unique_patterns.shape[1] != n_features:
        raise ValueError("Calibration masks do not match initial weights.")
    if guard.unique_patterns.shape[1] != n_features:
        raise ValueError("Guard masks do not match initial weights.")
    reference = np.asarray(
        [max(float(initial_weights[feature]), 0.0) for feature in features],
        dtype=float,
    )
    if np.sum(reference) <= 1e-15:
        raise ValueError("At least one ABC initial weight must be positive.")

    X_cal = calibration.unique_patterns
    y_cal = calibration.pattern_mean_change
    X_guard = guard.unique_patterns
    y_guard = guard.pattern_mean_change
    initial_scale = _fit_global_scale(X_cal, reference, y_cal)
    initial_cal_pred = _predict_behavior(X_cal, reference, initial_scale)
    initial_guard_pred = _predict_behavior(X_guard, reference, initial_scale)
    calibration_initial = reconstruction_metrics(y_cal, initial_cal_pred)
    guard_initial = reconstruction_metrics(y_guard, initial_guard_pred)

    target_variance = max(float(np.var(y_cal)), 1e-12)
    safe_reference = np.where(reference > 1e-12, reference, 1.0)

    def objective(candidate: np.ndarray) -> float:
        scale = _fit_global_scale(X_cal, candidate, y_cal)
        predicted = _predict_behavior(X_cal, candidate, scale)
        reconstruction = float(np.mean((y_cal - predicted) ** 2)) / target_variance
        relative_change = (candidate - reference) / safe_reference
        regularization = config.regularization * float(
            np.mean(relative_change**2)
        )
        return reconstruction + regularization

    def solve(sensitivity_pct: float | None):
        if sensitivity_pct is None:
            bounds = [
                (0.0, None) if value > 0.0 else (0.0, 0.0)
                for value in reference
            ]
        else:
            ratio = float(sensitivity_pct) / 100.0
            bounds = [
                (
                    value * max(0.0, 1.0 - ratio),
                    value * (1.0 + ratio),
                )
                if value > 0.0
                else (0.0, 0.0)
                for value in reference
            ]
        optimized = minimize(
            objective,
            reference,
            method="L-BFGS-B",
            bounds=bounds,
            options={"maxiter": config.steps, "ftol": 1e-12, "gtol": 1e-8},
        )
        candidate = np.asarray(optimized.x, dtype=float)
        return optimized, candidate, float(objective(candidate))

    sensitivity = config.sensitivity
    requested_mode = "auto" if isinstance(sensitivity, str) else (
        "unbounded" if sensitivity is None else "fixed"
    )
    sensitivity_history: tuple[float, ...] = ()
    sensitivity_evaluations = 1
    sensitivity_boundary_hit = False

    if requested_mode == "auto":
        lower = float(config.auto_sensitivity_min_pct)
        upper = float(config.auto_sensitivity_max_pct)
        rng = np.random.default_rng(config.random_state)
        food_count = max(2, config.auto_abc_colony_size // 2)
        cache: dict[float, tuple[object, np.ndarray, float, float]] = {}

        def evaluate_sensitivity(value: float):
            clipped = float(np.clip(value, lower, upper))
            key = round(clipped, 6)
            if key not in cache:
                result, candidate, base_score = solve(clipped)
                score = base_score + config.auto_sensitivity_penalty * (
                    clipped / 100.0
                ) ** 2
                cache[key] = (result, candidate, float(score), clipped)
            return cache[key]

        anchors = np.asarray([lower, upper, 30.0, 50.0], dtype=float)
        positions = rng.uniform(lower, upper, size=food_count)
        for index in range(min(food_count, len(anchors))):
            positions[index] = float(np.clip(anchors[index], lower, upper))
        scores = np.asarray([evaluate_sensitivity(x)[2] for x in positions])
        trials = np.zeros(food_count, dtype=int)
        best_history: list[float] = []

        def greedy_update(index: int) -> None:
            partners = np.delete(np.arange(food_count), index)
            partner = int(rng.choice(partners))
            proposal = positions[index] + rng.uniform(-1.0, 1.0) * (
                positions[index] - positions[partner]
            )
            proposal = float(np.clip(proposal, lower, upper))
            proposal_score = evaluate_sensitivity(proposal)[2]
            if proposal_score < scores[index] - 1e-15:
                positions[index] = proposal
                scores[index] = proposal_score
                trials[index] = 0
            else:
                trials[index] += 1

        for _ in range(config.auto_abc_iterations):
            for index in range(food_count):
                greedy_update(index)
            shifted = scores - float(np.min(scores))
            fitness = 1.0 / (1.0 + shifted)
            probabilities = fitness / float(np.sum(fitness))
            for _ in range(food_count):
                greedy_update(int(rng.choice(food_count, p=probabilities)))
            for index in np.flatnonzero(
                trials >= config.auto_abc_abandonment_limit
            ):
                positions[index] = rng.uniform(lower, upper)
                scores[index] = evaluate_sensitivity(positions[index])[2]
                trials[index] = 0
            best_history.append(float(positions[int(np.argmin(scores))]))

        best_index = int(np.argmin(scores))
        selected_sensitivity = float(positions[best_index])
        optimized, candidate_values, _, _ = evaluate_sensitivity(selected_sensitivity)
        sensitivity_history = tuple(best_history)
        sensitivity_evaluations = len(cache)
        sensitivity_boundary_hit = bool(
            selected_sensitivity <= lower + 0.5
            or selected_sensitivity >= upper - 0.5
        )
    else:
        selected_sensitivity = None if sensitivity is None else float(sensitivity)
        optimized, candidate_values, _ = solve(selected_sensitivity)

    candidate_values = np.asarray(optimized.x, dtype=float)
    candidate_scale = _fit_global_scale(X_cal, candidate_values, y_cal)
    candidate_cal_pred = _predict_behavior(X_cal, candidate_values, candidate_scale)
    candidate_guard_pred = _predict_behavior(X_guard, candidate_values, candidate_scale)
    calibration_candidate = reconstruction_metrics(y_cal, candidate_cal_pred)
    guard_candidate = reconstruction_metrics(y_guard, candidate_guard_pred)
    improvement = float(guard_candidate.r2 - guard_initial.r2)
    nmae_change = float(
        guard_candidate.normalized_mae - guard_initial.normalized_mae
    )
    improvement_met = (
        improvement >= config.min_improvement or not config.accept_only_if_improved
    )
    absolute_threshold_met = (
        config.min_acceptable_faithfulness is None
        or guard_candidate.r2 >= config.min_acceptable_faithfulness
    )
    nmae_guard_met = (
        config.max_guard_nmae_increase is None
        or nmae_change <= config.max_guard_nmae_increase + 1e-12
    )
    accepted = bool(improvement_met and absolute_threshold_met and nmae_guard_met)
    if not absolute_threshold_met:
        reason = "unseen_mask_reconstruction_below_threshold"
    elif not improvement_met:
        reason = "unseen_mask_reconstruction_improvement_below_threshold"
    elif not nmae_guard_met:
        reason = "unseen_mask_normalized_mae_worsened"
    elif config.accept_only_if_improved:
        reason = "all_unseen_mask_acceptance_thresholds_met"
    else:
        reason = "improvement_guard_disabled_absolute_threshold_met"

    candidate = {
        feature: float(value) for feature, value in zip(features, candidate_values)
    }
    initial = {feature: float(initial_weights[feature]) for feature in features}
    final = candidate if accepted else initial
    final_scale = candidate_scale if accepted else initial_scale
    guard_final = guard_candidate if accepted else guard_initial
    changes = np.zeros_like(reference)
    nonzero = reference > 1e-12
    changes[nonzero] = (
        np.abs(candidate_values[nonzero] - reference[nonzero])
        / reference[nonzero]
        * 100.0
    )
    return FaithfulnessOptimizationResult(
        initial_weights=initial,
        candidate_weights=candidate,
        final_weights=final,
        initial_behavior_scale=initial_scale,
        candidate_behavior_scale=candidate_scale,
        final_behavior_scale=final_scale,
        calibration_initial=calibration_initial,
        calibration_candidate=calibration_candidate,
        guard_initial=guard_initial,
        guard_candidate=guard_candidate,
        guard_final=guard_final,
        guard_improvement=improvement,
        guard_nmae_change=nmae_change,
        accepted=accepted,
        reason=reason,
        mean_weight_change_pct=float(np.mean(changes)),
        max_weight_change_pct=float(np.max(changes)),
        minimum_acceptable_faithfulness=config.min_acceptable_faithfulness,
        absolute_threshold_met=absolute_threshold_met,
        nmae_guard_met=bool(nmae_guard_met),
        requested_sensitivity_mode=requested_mode,
        selected_sensitivity_pct=selected_sensitivity,
        sensitivity_boundary_hit=sensitivity_boundary_hit,
        sensitivity_search_evaluations=sensitivity_evaluations,
        sensitivity_search_history=sensitivity_history,
        optimizer_success=bool(optimized.success),
        optimizer_message=str(optimized.message),
    )


def evaluate_behavior_reconstruction(
    weights: Mapping[str, float],
    scale: float,
    behavior: BehaviorPerturbationResult,
) -> ReconstructionMetrics:
    values = np.asarray([float(weights[feature]) for feature in weights])
    predicted = _predict_behavior(behavior.unique_patterns, values, scale)
    return reconstruction_metrics(behavior.pattern_mean_change, predicted)
