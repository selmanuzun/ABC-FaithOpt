from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from .abc import ABCConfig
from .datasets import available_uci_datasets, fetch_uci_dataset
from .faithfulness import FaithfulnessOptimizerConfig
from .pipeline import ABCFaithOpt, ABCFaithOptConfig


def _optional_percentage(value: str) -> float | str | None:
    if value.strip().lower() == "auto":
        return "auto"
    if value.strip().lower() in {"none", "off", "unbounded"}:
        return None
    parsed = float(value)
    if not 0.0 <= parsed <= 100.0:
        raise argparse.ArgumentTypeError(
            "percentage must be in [0, 100], 'auto', or 'none'"
        )
    return parsed


def _optional_faithfulness(value: str) -> float | None:
    if value.strip().lower() in {"none", "off"}:
        return None
    parsed = float(value)
    if not -1.0 <= parsed <= 1.0:
        raise argparse.ArgumentTypeError("faithfulness must be in [-1, 1] or 'none'")
    return parsed


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run independent ABC-FaithOpt XAI.")
    source = parser.add_mutually_exclusive_group()
    source.add_argument(
        "--dataset",
        choices=sorted(available_uci_datasets()),
        default="breast_cancer",
        help="Official UCI dataset (default: breast_cancer)",
    )
    source.add_argument("--csv", type=Path, default=None)
    parser.add_argument("--target", default=None, help="Required with --csv")
    parser.add_argument("--categorical", default=None, help="Comma-separated names")
    parser.add_argument("--cache-dir", type=Path, default=None)
    parser.add_argument("--force-download", action="store_true")
    parser.add_argument("--colony-size", type=int, default=24)
    parser.add_argument("--iterations", type=int, default=40)
    parser.add_argument("--min-features", type=int, default=3)
    parser.add_argument("--max-features", type=int, default=7)
    parser.add_argument("--selector-bins", type=int, default=101)
    parser.add_argument("--abc-stability-runs", type=int, default=7)
    parser.add_argument("--abc-stability-subsample", type=float, default=0.80)
    parser.add_argument("--abc-stability-frequency-weight", type=float, default=0.75)
    parser.add_argument("--abc-stability-fitness-tolerance", type=float, default=0.05)
    parser.add_argument("--permutation-runs", type=int, default=30)
    parser.add_argument("--optimizer-steps", type=int, default=500)
    parser.add_argument("--calibration-perturbations", type=int, default=192)
    parser.add_argument("--guard-perturbations", type=int, default=128)
    parser.add_argument("--test-perturbations", type=int, default=128)
    parser.add_argument("--calibration-mask-patterns", type=int, default=32)
    parser.add_argument("--guard-mask-patterns", type=int, default=24)
    parser.add_argument("--test-mask-patterns", type=int, default=24)
    parser.add_argument(
        "--sensitivity",
        "--max-weight-change-pct",
        dest="sensitivity",
        type=_optional_percentage,
        default="auto",
        help="0..100, 'auto', or 'none' (default: auto)",
    )
    parser.add_argument(
        "--minimum-faithfulness",
        type=_optional_faithfulness,
        default=None,
        help="Optional absolute validation-guard threshold (default: none)",
    )
    parser.add_argument("--auto-sensitivity-min-pct", type=float, default=10.0)
    parser.add_argument("--auto-sensitivity-max-pct", type=float, default=100.0)
    parser.add_argument("--output", type=Path, default=Path("abc_faithopt_result.json"))
    return parser


def main() -> None:
    args = build_parser().parse_args()
    dataset_metadata: dict[str, object]
    if args.csv is not None:
        if args.target is None:
            raise SystemExit("--target is required when --csv is used.")
        data = pd.read_csv(args.csv)
        if args.target not in data:
            raise SystemExit(f"Target column {args.target!r} was not found.")
        X = data.drop(columns=[args.target])
        y = data[args.target]
        categorical = (
            [value.strip() for value in args.categorical.split(",") if value.strip()]
            if args.categorical
            else None
        )
        dataset_metadata = {"source": str(args.csv), "target": args.target}
    else:
        uci = fetch_uci_dataset(
            args.dataset,
            cache_dir=args.cache_dir,
            force_download=args.force_download,
        )
        X, y = uci.X, uci.y
        categorical = list(uci.categorical_features)
        dataset_metadata = {
            "source": "UCI Machine Learning Repository",
            "name": uci.name,
            "uci_id": uci.uci_id,
            "citation": uci.citation,
            "license": uci.license,
        }
    config = ABCFaithOptConfig(
        permutation_runs=args.permutation_runs,
        abc=ABCConfig(
            colony_size=args.colony_size,
            iterations=args.iterations,
            min_features=args.min_features,
            max_features=args.max_features,
            selector_bins=args.selector_bins,
            stability_runs=args.abc_stability_runs,
            stability_subsample=args.abc_stability_subsample,
            stability_frequency_weight=args.abc_stability_frequency_weight,
            stability_fitness_tolerance=args.abc_stability_fitness_tolerance,
        ),
        optimizer=FaithfulnessOptimizerConfig(
            steps=args.optimizer_steps,
            sensitivity=args.sensitivity,
            min_acceptable_faithfulness=args.minimum_faithfulness,
            auto_sensitivity_min_pct=args.auto_sensitivity_min_pct,
            auto_sensitivity_max_pct=args.auto_sensitivity_max_pct,
            calibration_perturbations=args.calibration_perturbations,
            guard_perturbations=args.guard_perturbations,
            test_perturbations=args.test_perturbations,
            calibration_mask_patterns=args.calibration_mask_patterns,
            guard_mask_patterns=args.guard_mask_patterns,
            test_mask_patterns=args.test_mask_patterns,
        ),
    )
    explainer = ABCFaithOpt(config).fit(
        X,
        y,
        categorical_features=categorical,
    )
    result = explainer.explain_global()
    result.metadata["dataset"] = dataset_metadata
    result.save_json(args.output)
    print(result.explanation.to_string(index=False))
    print("\nMetrics:")
    for name, value in result.metrics.items():
        print(f"  {name}: {value:.4f}")
    print(f"\nOptimization accepted: {result.optimization.accepted}")
    print(f"Acceptance reason: {result.optimization.reason}")
    print(f"Independent test audit: {result.metadata['test_audit_status']}")
    print(
        "Maximum weight change (%): "
        f"{result.optimization.max_weight_change_pct:.4f}"
    )
    print(
        "Selected sensitivity (%): "
        f"{result.optimization.selected_sensitivity_pct}"
    )
    print(f"Saved: {args.output.resolve()}")


if __name__ == "__main__":
    main()
