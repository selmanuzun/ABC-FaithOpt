from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Optional

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, log_loss
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from .abc import (
    ABCConfig,
    ABCSearchResult,
    FeatureValueObjective,
    run_abc_feature_value_search,
)
from .faithfulness import (
    FaithfulnessOptimizationResult,
    FaithfulnessOptimizerConfig,
    build_disjoint_mask_patterns,
    evaluate_behavior_reconstruction,
    measure_masked_model_behavior,
    optimize_behavior_reconstruction,
    permutation_impacts,
    safe_spearman,
)
from .preprocessing import TabularPreprocessor


@dataclass(frozen=True)
class ABCFaithOptConfig:
    test_size: float = 0.20
    validation_size: float = 0.30
    random_state: int = 42
    permutation_runs: int = 20
    faithfulness_metric: str = "neg_log_loss"
    logistic_c: float = 1.0
    logistic_max_iter: int = 2000
    class_weight: str | None = "balanced"
    abc: ABCConfig = field(default_factory=ABCConfig)
    optimizer: FaithfulnessOptimizerConfig = field(
        default_factory=FaithfulnessOptimizerConfig
    )

    def __post_init__(self) -> None:
        if not 0.0 < self.test_size < 1.0:
            raise ValueError("test_size must be between 0 and 1.")
        if not 0.0 < self.validation_size < 1.0:
            raise ValueError("validation_size must be between 0 and 1.")
        if self.test_size + self.validation_size >= 1.0:
            raise ValueError("test_size + validation_size must be below 1.")
        if self.permutation_runs < 1:
            raise ValueError("permutation_runs must be at least 1.")


@dataclass
class ABCFaithOptResult:
    explanation: pd.DataFrame
    selected_features: list[str]
    abc_search: ABCSearchResult
    optimization: FaithfulnessOptimizationResult
    metrics: dict[str, float]
    split_sizes: dict[str, int]
    target_classes: list[Any]
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "selected_features": self.selected_features,
            "explanation": json.loads(self.explanation.to_json(orient="records")),
            "abc_search": asdict(self.abc_search),
            "optimization": asdict(self.optimization),
            "metrics": self.metrics,
            "split_sizes": self.split_sizes,
            "target_classes": self.target_classes,
            "metadata": self.metadata,
        }

    def save_json(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(
                self.to_dict(),
                indent=2,
                ensure_ascii=False,
                default=str,
                allow_nan=False,
            ),
            encoding="utf-8",
        )


class ABCFaithOpt:
    """ABC-initialized, Logistic-Regression-faithful global XAI model."""

    def __init__(self, config: Optional[ABCFaithOptConfig] = None) -> None:
        self.config = config or ABCFaithOptConfig()
        self.preprocessor_: Optional[TabularPreprocessor] = None
        self.label_encoder_: Optional[LabelEncoder] = None
        self.model_: Optional[LogisticRegression] = None
        self.result_: Optional[ABCFaithOptResult] = None
        self.selected_model_columns_: Optional[np.ndarray] = None

    def fit(
        self,
        X: pd.DataFrame,
        y: Iterable[Any],
        *,
        categorical_features: Optional[Iterable[str]] = None,
    ) -> "ABCFaithOpt":
        if not isinstance(X, pd.DataFrame) or X.empty:
            raise ValueError("X must be a non-empty pandas DataFrame.")
        y_array = np.asarray(list(y))
        if len(X) != len(y_array):
            raise ValueError("X and y must have the same number of rows.")

        encoder = LabelEncoder()
        encoded_y = encoder.fit_transform(y_array)
        indices = np.arange(len(X))
        train_idx, remainder_idx = train_test_split(
            indices,
            test_size=self.config.test_size + self.config.validation_size,
            random_state=self.config.random_state,
            stratify=encoded_y,
        )
        test_fraction_of_remainder = self.config.test_size / (
            self.config.test_size + self.config.validation_size
        )
        validation_idx, test_idx = train_test_split(
            remainder_idx,
            test_size=test_fraction_of_remainder,
            random_state=self.config.random_state,
            stratify=encoded_y[remainder_idx],
        )

        X_train = X.iloc[train_idx].reset_index(drop=True)
        calibration_idx, guard_idx = train_test_split(
            validation_idx,
            test_size=0.50,
            random_state=self.config.random_state,
            stratify=encoded_y[validation_idx],
        )
        X_calibration = X.iloc[calibration_idx].reset_index(drop=True)
        X_guard = X.iloc[guard_idx].reset_index(drop=True)
        X_test = X.iloc[test_idx].reset_index(drop=True)
        y_train = encoded_y[train_idx]
        y_calibration = encoded_y[calibration_idx]
        y_guard = encoded_y[guard_idx]
        y_test = encoded_y[test_idx]

        preprocessor = TabularPreprocessor(categorical_features).fit(X_train)
        train_rules = preprocessor.transform_rules(X_train)
        objective = FeatureValueObjective(
            train_rules,
            y_train,
            preprocessor.feature_names_,
            preprocessor.categorical_mask(),
            preprocessor.decode_category,
            self.config.abc,
        )
        abc_result = run_abc_feature_value_search(objective, self.config.abc)
        selected_indices = np.asarray(abc_result.selected_indices, dtype=int)

        full_groups = preprocessor.model_group_indices(selected_indices)
        selected_model_columns = np.asarray(
            [
                column
                for feature in abc_result.selected_features
                for column in full_groups[feature]
            ],
            dtype=int,
        )
        relative_groups: dict[str, tuple[int, ...]] = {}
        cursor = 0
        for feature in abc_result.selected_features:
            width = len(full_groups[feature])
            relative_groups[feature] = tuple(range(cursor, cursor + width))
            cursor += width

        train_model = preprocessor.transform_model(X_train)[:, selected_model_columns]
        calibration_model = preprocessor.transform_model(X_calibration)[:, selected_model_columns]
        guard_model = preprocessor.transform_model(X_guard)[:, selected_model_columns]
        test_model = preprocessor.transform_model(X_test)[:, selected_model_columns]
        model = LogisticRegression(
            C=self.config.logistic_c,
            max_iter=self.config.logistic_max_iter,
            class_weight=self.config.class_weight,
            random_state=self.config.random_state,
            solver="lbfgs",
        )
        model.fit(train_model, y_train)

        pattern_split = build_disjoint_mask_patterns(
            len(abc_result.selected_features),
            calibration_patterns=max(
                self.config.optimizer.calibration_mask_patterns,
                len(abc_result.selected_features),
            ),
            guard_patterns=self.config.optimizer.guard_mask_patterns,
            test_patterns=self.config.optimizer.test_mask_patterns,
            random_state=self.config.random_state + 71,
        )
        calibration_behavior = measure_masked_model_behavior(
            model=model,
            X=calibration_model,
            feature_names=abc_result.selected_features,
            feature_groups=relative_groups,
            mask_patterns=pattern_split.calibration,
            n_perturbations=max(
                self.config.optimizer.calibration_perturbations,
                len(pattern_split.calibration),
            ),
            random_state=self.config.random_state + 101,
        )
        guard_behavior = measure_masked_model_behavior(
            model=model,
            X=guard_model,
            feature_names=abc_result.selected_features,
            feature_groups=relative_groups,
            mask_patterns=pattern_split.guard,
            n_perturbations=max(
                self.config.optimizer.guard_perturbations,
                len(pattern_split.guard),
            ),
            random_state=self.config.random_state + 151,
        )
        optimization = optimize_behavior_reconstruction(
            abc_result.initial_weights,
            calibration_behavior,
            guard_behavior,
            self.config.optimizer,
        )
        test_behavior = measure_masked_model_behavior(
            model=model,
            X=test_model,
            feature_names=abc_result.selected_features,
            feature_groups=relative_groups,
            mask_patterns=pattern_split.test,
            n_perturbations=max(
                self.config.optimizer.test_perturbations,
                len(pattern_split.test),
            ),
            random_state=self.config.random_state + 202,
        )
        test_reconstruction_initial = evaluate_behavior_reconstruction(
            optimization.initial_weights,
            optimization.initial_behavior_scale,
            test_behavior,
        )
        test_reconstruction_candidate = evaluate_behavior_reconstruction(
            optimization.candidate_weights,
            optimization.candidate_behavior_scale,
            test_behavior,
        )
        test_reconstruction_final = evaluate_behavior_reconstruction(
            optimization.final_weights,
            optimization.final_behavior_scale,
            test_behavior,
        )
        test_threshold = self.config.optimizer.min_acceptable_faithfulness
        test_r2_improvement = float(
            test_reconstruction_final.r2 - test_reconstruction_initial.r2
        )
        test_nmae_change = float(
            test_reconstruction_final.normalized_mae
            - test_reconstruction_initial.normalized_mae
        )
        test_relative_improvement_met = bool(
            optimization.accepted
            and test_r2_improvement >= self.config.optimizer.min_improvement
            and (
                self.config.optimizer.max_guard_nmae_increase is None
                or test_nmae_change
                <= self.config.optimizer.max_guard_nmae_increase + 1e-12
            )
        )
        test_audit_threshold_met = bool(
            test_relative_improvement_met
            and (
                test_threshold is None
                or test_reconstruction_final.r2 >= test_threshold
            )
        )

        # A separate single-feature permutation diagnostic is retained only for
        # comparison with v0.2. It does not train, accept, or reject the weights.
        test_impacts = permutation_impacts(
            model=model,
            X=test_model,
            y=y_test,
            feature_names=abc_result.selected_features,
            feature_groups=relative_groups,
            metric=self.config.faithfulness_metric,
            runs_per_feature=self.config.permutation_runs,
            random_state=self.config.random_state + 252,
        )

        initial_vector = [
            abc_result.initial_weights[feature] for feature in abc_result.selected_features
        ]
        final_vector = [
            optimization.final_weights[feature] for feature in abc_result.selected_features
        ]
        test_target = [test_impacts.impacts[feature] for feature in abc_result.selected_features]
        diagnostic_rank_before = safe_spearman(initial_vector, test_target)
        diagnostic_rank_final = safe_spearman(final_vector, test_target)

        probabilities = model.predict_proba(test_model)
        predictions = model.predict(test_model)
        metrics = {
            "test_accuracy": float(accuracy_score(y_test, predictions)),
            "test_balanced_accuracy": float(
                balanced_accuracy_score(y_test, predictions)
            ),
            "test_neg_log_loss": -float(
                log_loss(y_test, probabilities, labels=model.classes_)
            ),
            "calibration_behavior_r2_initial": optimization.calibration_initial.r2,
            "calibration_behavior_r2_candidate": (
                optimization.calibration_candidate.r2
            ),
            "validation_guard_faithfulness_initial": optimization.guard_initial.r2,
            "validation_guard_faithfulness_candidate": (
                optimization.guard_candidate.r2
            ),
            "validation_guard_faithfulness_final": optimization.guard_final.r2,
            "validation_guard_behavior_mae_final": optimization.guard_final.mae,
            "validation_guard_behavior_spearman_final": (
                optimization.guard_final.spearman
            ),
            "test_faithfulness_initial": test_reconstruction_initial.r2,
            "test_faithfulness_candidate": test_reconstruction_candidate.r2,
            "test_faithfulness_final": test_reconstruction_final.r2,
            "test_faithfulness_change": (
                test_r2_improvement
            ),
            "test_behavior_normalized_mae_change": test_nmae_change,
            "test_behavior_mae_final": test_reconstruction_final.mae,
            "test_behavior_normalized_mae_final": (
                test_reconstruction_final.normalized_mae
            ),
            "test_behavior_spearman_final": test_reconstruction_final.spearman,
            "diagnostic_test_singleton_rank_initial": diagnostic_rank_before,
            "diagnostic_test_singleton_rank_final": diagnostic_rank_final,
        }

        coefficients = np.asarray(model.coef_, dtype=float)
        coefficient_magnitude: dict[str, float] = {}
        coefficient_direction: dict[str, float | None] = {}
        categorical = set(preprocessor.categorical_features_)
        for feature in abc_result.selected_features:
            group = np.asarray(relative_groups[feature], dtype=int)
            coefficient_magnitude[feature] = float(np.linalg.norm(coefficients[:, group]))
            coefficient_direction[feature] = (
                float(np.sign(coefficients[0, group[0]]))
                if coefficients.shape[0] == 1 and feature not in categorical
                else None
            )
        final_total = max(sum(optimization.final_weights.values()), 1e-12)
        rule_by_feature = {rule.feature: rule for rule in abc_result.rules}
        records: list[dict[str, Any]] = []
        for feature in abc_result.selected_features:
            rule = rule_by_feature[feature]
            favored_class = encoder.inverse_transform([int(rule.favored_class)])[0]
            records.append(
                {
                    "feature": feature,
                    "value_rule": f"{feature} {rule.operator} {rule.value}",
                    "favored_class": favored_class,
                    "rule_strength": rule.strength,
                    "rule_support": rule.support,
                    "class_rate_delta": rule.class_rate_delta,
                    "abc_initial_weight": abc_result.initial_weights[feature],
                    "abc_selection_frequency": abc_result.selection_frequency.get(
                        feature, 1.0
                    ),
                    "faithful_weight": optimization.final_weights[feature],
                    "faithful_share": optimization.final_weights[feature] / final_total,
                    "diagnostic_test_singleton_permutation_impact": (
                        test_impacts.impacts[feature]
                    ),
                    "logistic_coefficient_magnitude": float(
                        coefficient_magnitude[feature]
                    ),
                    "logistic_direction": coefficient_direction[feature],
                }
            )
        explanation = pd.DataFrame(records).sort_values(
            "faithful_weight", ascending=False, ignore_index=True
        )

        self.preprocessor_ = preprocessor
        self.label_encoder_ = encoder
        self.model_ = model
        self.selected_model_columns_ = selected_model_columns
        self.result_ = ABCFaithOptResult(
            explanation=explanation,
            selected_features=list(abc_result.selected_features),
            abc_search=abc_result,
            optimization=optimization,
            metrics=metrics,
            split_sizes={
                "train": len(train_idx),
                "calibration": len(calibration_idx),
                "validation_guard": len(guard_idx),
                "test": len(test_idx),
            },
            target_classes=encoder.classes_.tolist(),
            metadata={
                "algorithm": "ABC-FaithOpt",
                "version": "0.4.0",
                "predictive_model": "LogisticRegression",
                "abc_scope": "train_only",
                "abc_stability_runs": abc_result.ensemble_runs,
                "abc_stability_subsample": self.config.abc.stability_subsample,
                "abc_consensus_used": abc_result.consensus_used,
                "abc_consensus_fitness": abc_result.consensus_fitness,
                "abc_reference_fitness": abc_result.reference_fitness,
                "faithfulness_optimization_scope": "calibration_only",
                "acceptance_guard_scope": "held_out_validation_guard_only",
                "final_evaluation_scope": "untouched_test",
                "faithfulness_definition": (
                    "R-squared reconstruction of mean probability total-variation "
                    "under held-out multi-feature perturbation masks"
                ),
                "optimization_target": (
                    "multi-mask model-behavior reconstruction with an ABC-weight "
                    "proximity penalty"
                ),
                "rank_metric_is_diagnostic_only": True,
                "mask_pattern_overlap": False,
                "mask_patterns": {
                    "calibration": int(len(pattern_split.calibration)),
                    "validation_guard": int(len(pattern_split.guard)),
                    "test": int(len(pattern_split.test)),
                },
                "perturbation_realizations": {
                    "calibration": calibration_behavior.n_perturbations,
                    "validation_guard": guard_behavior.n_perturbations,
                    "test": test_behavior.n_perturbations,
                },
                "causal_claim": False,
                "test_is_reporting_only": True,
                "test_audit_threshold_met": test_audit_threshold_met,
                "test_audit_status": (
                    "candidate_rejected"
                    if not optimization.accepted
                    else ("passed" if test_audit_threshold_met else "failed")
                ),
                "minimum_guard_faithfulness": (
                    self.config.optimizer.min_acceptable_faithfulness
                ),
                "max_weight_change_pct": (
                    self.config.optimizer.sensitivity
                ),
                "sensitivity_mode": optimization.requested_sensitivity_mode,
                "selected_sensitivity_pct": optimization.selected_sensitivity_pct,
                "auto_sensitivity_max_pct": (
                    self.config.optimizer.auto_sensitivity_max_pct
                ),
                "sensitivity_boundary_hit": optimization.sensitivity_boundary_hit,
                "guard_acceptance_is_relative": True,
                "guard_max_nmae_increase": (
                    self.config.optimizer.max_guard_nmae_increase
                ),
                "categorical_features": preprocessor.categorical_features_,
            },
        )
        return self

    def explain_global(self) -> ABCFaithOptResult:
        if self.result_ is None:
            raise RuntimeError("Call fit before explain_global.")
        return self.result_

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        if (
            self.result_ is None
            or self.preprocessor_ is None
            or self.model_ is None
            or self.selected_model_columns_ is None
        ):
            raise RuntimeError("Call fit before predict.")
        encoded = self.model_.predict(
            self.preprocessor_.transform_model(X)[:, self.selected_model_columns_]
        )
        assert self.label_encoder_ is not None
        return self.label_encoder_.inverse_transform(encoded)

    def fit_csv(
        self,
        path: str | Path,
        *,
        target_column: str,
        categorical_features: Optional[Iterable[str]] = None,
    ) -> "ABCFaithOpt":
        data = pd.read_csv(path)
        if target_column not in data:
            raise ValueError(f"Target column {target_column!r} was not found.")
        return self.fit(
            data.drop(columns=[target_column]),
            data[target_column],
            categorical_features=categorical_features,
        )
