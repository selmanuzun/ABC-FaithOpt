"""ABC-FaithOpt global XAI framework."""

from .abc import ABCConfig, ABCSearchResult, FeatureValueRule
from .datasets import UCIDataset, available_uci_datasets, fetch_uci_dataset
from .faithfulness import FaithfulnessOptimizerConfig
from .pipeline import ABCFaithOpt, ABCFaithOptConfig, ABCFaithOptResult

__all__ = [
    "ABCConfig",
    "ABCFaithOpt",
    "ABCFaithOptConfig",
    "ABCFaithOptResult",
    "ABCSearchResult",
    "FaithfulnessOptimizerConfig",
    "FeatureValueRule",
    "UCIDataset",
    "available_uci_datasets",
    "fetch_uci_dataset",
]

__version__ = "0.4.0"
