from __future__ import annotations

import io
import os
import shutil
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
from scipy.io import arff


@dataclass(frozen=True)
class UCIDataset:
    name: str
    uci_id: int
    X: pd.DataFrame
    y: pd.Series
    categorical_features: tuple[str, ...]
    source_url: str
    citation: str
    license: str = "CC BY 4.0"


_REGISTRY: dict[str, dict[str, Any]] = {
    "breast_cancer": {
        "uci_id": 17,
        "name": "Breast Cancer Wisconsin (Diagnostic)",
        "url": (
            "https://archive.ics.uci.edu/static/public/17/"
            "breast%2Bcancer%2Bwisconsin%2Bdiagnostic.zip"
        ),
        "citation": (
            "Wolberg, W., Mangasarian, O., Street, N., & Street, W. (1993). "
            "Breast Cancer Wisconsin (Diagnostic) [Dataset]. UCI Machine "
            "Learning Repository. https://doi.org/10.24432/C5DW2B"
        ),
    },
    "adult": {
        "uci_id": 2,
        "name": "Adult",
        "url": "https://archive.ics.uci.edu/static/public/2/adult.zip",
        "citation": (
            "Becker, B. & Kohavi, R. (1996). Adult [Dataset]. UCI Machine "
            "Learning Repository. https://doi.org/10.24432/C5XW20"
        ),
    },
    "dry_bean": {
        "uci_id": 602,
        "name": "Dry Bean",
        "url": (
            "https://archive.ics.uci.edu/static/public/602/"
            "dry%2Bbean%2Bdataset.zip"
        ),
        "citation": (
            "Dry Bean [Dataset]. (2020). UCI Machine Learning Repository. "
            "https://doi.org/10.24432/C50S4B"
        ),
    },
}

_ALIASES = {
    "17": "breast_cancer",
    "wdbc": "breast_cancer",
    "breast-cancer": "breast_cancer",
    "breast_cancer_wisconsin_diagnostic": "breast_cancer",
    "2": "adult",
    "census_income": "adult",
    "602": "dry_bean",
    "dry-bean": "dry_bean",
    "drybean": "dry_bean",
}


def available_uci_datasets() -> dict[str, int]:
    return {name: int(entry["uci_id"]) for name, entry in _REGISTRY.items()}


def _canonical_name(name: str) -> str:
    normalized = name.strip().lower().replace(" ", "_")
    normalized = _ALIASES.get(normalized, normalized)
    if normalized not in _REGISTRY:
        raise ValueError(
            f"Unknown dataset {name!r}. Available: {sorted(_REGISTRY)}"
        )
    return normalized


def _archive_path(
    canonical_name: str,
    *,
    cache_dir: str | Path | None,
    force_download: bool,
) -> Path:
    entry = _REGISTRY[canonical_name]
    configured_cache = os.environ.get("ABC_FAITHOPT_CACHE")
    root = Path(
        cache_dir
        if cache_dir is not None
        else configured_cache
        if configured_cache
        else Path.home() / ".cache" / "abc_faithopt"
    )
    root.mkdir(parents=True, exist_ok=True)
    destination = root / f"uci_{entry['uci_id']}_{canonical_name}.zip"
    if destination.exists() and not force_download:
        return destination

    request = urllib.request.Request(
        str(entry["url"]),
        headers={"User-Agent": "ABC-FaithOpt/0.2.0"},
    )
    temporary = destination.with_suffix(".zip.part")
    with urllib.request.urlopen(request, timeout=120) as response, temporary.open(
        "wb"
    ) as output:
        shutil.copyfileobj(response, output)
    temporary.replace(destination)
    return destination


def _parse_breast_cancer(archive: zipfile.ZipFile) -> tuple[pd.DataFrame, pd.Series, tuple[str, ...]]:
    member = next(name for name in archive.namelist() if name.endswith("wdbc.data"))
    measures = [
        "radius",
        "texture",
        "perimeter",
        "area",
        "smoothness",
        "compactness",
        "concavity",
        "concave_points",
        "symmetry",
        "fractal_dimension",
    ]
    features = [f"{measure}_{suffix}" for suffix in ("mean", "se", "worst") for measure in measures]
    columns = ["id", "diagnosis", *features]
    frame = pd.read_csv(archive.open(member), header=None, names=columns)
    return frame[features], frame["diagnosis"].astype("string"), ()


def _parse_adult(archive: zipfile.ZipFile) -> tuple[pd.DataFrame, pd.Series, tuple[str, ...]]:
    columns = [
        "age",
        "workclass",
        "fnlwgt",
        "education",
        "education_num",
        "marital_status",
        "occupation",
        "relationship",
        "race",
        "sex",
        "capital_gain",
        "capital_loss",
        "hours_per_week",
        "native_country",
        "income",
    ]
    training_member = next(name for name in archive.namelist() if name.endswith("adult.data"))
    test_member = next(name for name in archive.namelist() if name.endswith("adult.test"))
    common = dict(
        header=None,
        names=columns,
        skipinitialspace=True,
        na_values="?",
    )
    training = pd.read_csv(archive.open(training_member), **common)
    test = pd.read_csv(archive.open(test_member), skiprows=1, **common)
    frame = pd.concat([training, test], ignore_index=True)
    frame = frame.dropna(subset=["income"]).reset_index(drop=True)
    target = frame["income"].astype("string").str.rstrip(".")
    categorical = (
        "workclass",
        "education",
        "marital_status",
        "occupation",
        "relationship",
        "race",
        "sex",
        "native_country",
    )
    return frame.drop(columns=["income"]), target, categorical


def _parse_dry_bean(archive: zipfile.ZipFile) -> tuple[pd.DataFrame, pd.Series, tuple[str, ...]]:
    member = next(name for name in archive.namelist() if name.lower().endswith(".arff"))
    text = archive.read(member).decode("utf-8", errors="replace")
    records, _ = arff.loadarff(io.StringIO(text))
    frame = pd.DataFrame(records)
    target = frame.pop("Class").map(
        lambda value: value.decode("utf-8") if isinstance(value, bytes) else str(value)
    )
    for column in frame:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    return frame, target.astype("string"), ()


def fetch_uci_dataset(
    name: str,
    *,
    cache_dir: str | Path | None = None,
    force_download: bool = False,
) -> UCIDataset:
    """Download and parse one of the three official UCI benchmark archives."""

    canonical = _canonical_name(name)
    archive_path = _archive_path(
        canonical,
        cache_dir=cache_dir,
        force_download=force_download,
    )
    with zipfile.ZipFile(archive_path) as archive:
        if canonical == "breast_cancer":
            X, y, categorical = _parse_breast_cancer(archive)
        elif canonical == "adult":
            X, y, categorical = _parse_adult(archive)
        else:
            X, y, categorical = _parse_dry_bean(archive)

    entry = _REGISTRY[canonical]
    return UCIDataset(
        name=str(entry["name"]),
        uci_id=int(entry["uci_id"]),
        X=X,
        y=y,
        categorical_features=categorical,
        source_url=str(entry["url"]),
        citation=str(entry["citation"]),
    )
